
#pragma pack(1)

typedef struct 
{
	LONGLONG lCellScore;										//底注
	LONGLONG lJackpot;										//奖池
	LONGLONG lToltalWinScore;								//玩家累计赢得奖金
	DWORD    dwFreeGames;
}JXLW_CMD_S_Status;

typedef struct 
{
	LONGLONG lWinScore;										//开奖赢分
	LONGLONG lToltalWinScore;
	BYTE cbCardDatas[15];							//牌型数据
	BYTE cbLineDatas[9];						//中奖线数据
	DWORD    dwFreeGames;
	DWORD    dwMultiple[9];
	LONGLONG   l777Score;
 	LONGLONG   lJackpot;

}JXLW_CMD_S_Bet;

typedef struct 
{
	LONGLONG lJackpot;										//奖池
}JXLW_CMD_S_BroadcastJackpot;

typedef struct 
{
	BYTE cbLineCount;								//线数
	LONGLONG lJettonScore;								//底注
}JXLW_CMD_C_Bet;

typedef struct {  
	TCHAR szNickName[32];   
	LONGLONG   lJackpot; 
}JXLW_CMD_S_BroadcastGetJackpot;

#pragma pack(0)

