#pragma pack(1)

typedef struct {
        BYTE							bWinMen[8+1];
    }BCHI_BENCHItagServerGameRecord;

typedef struct {
        WORD							wPlaceUser;
        BYTE							lJettonArea;
        LONGLONG						lPlaceScore;
    }BCHI_CMD_S_BENCHI_PlaceJettonFail;

typedef struct {
        WORD							wChairID;
        LONGLONG							lScore;

        WORD							wCurrentBankerChairID;
        BYTE							cbBankerTime;
        LONGLONG							lCurrentBankerScore;
    }BCHI_CMD_S_BENCHI_ChangeUserScore;

typedef struct {
        WORD							wApplyUser;
    }BCHI_CMD_S_BENCHI_ApplyBanker;

typedef struct {
        WORD							wChairID;
    }BCHI_CMD_S_BENCHI_CancelBanker;

typedef struct {
        WORD							wBankerUser;
        LONGLONG						lBankerScore;
    }BCHI_CMD_S_BENCHI_ChangeBanker;

typedef struct {

        BYTE							cbTimeLeave;

        LONGLONG						lUserMaxScore;

        WORD							wBankerUser;
        WORD							cbBankerTime;
        LONGLONG						lBankerWinScore;
        LONGLONG						lBankerScore;
        bool							bEnableSysBanker;

        LONGLONG						lApplyBankerCondition;
        LONGLONG						lAreaLimitScore;
        int								CheckImage;

        char							szGameRoomName[64];
    }BCHI_CMD_S_BENCHI_StatusFree;

typedef struct {
    TCHAR	szUserName[32];
    SCORE	lWinScore;
}BCHI_tagRankUser;

typedef struct {

        LONGLONG						lAllJettonScore[8+1];		//全体总注

        LONGLONG						lUserJettonScore[8+1];		//个人总注

        LONGLONG						lUserMaxScore;						//最大下注

        LONGLONG						lApplyBankerCondition;				//申请条件
        LONGLONG						lAreaLimitScore;					//区域限制

        BYTE							cbTableCardArray[1][1];				//桌面扑克

        WORD							wBankerUser;						//当前庄家
        WORD							cbBankerTime;						//庄家局数
        LONGLONG						lBankerWinScore;					//庄家赢分
        LONGLONG						lBankerScore;						//庄家分数
        bool							bEnableSysBanker;					//系统做庄

        LONGLONG						lEndBankerScore;					//庄家成绩
        LONGLONG						lEndUserScore;						//玩家成绩
        LONGLONG						lEndUserReturnScore;				//返回积分
        LONGLONG						lEndRevenue;						//游戏税收

        BYTE							cbTimeLeave;						//剩余时间
        BYTE							cbGameStatus;						//游戏状态
        int								CheckImage;
        TCHAR							szGameRoomName[32];			//房间名称
    }BCHI_CMD_S_BENCHI_StatusPlay;

typedef struct {

        LONGLONG						lAllJettonScore[8+1];		//全体总注

        LONGLONG						lUserJettonScore[8+1];		//个人总注

        LONGLONG						lUserMaxScore;						//最大下注

        LONGLONG						lApplyBankerCondition;				//申请条件
        LONGLONG						lAreaLimitScore;					//区域限制

        BYTE							cbTableCardArray[1][1];				//桌面扑克

        WORD							wBankerUser;						//当前庄家
        WORD							cbBankerTime;						//庄家局数
        LONGLONG						lBankerWinScore;					//庄家赢分
        LONGLONG						lBankerScore;						//庄家分数
        bool							bEnableSysBanker;					//系统做庄

        LONGLONG						lEndBankerScore;					//庄家成绩
        LONGLONG						lEndUserScore;						//玩家成绩
        LONGLONG						lEndUserReturnScore;				//返回积分
        LONGLONG						lEndRevenue;						//游戏税收

        BYTE							cbTimeLeave;						//剩余时间
        BYTE							cbGameStatus;						//游戏状态
        int								CheckImage;
        TCHAR							szGameRoomName[32];			//房间名称
    

        BYTE			                 cbRankCount;
        BCHI_tagRankUser		         RankUser[5];
        LONGLONG                         areaWinScore;
}BCHI_CMD_S_StatusPlay_Ex;

typedef struct {
        BYTE							cbTimeLeave;
    }BCHI_CMD_S_BENCHI_GameFree;

typedef struct {
        WORD							wBankerUser;
        LONGLONG						lBankerScore;
        LONGLONG						lUserMaxScore;
        BYTE							cbTimeLeave;
        bool							bContiueCard;
        int								nChipRobotCount;
        bool                            bRealUser[250];
    }BCHI_CMD_S_BENCHI_GameStart;

typedef struct {
        WORD							wChairID;
        BYTE							cbJettonArea;
        LONGLONG						lJettonScore;
        BYTE							cbAndroid;

    }BCHI_CMD_S_BENCHI_PlaceJetton;

typedef struct {

        BYTE							cbTimeLeave;

        BYTE							cbTableCardArray[1][1];
        BYTE							cbLeftCardCount;

        BYTE							bcFirstCard;

        LONGLONG						lBankerScore;
        LONGLONG						lBankerTotallScore;
        INT								nBankerTime;

        LONGLONG						lUserScore;
        LONGLONG						lUserReturnScore;

        LONGLONG						lRevenue;
    }BCHI_CMD_S_BENCHI_GameEnd;

typedef struct {

        BYTE							cbTimeLeave;

        BYTE							cbTableCardArray[1][1];
        BYTE							cbLeftCardCount;

        BYTE							bcFirstCard;

        LONGLONG						lBankerScore;
        LONGLONG						lBankerTotallScore;
        INT								nBankerTime;

        LONGLONG						lUserScore;
        LONGLONG						lUserReturnScore;

        LONGLONG						lRevenue;
    

    BYTE			cbRankCount;
    BCHI_tagRankUser		RankUser[5];
    LONGLONG                        areaWinScore;
}BCHI_CMD_S_GameEnd_Ex;

typedef struct {
        LONGLONG						lStorage;
        LONGLONG						lStorageDeduct;
    }BCHI_CMD_S_BENCHI_SystemStorage;

//”√ªßœ¬◊¢
typedef struct {
        BYTE							cbJettonArea;
        LONGLONG						lJettonScore;
        LONGLONG                        nSerivalValue;

    }BCHI_CMD_C_BENCHI_PlaceJetton;

typedef struct {
        int Index;
    }BCHI_CMD_C_BENCHI_CheckImage;

typedef struct {
        BYTE cbReturnsType;
        BYTE cbControlArea;
        BYTE cbControlTimes;
    }BCHI_CMD_S_BENCHI_ControlReturns;

typedef struct {
        BYTE cbControlAppType;
        BYTE cbControlArea;
        BYTE cbControlTimes;
        LONGLONG nSerivalValue;
    }BCHI_CMD_C_BENCHI_ControlApplication;

typedef struct {
        LONGLONG						lStorage;
        LONGLONG						lStorageDeduct;
    }BCHI_CMD_C_BENCHI_UpdateStorage;

#pragma pack()

