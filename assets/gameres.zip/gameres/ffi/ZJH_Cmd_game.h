#pragma pack(push)
#pragma pack(1)

typedef struct {
    BYTE	cbCardData[5][3];
}ZJH_CMD_S_GetAllCard;

//游戏状态
typedef struct {
    LONGLONG							lCellScore;							//基础积分
}ZJH_CMD_S_StatusFree;

typedef struct {
    LONGLONG							lMaxCellScore;						//单元上限
    LONGLONG							lCellScore;							//单元下注
    LONGLONG							lCurrentTimes;						//当前倍数
    LONGLONG							lUserMaxScore;						//用户分数上限

    LONGLONG								wBankerUser;						//庄家用户
    LONGLONG				 				wCurrentUser;						//当前玩家
    LONGLONG								cbPlayStatus[5];			//游戏状态
    bool								bMingZhu[5];				//看牌状态
    LONGLONG							lTableScore[5];			//下注数目
    LONGLONG                            lUserJetton[5][30];
    WORD                                wUserJettonTimes[5][30];
    BYTE								cbHandCardData[3];					//扑克数据

    bool								bCompareState;						//比牌状态
    int								nCurRounds;						//当前轮数
    int								nMaxRounds;						//最大轮数
    int								nLastSeconds;						//剩余秒数
    bool							bIsAllIn;						//是否全下
    LONGLONG							lAllInScore;						//全下金额
}ZJH_CMD_S_StatusPlay;

typedef struct {
    LONGLONG							lMaxScore;							//最大下注
    LONGLONG							lCellScore;							//单元下注
    LONGLONG							lCurrentTimes;						//当前倍数
    LONGLONG							lUserMaxScore;						//分数上限

    WORD								wBankerUser;						//庄家用户
    WORD				 				wCurrentUser;						//当前玩家
    int								nMaxRounds;						//最大轮数
}ZJH_CMD_S_GameStart;

//用户下注
typedef struct {
    WORD								wCurrentUser;						//当前用户
    WORD								wAddScoreUser;						//加注用户
    WORD								wCompareState;						//比牌状态
    LONGLONG							lAddScoreCount;						//加注数目
    LONGLONG						    lCurrentTimes;						//当前倍数
    int								    nCurRounds;						//剩余轮数
    WORD							    bIsAllIn;						//是否全下命令
    bool							    bIsOpenCard;					//是否开牌
}ZJH_CMD_S_AddScore;

//用户放弃
typedef struct {
    WORD								wGiveUpUser;						//放弃用户
    BYTE								cbCardData[3];				//用户扑克
}ZJH_CMD_S_GiveUp;

//比牌数据包
typedef struct {
    WORD								wCurrentUser;						//当前用户
    WORD								wCompareUser[2];					//比牌用户
    WORD								wLostUser;							//输牌用户
    BYTE                                cbCardData[3];
}ZJH_CMD_S_CompareCard;

//孤注一掷比牌数据包
typedef struct 
{
    BYTE                                wCount;                             //比牌次数
    ZJH_CMD_S_CompareCard                   compareCard[4];                     //比牌数据
}ZJH_CMD_S_CompareCardNoMoney;

//看牌数据包
typedef struct {
    WORD								wLookCardUser;						//看牌用户
    BYTE								cbCardData[3];				//用户扑克
}ZJH_CMD_S_LookCard;

//发送扑克
typedef struct {
    BYTE								cbCardData[5][3];	//用户扑克
}ZJH_CMD_S_SendCard;

//开牌数据包
typedef struct {
    WORD								wWinner;							//胜利用户
}ZJH_CMD_S_OpenCard;

//游戏结束
typedef struct {
    LONGLONG							lGameTax;							//游戏税收
    LONGLONG							lGameScore[5];			//游戏得分
    BYTE								cbCardData[5][3];			//用户扑克
    WORD								wCompareUser[5][4];		//比牌用户
    WORD                                wOpenUser[5];             //开牌用户
    WORD								wEndState;							//结束状态
}ZJH_CMD_S_GameEnd;

//用户退出
typedef struct {
    WORD								wPlayerID;							//退出用户
}ZJH_CMD_S_PlayerExit;

//等待比牌
typedef struct {
    WORD								wCompareUser;						//比牌用户
}ZJH_CMD_S_WaitCompare;

//发送明牌
typedef struct {
    BYTE			cbCardData[5][3];	//用户扑克
}ZJH_CMD_S_Brand;

//用户加注
typedef struct {
    LONGLONG							lScore;								//加注数目
    WORD								wState;								//当前状态
    WORD							bIsAllIn;							//是否全下
}ZJH_CMD_C_AddScore;

//比牌数据包
typedef struct {	
    WORD								wCompareUser;						//比牌用户
}ZJH_CMD_C_CompareCard;

typedef struct 
{
    bool                                bNoAllIn;                           //是否allin模式
    LONGLONG                            lMaxCellScore;                      //allin最大注
}ZJH_CMD_S_Config;

//亮牌 
typedef struct  { 
 WORD        wShowUser;       //放弃用户  
 BYTE        cbCardData[3];    //用户扑克 
}ZJH_CMD_S_ShowCard;

typedef struct {
    WORD        wState;        //1自动加注 0取消
}ZJH_CMD_C_AutoScore;

typedef struct{
    WORD        wIndex;
    
}ZJH_CMD_C_ClientError;

#pragma pack(pop)
