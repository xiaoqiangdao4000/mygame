#pragma pack(1)

typedef struct
{
	//游戏属性
	LONG							lCellScore;							//基础积分
	//时间信息
	BYTE							cbTimeOutCard;						//出牌时间
	BYTE							cbTimeStartGame;					//开始时间
	BYTE							cbTimeHeadOutCard;					//首出时间
}PDK_CMD_S_StatusFree;

//游戏状态
typedef struct
{
	//时间信息
	BYTE							cbTimeOutCard;						//出牌时间
	BYTE							cbTimeStartGame;					//开始时间
	BYTE							cbTimeHeadOutCard;					//首出时间
	//游戏变量
	LONG							lCellScore;							//单元积分
	WORD							wCurrentUser;						//当前玩家

	//出牌信息
	WORD							wTurnWiner;							//胜利玩家
	BYTE							cbTurnCardCount;					//出牌数目
	BYTE							cbTurnCardData[16];			//出牌数据
	//扑克信息
	BYTE							cbHandCardData[16];			//手上扑克
	BYTE							cbHandCardCount[3];		//扑克数目
	BYTE							cbUserTrustee[3];			//托管标志
	BYTE                            cbPass;                     //1表示下家有大，0标识下家大不过
}PDK_CMD_S_StatusPlay;

//发送扑克
typedef struct
{
	WORD				 			wCurrentUser;						//当前玩家
	BYTE							cbCardData[16];			//扑克列表
	LONG							lCellScore;							//基础积分
	//时间信息
	BYTE							cbTimeOutCard;						//出牌时间
	BYTE							cbTimeStartGame;					//开始时间
	BYTE							cbTimeHeadOutCard;					//首出时间
}PDK_CMD_S_GameStart;


//用户出牌
typedef struct
{
	BYTE							cbCardCount;						//出牌数目
	WORD				 			wCurrentUser;						//当前玩家
	WORD							wOutCardUser;						//出牌玩家
	BYTE							cbCardData[16];				//扑克列表
	BYTE                            cbPass;                     //1表示下家有大，0标识下家大不过
	SCORE                           lScore[3];                //此次出牌造成的分数改变，一般用于炸弹
}PDK_CMD_S_OutCard;

//放弃出牌
typedef struct
{
	BYTE							cbTurnOver;							//一轮结束
	WORD				 			wCurrentUser;						//当前玩家
	WORD				 			wPassCardUser;						//放弃玩家
	BYTE                            cbPass;                             //1表示下家有大，0标识下家大不过
	SCORE                           lScore[3];                			//此次出牌造成的分数改变，一般用于炸弹
}PDK_CMD_S_PassCard;

//游戏结束
typedef struct
{
	//积分变量
	LONG							lCellScore;							//单元积分
	SCORE							lGameScore[3];			//游戏积分
	BYTE                            cbChuntian[3];            //是否被春天或者春天
	WORD                            wBaoPei;               //包赔玩家
	//游戏信息
	BYTE							cbCardCount[3];			//扑克数目
	BYTE							cbHandCardData[48];			//扑克列表
}PDK_CMD_S_GameConclude;

//托管
typedef struct
{
	WORD							wTrusteeUser;						//托管玩家
	BYTE							bTrustee;							//托管标志
}PDK_CMD_S_TRUSTEE;


//用户出牌
typedef struct
{
	BYTE							cbCardCount;						//出牌数目
	BYTE							cbCardData[16];				//扑克数据
}PDK_CMD_C_OutCard;

//托管
typedef struct
{
	BYTE							bTrustee;							//托管标志
}PDK_CMD_C_TRUSTEE;

// 炸弹分数
typedef struct
{  
	SCORE       lBombScore[3];   //炸弹积分 
}PDK_CMD_S_BOMBINFO;

///////////////////////////////////////gary测试用的明牌协议///////////////////////////////////////
typedef struct
{
	BYTE       cbHandCardCount[3];  //扑克数目
	BYTE       cbHandCard[3][16]; //手上扑克
	WORD       wCurrentUser;      //当前玩家
}PDK_CMD_S_AndroidCard;
#pragma pack()

