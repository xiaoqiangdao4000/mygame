#pragma pack(1)

typedef struct
{
    int nJettonArea;
    SCORE lScore;
}SBB_CMD_C_Jetton;

typedef struct
{
    SCORE lBet[53];
}SBB_CMD_C_Jetton_Continue;

typedef struct
{
    BYTE nArea;    //下注区域
    WORD wChairID;
    SCORE lScore;     //本次下注的量
    SCORE lTotalJetton;    //此门下注的总量
    SCORE lTotal;     //个人下注总量
}SBB_CMD_S_Jetton;

//开始协议
typedef struct
{
    SCORE lJettonConfig[5];//可下注的筹码
    int nJettonAreaTimes[53];
    BYTE cbTimeLeave;                        //剩余时间
}SBB_CMD_S_GameStart;

//游戏空闲
typedef struct
{
    BYTE                            cbTimeLeave;                        //剩余时间
    BYTE                            cbStatus;
}SBB_CMD_S_GameStatus;


typedef struct
{
    BYTE                            cbTimeLeave;                        //剩余时间
    BYTE                            cbStatus;
    SCORE                            lJettonConfig[5];                    //可下注的筹码
    SCORE                           lJettoned[53];                //各个区域已下注总额
    int                                nAward;                             //已经开出的奖
    int                                nJettonAreaTimes[53];        //下注区的倍数
    SCORE                            lPlayerJettoned[53];        //各个区域玩家已下注总额
    int                                nAwardRecord[40];        //中奖纪录
     SCORE                              lTotal;     //个人下注总量
}SBB_CMD_S_GameScene;

typedef struct
{
    WORD wChairID;
    SCORE lJetton[53];
    SCORE lTotalJetton[53];    //这个区域的总注
    BYTE  cbRet;           //0成功 1钱不够
}SBB_CMD_S_Jetton_Continue;

//游戏结束
typedef struct
{
    int nAward;
    SCORE lScore;
    SCORE lJettoned;
    BYTE cbHit[10];                        //命中区域
    BYTE cbTimeLeave;                    //剩余时间
    int nAwardRecord[40]; //中奖纪录
}SBB_CMD_S_GameEnd;

#pragma pack()
