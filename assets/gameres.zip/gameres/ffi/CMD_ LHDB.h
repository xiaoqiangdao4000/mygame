#pragma pack(push)
#pragma pack(1)

//游戏状态 
typedef struct{
	LONGLONG   	lCellScore;//房间底分
	LONGLONG   	lTotalWinScore;         //累计赢分  
	DWORD    		dwMultiple;          //下注分数  
	DWORD    		dwLine;           //下注线数  
	BYTE    			cbCardArray[240];       //牌型数据  
	BYTE    			cbBrickCount;         //剩余钻头数量  
	WORD    		wBetMultiple[12];        //可下注的筹码 
	LONGLONG	lJackpot;				//奖池
    LONGLONG			lSpecialAward;									//
    LONGLONG			lTreasure[4];
}SERIAL_CMD_S_STATUS;  
//用户下注 
typedef struct{
	BYTE    			cbCardArray[240];  //牌型数据  
	LONGLONG   	lWinScore; 			//开奖赢分
	LONGLONG   	lTotalWinScore;		//累计赢分
	BYTE    			cbBrickCount;			//剩余钻头数量
	LONGLONG   	lJettonScore;         //下注分数 
	LONGLONG	lJackpot;				//中奖池分数
}SERIAL_CMD_S_BET;

//广播奖池
typedef struct
{
	DWORD    				dwUserID;
	LONGLONG   			lJackpot;          //奖池
}SERIAL_CMD_S_BROADCAST_JACKPOT;

typedef struct
{
	WORD				wWinTreasure;
}SERIAL_CMD_S_TREASURE;
typedef struct
{
	LONGLONG	lSpecialAward;
	LONGLONG	lTreasure[4];
}SERIAL_CMD_S_TREASUREINFO;

//广播中高倍奖
typedef struct 
{
	TCHAR				szNickName[32];						//中奖用户
	TCHAR				szServerName[32];						//房间名称
	LONGLONG		lJackpot;										//中了奖池
	LONGLONG		lWinScore;										//中了高倍奖
}SERIAL_CMD_S_BROADCAST_AWARDS;

typedef struct
{
	WORD			wMultiple;
	WORD			wLine;
}SERIAL_CMD_C_BET;

/********** 保存游戏进度 **********/
typedef struct
{
    bool bSave;
}SERIAL_CMD_C_STORAGE;

typedef struct
{
    bool bSave; // 是否保存
}SERIAL_CMD_S_STORAGE;
/********** 保存游戏进度 **********/


/********** 聊天纪录 **********/
typedef struct
{
    DWORD dwUserID;
    TCHAR szNickName[32]; // 聊天用户名
    TCHAR szContent[128]; // 内容
}ChatRecord;
/********** 聊天记录 **********/

/********** 高分玩家信息 **********/
typedef struct
{
    DWORD dwID;															// id
	TCHAR szNickName[32];
    LONGLONG lScore;													// 得分
    LONGLONG lJackpot;													// 奖池得分
    LONGLONG lJetton;													// 下注
    DWORD dwPopularity;													// 欢迎度
    DWORD dwBrick;														// 当前砖头数量
    DWORD dwCleapUpBrick;            									//消除的砖头  
    BYTE cbCardArray[240];										// 牌型
    SYSTEMTIME syTime;													// 系统时间
    //ChatRecord chats[2];												// 聊天纪录
}JackpotRecord;
/********** 高分玩家信息 **********/

/********** 收到高分玩家信息 **********/
typedef struct
{
    JackpotRecord record[30];											//
}SERIAL_CMD_S_LoadJackpotRecord;
/********** 收到高分玩家信息 **********/

/********** 更新人气 **********/
typedef struct
{
    DWORD dwID;
    DWORD dwPopularity;
}SERIAL_CMD_S_UpdatePopularity;
/********** 更新人气 **********/

/********** 更新聊天 **********/
typedef struct
{
    DWORD dwID;
    ChatRecord chat;												//
}SERIAL_CMD_S_Chat;
/********** 更新聊天 **********/

/********** 发送更新人气 **********/
typedef struct
{
    DWORD dwID;
}SERIAL_CMD_C_UpdatePopularity;
/********** 发送更新人气 **********/

/********** 发送评论 **********/
typedef struct
{
    DWORD dwID;
    char szContent[128];												//
}SERIAL_CMD_C_Chat;
/********** 发送评论 **********/

/********** 加载评论 **********/
typedef struct
{
    DWORD dwID;
}SERIAL_CMD_C_LOAD_CHAT;

typedef struct
{
    DWORD dwID;
    ChatRecord chats[20];
}SERIAL_CMD_S_LOAD_CHAT;
/********** 加载评论 **********/
































#pragma pack(pop)
