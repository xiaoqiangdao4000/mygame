
#pragma pack(1)

//攻击怪兽获得伤害值
typedef struct {
	DWORD		dwUserID;
	CHAR		szMonsterID[33];
	DWORD		dwHit;			//伤害值
	LONGLONG	lLuckyScore;	//获得分数
	BYTE		cbIsLucky;		//幸运一击
	DWORD       dwParam;		//捕鱼用到的特殊字段，表示鱼的id

}CMD_GR_S_MonsterHit;

//怪物信息
typedef struct
{
	CHAR		szMonsterID[33];
	BYTE		cbIsBoss;
}CMD_GR_S_MonsterInfo;

#pragma pack(0)
