#pragma pack(1)

//记录信息
typedef struct {
    bool							bInit;
    bool							bWinShunMen;						//顺门胜利
    bool							bWinDuiMen;							//对门胜利
    bool							bWinDaoMen;							//倒门胜利

}HLZZtagClientGameRecord;

//记录信息
typedef struct {
    bool							bWinShunMen;						//顺门胜利
    bool							bWinDuiMen;							//对门胜利
    bool							bWinDaoMen;							//倒门胜利
}HLZZtagServerGameRecord;

//失败结构
typedef struct {
    WORD							wPlaceUser;							//下注玩家
    BYTE							lJettonArea;						//下注区域
    LONGLONG						lPlaceScore;						//当前下注
}CMD_S_HLZZ_PlaceJettonFail;

typedef struct {
    WORD							wChairID;							//椅子号码
    LONGLONG							lScore;								//玩家积分

    WORD							wCurrentBankerChairID;				//当前庄家
    BYTE							cbBankerTime;						//庄家局数
    LONGLONG							lCurrentBankerScore;				//庄家分数
}CMD_S_HLZZ_ChangeUserScore;

//申请庄家
typedef struct {
    WORD							wApplyUser;							//申请玩家
}CMD_S_HLZZ_ApplyBanker;

//取消申请
typedef struct {
    WORD							szCancelUser;					//取消玩家
}CMD_S_HLZZ_CancelBanker;

//切换庄家
typedef struct {
    WORD							wBankerUser;						//当庄玩家
    LONGLONG						lBankerScore;						//庄家欢乐豆
}CMD_S_HLZZ_ChangeBanker;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    LONGLONG						lUserMaxScore;						//玩家欢乐豆

    WORD							wBankerUser;						//当前庄家
    WORD							cbBankerTime;						//庄家局数
    LONGLONG						lBankerWinScore;					//庄家成绩
    LONGLONG						lBankerScore;						//庄家分数
    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制
    LONGLONG                        lQiangConition;

    LONGLONG                        lQiangScore;

    LONGLONG							dwServerId;			//房间名称
}CMD_S_HLZZ_StatusFree;

typedef struct {
    LONGLONG						lAllJettonScore[7];		//全体总注

    LONGLONG						lUserJettonScore[7];		//个人总注

    LONGLONG						lUserMaxScore;						//最大下注

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制

    LONGLONG                        lQiangConition;
    LONGLONG                        lQiangScore;

    BYTE							cbTableCardArray[4][2];				//桌面扑克

    WORD							wBankerUser;						//当前庄家
    WORD							cbBankerTime;						//庄家局数
    LONGLONG						lBankerWinScore;					//庄家赢分
    LONGLONG						lBankerScore;						//庄家分数
    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lEndBankerScore;					//庄家成绩
    LONGLONG						lEndUserScore;						//玩家成绩
    LONGLONG						lEndUserReturnScore;				//返回积分
    LONGLONG						lEndRevenue;						//游戏税收

    BYTE							cbTimeLeave;						//剩余时间
    BYTE							cbGameStatus;						//游戏状态

    LONGLONG dwServerId;			//房间名称
}CMD_S_HLZZ_StatusPlay;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    BYTE							cbTableCardArray[4][2];				//桌面扑克
    BYTE							cbLeftCardCount;					//扑克数目

    WORD							bcFirstCard;

    WORD							wCurrentBanker;						//当前庄家
    LONGLONG						lBankerScore;						//庄家成绩
    LONGLONG						lBankerTotallScore;					//庄家成绩
    INT								nBankerTime;						//做庄次数

    LONGLONG						lUserScore;							//玩家成绩
    LONGLONG						lUserReturnScore;					//返回积分

    LONGLONG						lRevenue;							//游戏税收
}CMD_S_GameEnd;

typedef struct {
    TCHAR	szUserName[32];
    SCORE	lWinScore;
}tagRankUser;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    BYTE							cbTableCardArray[4][2];				//桌面扑克
    BYTE							cbLeftCardCount;					//扑克数目

    WORD							bcFirstCard;

    WORD							wCurrentBanker;						//当前庄家
    LONGLONG						lBankerScore;						//庄家成绩
    LONGLONG						lBankerTotallScore;					//庄家成绩
    INT								nBankerTime;						//做庄次数

    LONGLONG						lUserScore;							//玩家成绩
    LONGLONG						lUserReturnScore;					//返回积分

    LONGLONG						lRevenue;							//游戏税收

    BYTE			cbRankCount;
    tagRankUser		RankUser[5];
    SCORE			lAreaScore[7];

}CMD_S_GameEnd_Ex;

typedef struct {
    LONGLONG						lAllJettonScore[7];		//全体总注

    LONGLONG						lUserJettonScore[7];		//个人总注

    LONGLONG						lUserMaxScore;						//最大下注

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制

    LONGLONG                        lQiangConition;
    LONGLONG                        lQiangScore;

    BYTE							cbTableCardArray[4][2];				//桌面扑克

    WORD							wBankerUser;						//当前庄家
    WORD							cbBankerTime;						//庄家局数
    LONGLONG						lBankerWinScore;					//庄家赢分
    LONGLONG						lBankerScore;						//庄家分数
    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lEndBankerScore;					//庄家成绩
    LONGLONG						lEndUserScore;						//玩家成绩
    LONGLONG						lEndUserReturnScore;				//返回积分
    LONGLONG						lEndRevenue;						//游戏税收

    BYTE							cbTimeLeave;						//剩余时间
    BYTE							cbGameStatus;						//游戏状态

    LONGLONG                           dwServerID;
}CMD_S_StatusPlay;

typedef struct {
    LONGLONG						lAllJettonScore[7];		//全体总注

    LONGLONG						lUserJettonScore[7];		//个人总注

    LONGLONG						lUserMaxScore;						//最大下注

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制

    LONGLONG                        lQiangConition;
    LONGLONG                        lQiangScore;

    BYTE							cbTableCardArray[4][2];				//桌面扑克

    WORD							wBankerUser;						//当前庄家
    WORD							cbBankerTime;						//庄家局数
    LONGLONG						lBankerWinScore;					//庄家赢分
    LONGLONG						lBankerScore;						//庄家分数
    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lEndBankerScore;					//庄家成绩
    LONGLONG						lEndUserScore;						//玩家成绩
    LONGLONG						lEndUserReturnScore;				//返回积分
    LONGLONG						lEndRevenue;						//游戏税收

    BYTE							cbTimeLeave;						//剩余时间
    BYTE							cbGameStatus;						//游戏状态

    LONGLONG                           dwServerID;

    BYTE			cbRankCount;
    tagRankUser		RankUser[5];
    SCORE			lAreaScore[7];
}CMD_S_StatusPlay_Ex;
//游戏空闲
typedef struct {
    BYTE							cbTimeLeave;						//剩余时间
    WORD							wCurrentBanker;						//当前庄家
    INT								nBankerTime;						//做庄次数
}CMD_S_HLZZ_GameFree;

//游戏开始
typedef struct {
    WORD							wBankerUser;						//庄家位置
    LONGLONG						lBankerScore;						//庄家欢乐豆
    LONGLONG						lUserMaxScore;						//我的欢乐豆
    BYTE							cbTimeLeave;						//剩余时间
    bool							bContiueCard;						//继续发牌
    int								nChipRobotCount;					//人数上限 (下注机器人)
}CMD_S_HLZZ_GameStart;

//用户下注
typedef struct {
    WORD							wChairID;							//用户位置
    BYTE							cbJettonArea;						//筹码区域
    LONGLONG						lJettonScore;						//加注数目
    bool							bIsAndroid;							//是否机器人
}CMD_S_HLZZ_PlaceJetton;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    BYTE							cbTableCardArray[4][2];				//桌面扑克
    BYTE							cbLeftCardCount;					//扑克数目

    WORD							bcFirstCard;

    WORD							wCurrentBanker;						//当前庄家
    LONGLONG						lBankerScore;						//庄家成绩
    LONGLONG						lBankerTotallScore;					//庄家成绩
    INT								nBankerTime;						//做庄次数

    LONGLONG						lUserScore;							//玩家成绩
    LONGLONG						lUserReturnScore;					//返回积分

    LONGLONG						lRevenue;							//游戏税收
}CMD_S_HLZZ_GameEnd;

typedef struct {
    TCHAR	szUserName[32];
    SCORE	lWinScore;
}CMD_S_HLZZ_TagRankUser;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    BYTE							cbTableCardArray[4][2];				//桌面扑克
    BYTE							cbLeftCardCount;					//扑克数目

    WORD							bcFirstCard;

    WORD							wCurrentBanker;						//当前庄家
    LONGLONG						lBankerScore;						//庄家成绩
    LONGLONG						lBankerTotallScore;					//庄家成绩
    INT								nBankerTime;						//做庄次数

    LONGLONG						lUserScore;							//玩家成绩
    LONGLONG						lUserReturnScore;					//返回积分

    LONGLONG						lRevenue;							//游戏税收

    BYTE			cbRankCount;
    CMD_S_HLZZ_TagRankUser		RankUser[5];
    SCORE			lAreaScore[7];

}CMD_S_HLZZ_GameEnd_Ex;

//游戏作弊
typedef struct {
    BYTE							cbTableCardArray[4][2];				//桌面扑克
}CMD_S_HLZZ_Cheat;

//更新库存
typedef struct {
    LONGLONG						lStorage;						//新库存值
    LONGLONG						lStorageDeduct;					//库存衰减
}CMD_S_HLZZ_SystemStorage;

//控制区域信息
typedef struct {
    BYTE cbControlArea[3];			//控制区域
}HLZZ_tagControlInfo;

typedef struct {
    BYTE							m_cbExcuteTimes;					//执行次数
    BYTE							m_cbControlStyle;					//控制方式
    bool							m_bWinArea[3];						//赢家区域
}HLZZ_tagAdminReq;

typedef struct {
    BYTE cbReqType;
    BYTE cbExtendData[20];			//附加数据V
    LONGLONG nServerValue;
}HLZZ_C_HLZZ_AdminReq;

//用户下注
typedef struct {
    BYTE							cbJettonArea;						//筹码区域
    LONGLONG						lJettonScore;						//加注数目
}CMD_C_HLZZ_PlaceJetton;

typedef struct {
    LONGLONG lUserJettonScore[7];	    //个人总注
}CMD_S_HLZZ_ScoreResult;

typedef struct {
    char szAccount[100][32];					//帐号昵称
}CMD_S_HLZZ_AccountResult;
//更新库存
typedef struct {
    LONGLONG						lStorage;						//新库存值
    LONGLONG						lStorageDeduct;					//库存衰减
}CMD_C_HLZZ_UpdateStorage;

#pragma pack()
