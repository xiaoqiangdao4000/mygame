#pragma pack(1)

// #define MDM_AS_ACTIVITY_SERVICE		2	

// #define SUB_GP_ACTIVITY_REQUEST			700							//活动请求
// #define SUB_GP_ACTIVITY_RESPONSE		701							//活动相应

//服务命令
//#define MDM_GP_USER_SERVICE   3         //用户服务
// #define SUB_GP_BRAODCAST_ACTIVITY_MESSAGE  704  

//dwMessageID活动消息id
// #define MESSAGE_GET_LOTTERY_REQUEST   1
// #define MESSAGE_GET_LOTTERY_RESPONSE  2
// #define MESSAGE_DRAW_A_LOTTERY_REQUEST  3
// #define MESSAGE_DRAW_A_LOTTERY_RESPONSE  4
// #define MESSAGE_DRAW_A_LOTTERY_BROADCAST 5
// #define MESSAGE_STATE_UPDATE_BROADCAST  6

typedef struct {
	DWORD		dwActivityID;
	DWORD		dwMessageID;
	CHAR		szMessage[8192];			//json消息
}CMD_GP_Activity_Request;

typedef struct {
	DWORD		dwActivityID;
	DWORD		dwMessageID;
	CHAR		szMessage[8192];			//json消息
}CMD_GP_Activity_Response;

//喇叭服
typedef struct {
	DWORD		dwActivityID;
	DWORD		dwMessageID;
	CHAR		szMessage[8192];			//json消息
}CMD_CS_S_BroadCast_Activity_Message;

// szMessage json {
// 	DWORD dwUserID;    //玩家ID
// }CMD_GP_LotteryInfoRequest;

// szMessage json {
// 	DWORD		dwPeriod;						//当前期数
// 	LONGLONG	lReward;						//奖金
// 	DWORD		dwTotalCount;					//总份数
// 	DWORD		dwRemainCount;					//剩余份数
// 	LONGLONG	lUnitPrice;						//单价
// 	DWORD		dwWinnerID;						//赢家
// 	char		szWinner[64];			//赢家名字
// 	DWORD		dwWinningNumber;				//中奖号码
// 	char		szLastWinner[64];		//上一期赢家
// 	LONGLONG	lLastReward;					//上一期奖金
// 	WORD		wState;							//一元夺宝的服务器状态 0：启动中 1：购买中 2：等待开奖中  3：开完奖
// 	DWORD		dwStateTime;					//进入wState的时间点 		
// }CMD_GP_LotteryInfoResponse;

// szMessage json {
// 	DWORD   dwUserID;      //玩家ID
// 	DWORD	dwCount;						//购买份数
// 	char	szToken[66];				//临时密码
// 	char	szMachineID[66];	//机器序列
// }CMD_GP_DrawALotteryRequest;

// szMessage json {
// 	DWORD		dwUserID;				//玩家ID
// 	DWORD		dwResult;	//0成功
// 	CHAR		szUser[64];	//玩家名字
// 	DWORD		dwCount;				//购买份数
// 	DWORD		numbers[20];			//购买的号码
// 	DWORD		dwLeftCount;			//剩余号码
// }CMD_GP_DrawALotteryResponse;


/*
szMessage json {
	DWORD		dwPeriod;						//当前期数
	LONGLONG	lReward;						//奖金
	DWORD		dwTotalCount;					//总份数
	DWORD		dwRemainCount;					//剩余份数
	LONGLONG	lUnitPrice;						//单价
	DWORD		dwWinnerID;						//赢家
	char		szWinner[32];			//赢家名字
	DWORD		dwWinningNumber;				//中奖号码
	char		szLastWinner[32];		//上一期赢家
	LONGLONG	lLastReward;					//上一期奖金
	WORD		wState;							//一元夺宝的服务器状态 0：启动中 1：购买中 2：等待开奖中  3：开完奖
	DWORD		dwStateTime;					//进入wState的时间点 		
}CMD_GP_BroadcastLotteryInfo;

szMessage json {
	DWORD		dwUserID;				//玩家ID
	char		szUser[32];	//玩家名字
	DWORD		dwCount;				//购买份数
	DWORD		numbers[20];			//购买的号码
	DWORD		dwLeftCount;			//剩余号码
}CMD_GP_BroadcastDrawALottery;
*/