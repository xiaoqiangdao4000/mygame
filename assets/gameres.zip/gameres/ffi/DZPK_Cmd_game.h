#pragma pack(push)
#pragma pack(1)     

//场景协议：游戏状态
typedef struct
{
    BYTE                cbStatus;
    WORD                wButton;                                //庄家位置（客户端需要加+1）
    WORD                wCurrentUser;                            //当前用户（客户端需要加+1）
    LONGLONG            lPot;                                    //底池
    LONGLONG            lSmallBlind;                            //小盲注分数
    LONGLONG            lBigBlind;                                //大盲注分数
    DWORD                wActionTimeLeft;                        //剩余操作时间
    WORD                wRaiseCount;                            //该轮加注次数
    BYTE                cbUserAction[6];                //游戏状态
    LONGLONG            lUserBetScore[6];                //这一轮下注数目
    LONGLONG            lUserTotalBetScore[6];        //总的下注数目
    LONGLONG            lUserWinScore[6];                //最终得分
    LONGLONG            lMainSidePot[10];                             //主池和边池
    BYTE                cbHandCardData[6][7];    //桌面扑克
    LONGLONG            lAnte;         //前注
    
}DZPK_CMD_S_Status;

//游戏进入“翻牌前”阶段
typedef struct
{
    WORD                wButton;                                //庄家位置（客户端需要加+1）
    WORD                wCurrentUser;                            //当前用户（客户端需要加+1）
    LONGLONG            lSmallBlind;                            //小盲注分数
    LONGLONG            lBigBlind;                                //大盲注分数
    WORD                wRaiseCount;       //该轮加注次数
    BYTE                cbUserAction[6];                //游戏状态
    LONGLONG            lUserBetScore[6];                //叫庄数目
    BYTE                cbCardData[7];                    //用户扑克
}DZPK_CMD_S_GameStartPreflop;

//游戏进入新的一圈
typedef struct
{
    BYTE                cbStatus;                                //“翻牌”“转牌”“河牌”
    BYTE                cbCardData[6][7];       //用户扑克
    LONGLONG            lMainSidePot[10];                        //主池和边池
    WORD                wNextUser;
}DZPK_CMD_S_GameRound;

typedef struct
{
    BYTE    cbCardData[7];          //桌面扑克
    LONGLONG   lMainSidePot[10];      //主池和边池
}DZPK_CMD_S_SendAllCard;

//游戏结算
typedef struct
{
    LONGLONG   lUserWinScore[6];    //最终得分
    BYTE    cbCardData[6][7];  //桌面扑克
    LONGLONG   lMainSidePot[10];      //主池和边池
    WORD    wWinner[10][6];    //每个主池和边池的赢家
    BYTE    cbUserAction[6];    //游戏状
    BYTE cbBiggestCardData[6][5];  //亮牌扑克
}DZPK_CMD_S_GameEnd;

//用户下注
typedef struct
{
    WORD                wChairID;
    LONGLONG            lScore;                                    //加注数目
    WORD                wNextUser;
}DZPK_CMD_S_Bet;

//用户加注
typedef struct
{
    WORD                wChairID;
    WORD                wRaiseCount;
    LONGLONG            lScore;                                    //加注数目
    WORD                wNextUser;
}DZPK_CMD_S_Raise;

//用户跟注
typedef struct
{
    WORD                wChairID;
    LONGLONG            lScore;                                    //加注数目
    WORD                wNextUser;
}DZPK_CMD_S_Call;

//用户弃牌
typedef struct
{
    WORD                wChairID;
    BYTE                cbCardData[7];                    //用户扑克
    WORD                wNextUser;
}DZPK_CMD_S_Fold;

//用户过牌
typedef struct
{
    WORD                wChairID;
    WORD                wNextUser;
}DZPK_CMD_S_Check;

//用户全下
typedef struct
{
    WORD                wChairID;
    LONGLONG            lScore;                                    //加注数目
    WORD                wNextUser;
}DZPK_CMD_S_Allin;

//轮到该玩家行动了
typedef struct
{
    WORD                wChairID;                                //退出用户
    //    BYTE                cbActonMask;                            //操作码
}DZPK_CMD_S_PlayerRound;

//用户退出
typedef struct
{
    WORD                wChairID;                                //退出用户
}DZPK_CMD_S_PlayerExit;

//用户加注
typedef struct
{
    LONGLONG                lScore;                                //下注数目
}DZPK_CMD_C_Raise;

//用户加注
typedef struct
{
    LONGLONG                lScore;                                //下注数目
}DZPK_CMD_C_Bet;

typedef struct 
{  
    DWORD    wChairID;          
    DWORD    dwUserID;         
    LONGLONG   lUserScore;        //玩家分数 
    LONGLONG   lAddedScore;       //补充的分数  
    LONGLONG   lRemainScore;       //背包剩余分数分数
    bool    bGameEnd;        //结算标志

}DZPK_CMD_S_UpdateUserScore;

//加载比赛信息
typedef struct 
{
    DWORD                dwUserID;                            //玩家ID
}CMD_MB_LoadTexasHoldemMatchRequest;

//加载我参与的比赛信息
typedef struct 
{
    DWORD               dwUserID;                           //玩家
}CMD_MB_LoadTexasHoldemJoinMatchRequest;

//参与比赛请求
typedef struct 
{
    WORD                wMatchID;                           //比赛ID
}CMD_MB_LoadTexasHoldemBlindRequest;

//加载某个比赛的固定奖励信息
typedef struct 
{
    WORD                wMatchID;                           //比赛ID
}CMD_MB_LoadTexasHoldemFixedBonusRequest;


//参与比赛请求
typedef struct 
{
    WORD                wMatchID;                           //比赛ID
    WORD                wServerID;                          //比赛ID
    DWORD                wUserID;       //玩家ID
    CHAR                szTempPassword[33];            //临时密码
    CHAR                szMachineID[33];        //机器标识
}CMD_MB_JoinTexasHoldemMatchRequest;

//参与比赛请求
typedef struct 
{
    WORD                wMatchID;                           //比赛ID
    WORD                wServerID;                          //比赛ID
    DWORD                wUserID;       //玩家ID
    CHAR                szTempPassword[33];            //临时密码
    CHAR                szMachineID[33];        //机器标识
}CMD_MB_QuitTexasHoldemMatchRequest;

//参与过往比赛请求
typedef struct 
{
    DWORD               dwUserID;                           //玩家ID
}CMD_MB_LoadTexasHoldemMatchRecordRequest;

//参与某个过往比赛排名请求
typedef struct 
{
    DWORD               dwPeriodID;
    DWORD               dwUserID;               
}CMD_MB_LoadTexasHoldemMatchResultRequest;

//加载比赛结果
typedef struct 
{
    bool                bStart;
    bool                bEnd;
    WORD                wMatchID;                           //比赛ID
    WORD                wServerID;                          //服务器ID
    WORD                wSortID;
    CHAR                szMatchName[32 * 2];        //比赛名称
    WORD                wMatchType;                         //赛事类型 0定时赛 1人满赛
    WORD                wAwardType;                         //奖励类型 0固定奖励 1滚雪球
    LONGLONG            lTotalAward;                        //奖励总和
    DWORD               dwMinUserCount;                     //最小参赛人数
    DWORD               dwMaxUserCount;                     //最大参赛人数
    LONGLONG            lRegistrationFee;                   //报名费
    LONGLONG            lServiceFee;                        //服务费
    LONGLONG            lInitChip;                          //玩家初始筹码
    LONGLONG            lLoseCip;                           //玩家淘汰筹码
    WORD                wRebuyTimes;                        //重购次数限制
    WORD                wRebuyMinLevel;                     //重购最小盲注等级
    WORD                wRebuyMaxLevel;                     //重购最大盲注等级
    LONGLONG            wRebuyFee;                          //重购费用
    DWORD               wRebuyCount;                        //重购所获得的筹码
    WORD                wAddOnTimes;                        //增购次数限制
    WORD                wAddOnMinLevel;                     //增购最小盲注等级
    WORD                wAddOnMaxLevel;                     //增购最大盲注等级
    LONGLONG            wAddOnFee;                          //增购费用
    DWORD               wAddOnCount;                        //增购所获得的筹码
    WORD                wState;                             //0：报名阶段 1：进入阶段
    DWORD               StartTime;                          //比赛开始时间
    WORD                CycleTime;                          //比赛循环时间（秒）
    DWORD               dwRegistrationStartTime;            //报名开始时间（秒）
    DWORD               dwRegistrationEndTime;              //报名截至时间（秒）
    WORD                wJoinUserCount;                     //参与的玩家
    bool                bJoin;                              //您是否参与
}CMD_MB_LoadTexasHoldemMatchResponse;

//加载自己参与比赛结果
typedef struct 
{
    bool                bStart;
    bool                bEnd;
    WORD                wMatchID;                           //比赛ID
    WORD                wServerID;                          //服务器ID
    WORD                wSortID;
    CHAR                szMatchName[32 * 2];        //比赛名称
    WORD                wMatchType;                         //赛事类型 0定时赛 1人满赛
    WORD                wAwardType;                         //奖励类型 0固定奖励 1滚雪球
    LONGLONG            lTotalAward;                        //奖励总和
    DWORD               dwMinUserCount;                     //最小参赛人数
    DWORD               dwMaxUserCount;                     //最大参赛人数
    LONGLONG            lRegistrationFee;                   //报名费
    LONGLONG            lServiceFee;                        //服务费
    LONGLONG            lInitChip;                          //玩家初始筹码
    LONGLONG            lLoseCip;                           //玩家淘汰筹码
    WORD                wRebuyTimes;                        //重购次数限制
    WORD                wRebuyMinLevel;                     //重购最小盲注等级
    WORD                wRebuyMaxLevel;                     //重购最大盲注等级
    LONGLONG            wRebuyFee;                          //重购费用
    DWORD               wRebuyCount;                        //重购所获得的筹码
    WORD                wAddOnTimes;                        //增购次数限制
    WORD                wAddOnMinLevel;                     //增购最小盲注等级
    WORD                wAddOnMaxLevel;                     //增购最大盲注等级
    LONGLONG            wAddOnFee;                          //增购费用
    DWORD               wAddOnCount;                        //增购所获得的筹码
    WORD                wState;                             //0：报名阶段 1：进入阶段
    DWORD               StartTime;                          //比赛开始时间
    WORD                CycleTime;                          //比赛循环时间（秒）
    DWORD               dwRegistrationStartTime;            //报名开始时间（秒）
    DWORD               dwRegistrationEndTime;              //报名截至时间（秒）
    WORD                wJoinUserCount;                     //参与的玩家
}CMD_MB_LoadTexasHoldemJoinMatchResponse;

//加载某个比赛的盲注信息
typedef struct 
{
    bool                bStart;
    bool                bEnd;                         
    WORD                wMatchID;                           //比赛ID
    WORD                wLevel;                             //盲注等级
    LONGLONG            lBigBlind;                          //大盲注
    LONGLONG            lSmallBlind;                        //小盲注
    LONGLONG            lAnte;                              //前注
    DWORD               dwGrowthTime;                       //增长时间（秒）
}CMD_MB_LoadTexasHoldemBlindResponse;

//加载某个比赛的固定奖励信息
typedef struct 
{
    bool                bStart;
    bool                bEnd;
    WORD                wMatchID;                           //比赛ID
    WORD                wRank;                              //盲注等级
    LONGLONG            lAward;                             //大盲注
}CMD_MB_LoadTexasHoldemFixedBonusResponse;

//加载玩家参赛纪录
typedef struct 
{
    bool                bStart;
    bool                bEnd;
    DWORD               dwPeriodID;                         //比赛ID
    WORD                wMatchID;                           //比赛ID
    CHAR                szMatchName[32 * 2];
    LONGLONG            lAward;                             //奖励
    SYSTEMTIME          StartTime;
}CMD_MB_LoadTexasHoldemMatchRecordResponse;

//加载玩家参赛结果
typedef struct 
{
    bool                bStart;
    bool                bEnd;
    DWORD               dwPeriodID;
    DWORD               dwUserID;
    CHAR                szNickName[32 * 2];
    WORD                wRank;
    LONGLONG            lScore;
}CMD_MB_LoadTexasHoldemMatchResultResponse;


//参与比赛请求
typedef struct 
{
    WORD                wMatchID;                           //比赛ID
    WORD                wServerID;                          //服务器ID
    LONG                lResultCode;                        //返回值
    CHAR                szDescribeString[128];              //描述消息
}CMD_MB_JoinTexasHoldemMatchResponse;

//退出比赛请求
typedef struct 
{
    WORD                wMatchID;                           //比赛ID
    WORD                wServerID;                          //服务器ID
    LONG                lResultCode;                        //返回值
    CHAR                szDescribeString[128];              //描述消息
}CMD_MB_QuitTexasHoldemMatchResponse;

//======

//进入游戏等待比赛开始
typedef struct
{
    DWORD                            dwTimeRemaining;            //剩余时间
}CMD_GR_TexasHoldem_Waiting;

//等待其他玩家结束
typedef struct
{
    DWORD                            dwTimeRemaining;            //剩余时间
}CMD_GR_TexasHoldem_Waiting_Other_Player;


//重购筹码请求
typedef struct
{
    WORD                            lChip;                            //购买数量，如果不是免费赛这个值不用填
}CMD_GR_TexasHoldem_Rebuy_Request ;

//重购筹码应答
typedef struct
{
    DWORD                            lResultCode;                    //购买返回值
    WORD                            lChip;                            //购买数量
    WORD                            lRemainTimes;                    //剩余购买次数
}CMD_GR_TexasHoldem_Rebuy_Response;

//增购筹码请求
typedef struct
{
    WORD                            lChip;                            //购买数量，如果不是免费赛这个值不用填
}CMD_GR_TexasHoldem_Addon_Request;

//增购筹码应答
typedef struct
{
    DWORD                            lResultCode;                    //购买返回值
    WORD                            lChip;                            //购买数量
    WORD                            lRemainTimes;                    //剩余购买次数
}CMD_GR_TexasHoldem_Addon_Response;

//加载信息
typedef struct
{
    LONGLONG                        lInitChip;                        //初始筹码信息
    WORD                            wRebuyTimes;                    //最大重购次数
    WORD                            wRebuyMinLevel;                    //重购最小等级
    WORD                            wRebuyMaxLevel;                    //重购最大等级
    LONGLONG                            wRebuyFee;                        //重购花费的欢乐豆
    DWORD                            wRebuyCount;                    //重购获得的筹码
    WORD                            wAddonTimes;                    //最大增购次数
    WORD                            wAddonMinLevel;                    //增购最小等级
    WORD                            wAddonMaxLevel;                    //增购最大等级
    LONGLONG                            wAddOnFee;                        //增购花费的欢乐豆
    DWORD                            wAddOnCount;                    //增购获得的筹码
}CMD_GR_TexasHoldem_Info;

//更新筹码
typedef struct
{
    WORD       wLevel;    //盲注等级
    LONGLONG      lBigBlind;   //大盲注
    LONGLONG      lSmallBlind;  //小盲注（底注）
    LONGLONG      lAnte;    //前注
    DWORD       dwGrowthTime;  //增长到下一个盲注等级的时间（秒）
    DWORD       dwTotalUserCount;   //总人数
    DWORD       dwUserCount;    //当前人数
    LONGLONG      lAverageChip;    //平均筹码
    
}CMD_GR_TexasHoldem_UpdateBlindLevel;

typedef struct
{
    DWORD                            dwRank;                        //排名
    DWORD                            dwTotalRank;                //总排名
    DWORD                            dwUserCount;                //当前人数
    DWORD                            dwTotalUserCount;            //总人数
    DWORD                            dwAwardCount;                //奖励人数
    DWORD                            dwTotalAwardCount;            //总奖励人数
    
    DWORD                            dwUpdateBlindTime;            //升盲剩余时间
    DWORD                            dwCurrentBlindLevel;        //当前级别
    LONGLONG                        lBigBlind;                    //大盲注
    LONGLONG                        lSmallBlind;                //小盲注
    LONGLONG                        lAnte;                        //前注
    LONGLONG                        lNextBigBlind;                //下一级别大盲注
    LONGLONG                        lNextSmallBlind;            //下一级别小盲注
    LONGLONG                        lNextAnte;                    //下一级别前注
    
    DWORD                            dwElapsedTime;                //增当前耗时
    LONGLONG                        lAverageChip;                //平均筹码
    LONGLONG                        lTotalChip;                    //筹码总数
}CMD_GR_TexasHoldem_MatchDetailInfo;

typedef struct
{
    DWORD       dwRank;      //排名
    
}CMD_GR_TexasHoldem_MatchOver;

//更新筹码
typedef struct
{
    WORD       wLevel;    //盲注等级
    LONGLONG      lBigBlind;   //大盲注
    LONGLONG      lSmallBlind;  //小盲注（底注）
    LONGLONG      lAnte;    //前注
    DWORD       dwGrowthTime;  //增长到下一个盲注等级的时间（秒）
    
}CMD_GR_TexasHoldem_NextBlindLevel;

//玩家结束比赛推送消息 struct  
typedef struct
{
    DWORD           dwID; 
    CHAR            szNickName[64]; //玩家名称
    CHAR            szMatchName[64]; //比赛名称
    WORD            wMatchID;      //比赛ID
    DWORD           dwRank;       //排名
    LONGLONG        lScore;       //分数
    LONGLONG        lTotalScore;     //总分数
    WORD            wType;       //比赛类型 0定时赛 1人满赛
    SYSTEMTIME      StartTime;      //比赛开始时间 
}CMD_GR_TexasHoldem_PushMessage;

#pragma pack(pop)
