#pragma pack(1)

typedef struct {
	WORD							wIndex;								//道具标识
	WORD							wDiscount;							//会员折扣
	WORD							wIssueArea;							//发布范围

	SCORE							lPropertyGold;						//道具金币
	DOUBLE							dPropertyCash;						//道具价格

	SCORE							lSendLoveLiness;					//赠送魅力
	SCORE							lRecvLoveLiness;					//接受魅力
}tagPropertyInfo;

//道具属性
typedef struct {
	WORD							wIndex;								//道具标识
	WORD                            wPropertyType;                      //道具类型
	WORD							wServiceArea;						//使用范围
	TCHAR                           szMeasuringunit[8];					//计量单位
	TCHAR							szPropertyName[32];					//道具名字
	TCHAR							szRegulationsInfo[256];				//使用信息
}tagPropertyAttrib;

//道具子项
typedef struct {
	tagPropertyInfo					PropertyInfo;						//道具信息
	tagPropertyAttrib				PropertyAttrib;						//道具属性
}tagPropertyItem;

#pragma pack()

