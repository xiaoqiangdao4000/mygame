#pragma pack(1)

typedef struct {
    int nOp;//1申请上庄，2申请下庄，3申请抢庄
}CMD_C_FQZS_Request_Banker;

typedef struct {
    int nJettonArea;
    SCORE lBet;
}CMD_C_FQZS_Jetton;

typedef struct {
    BYTE cbStatus;
    BYTE cbLeftTime;
}CMD_S_FQZS_Refresh_Status;

typedef struct {
    int nRet;//0成功，-1已经在队列, -2金币不够,-3已经有人抢庄了,-4你已经在坐庄了
    int nTotal; //申请总数
    WORD wChairID;
    int nOp;
}CMD_S_FQZS_Request_Banker;

typedef struct {
    int nJettonArea;//下注区域
    WORD wChairID;
    SCORE lBet;//下注的量
    SCORE lTotalJetton;//这个区域的总注
    SCORE lAreaInvalid[11];//11门的投注上限
    int nRet; //0成功，-1下注已经到达上限
}CMD_S_FQZS_Jetton;

//游戏结束
typedef struct {
    SCORE                           lMePlayScore;     
    SCORE                           lBankPlayScore;  
    SCORE                           lOtherAllWinPlayScore;         //所有玩家的成绩
    BYTE                            cbAwardArea;
    BYTE                            cbAwardAreaIndex;                   //中奖小类
    BYTE                            cbEnough;                           //通赔的情况下是否有足够的钱赔偿提示，1提示0不要提示
}CMD_S_FQZS_GameEnd;

//场景协议
typedef struct {
    BYTE                            cbTimeLeave;                        //剩余时间
    BYTE                            cbGameStatus;                       //游戏状态
    //全局下注
    LONGLONG                        lAllJettonScore[14];      //全体总注
    //庄家信息
    WORD                            wBankerUser;                        //当前庄家
    SCORE                           lBankerScore;                       //庄家分数
    //结束信息  
    SCORE                           lMePlayScore;  
    SCORE                           lBankPlayScore;  
    SCORE                           lOtherAllWinPlayScore;
    BYTE                            cbHistory[20];                      //历史中奖
    SCORE                           lMaxScore; //最大下注上限 
    SCORE                           lRequestBankerCoin; //上庄条件
    int                             nBankerPlayTimes;//庄家连庄了多少局 
    LONGLONG                        lJettonScore[14];  //个人各个区域下注
    BYTE                            cbAwardArea;                        //中奖大类  
    BYTE                            cbAwardAreaIndex;                   //中奖小类
    WORD                            wServerID;
    SCORE                           lJettonChoice[6];                   //可下注的选项
    SCORE                           lQiangZhuangCoin;                    //抢庄价格
    SCORE                           lQiangZhuangMinCoin;                 //抢庄条件
}CMD_S_FQZS_StatusGame;

//游戏开始协议
typedef struct {
    int                         nRequestBankerCount;                //请求上庄人数
    SCORE                       lMaxScore;                          //最大下注上限个人 
    int                         nBankerPlayTimes;                   //庄家连庄了多少局  
}CMD_S_FQZS_GameStart;

typedef struct {  
    int nCurPose;  
    int nTotal; 
}CMD_S_FQZS_Refresh_List;

typedef struct {
    int          nBankerUser;         //庄家位置  
    SCORE      lBankerScore;         //庄家金币 
}CMD_S_FQZS_Update_Banker;

#pragma pack()

