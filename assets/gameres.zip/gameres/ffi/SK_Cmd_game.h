#pragma pack(1)

typedef struct {
	BYTE b;
}SK_tagMatchTopTen;
typedef struct {
	BYTE Serial[33];
}SK_tagClientSerial;
//调试显示
typedef struct {
	WORD wChairID;
	UINT nCardCount;
	BYTE byCardData[27];
}CMD_S_SK_ShowCard;

//调试换牌
typedef struct {
	WORD wChairID;
	UINT nCardCount;
	BYTE byCardData[27];
}CMD_S_SK_ChangeCard;

//游戏状态
typedef struct {
	WORD								wBankerUser;						//庄家用户
	WORD				 				wCurrentUser;						//当前玩家
	int								lCellScore;							//基础积分
	SK_tagMatchTopTen						TopTen;								//前十名
}CMD_S_SK_StatusFree;

typedef struct {
	LONGLONG								lCellScore;						//单元下注
	int										nTimes[2];			//当前倍数
	LONGLONG								lGongXian;						//用户分数上限

	WORD				 					wCurrentUser;					//当前玩家
	BYTE									cbPlayStatus[2];		//游戏状态

	BYTE									byCardData[27];			//扑克数据
	UINT									nCardCount[2];		//牌数量
	WORD									wOutCardUser;					//出牌玩家
	UINT									nOutCardCount;					//出牌数目
	BYTE									byOutCardData[27];		//出牌数据
	SK_tagMatchTopTen							TopTen;							//前十名
}CMD_S_SK_StatusPlay;

typedef struct {
	int								lMaxScore;							//最大下注
	LONGLONG							lCellScore;							//单元下注

	WORD								wBankerUser;						//庄家用户
	WORD				 				wCurrentUser;						//当前玩家
	BYTE								byFirstCard;						//随机牌
	BYTE								byCardCount;						//牌数量
	BYTE								byCardData[27];				//牌数据
}CMD_S_SK_GameStart;

//发牌完成消息
typedef struct {
	WORD wCurrentUser;//首先出牌玩家
	BYTE byCardData;//首张牌
}CMD_S_SK_SendCard;

//用户出牌
typedef struct {
	bool								bIsGameEnd;							//游戏是否结束
	WORD								wCurrentUser;						//当前用户
	WORD								wOutCardUser;						//出牌用户
	int									nTimes[2];				//当前倍数
	LONGLONG							lGongxian;							//贡献分
	UINT								nCardCount;							//出牌数目
	BYTE								byCardData[27];				//牌数据
}CMD_S_SK_OutCard;

//玩家过牌
typedef struct {
	WORD wCurrentUser;
	WORD wPassCardUser;
}CMD_S_SK_PassCard;

//游戏结束
typedef struct {
	WORD								wWinner;							//赢家
	LONGLONG							lGongxian[2];			//贡献
	int									nTimes[2];//倍数
	LONGLONG							lGameTax;							//游戏税收
	LONGLONG							lGameScore[2];			//游戏得分
	UINT								nCardCount;							//牌数目
	char								szName[2][32*2];		//用户名字
	BYTE								byCardData[27];				//用户扑克
}CMD_S_SK_GameEnd;

//游戏结束
typedef struct {
	WORD								wWinner;							//赢家
	LONGLONG							lGongxian[2];			//贡献
	int									nTimes[2];//倍数
	LONGLONG							lGameTax;							//游戏税收
	LONGLONG							lGameScore[2];			//游戏得分
	UINT								nCardCount;							//牌数目
	char								szName[2][64];		//用户名字
	BYTE								byCardData[27];				//用户扑克
}CMD_S_SK_GameEnd_Mobile;

//玩家名次
typedef struct {
	SK_tagMatchTopTen TopTen;//前十名
}SK_CMD_S_UserRank;

//用户加注
typedef struct {
	WORD								wCurrentUser;								//出牌玩家
	UINT								nCardCount;									//牌数量
	BYTE								byCardData[27];						//牌数据
}CMD_C_SK_OutCard;

//比牌数据包
typedef struct {	
	WORD								wCompareUser;						//比牌用户
}CMD_C_SK_PassCard;

//语音消息
typedef struct {
	int					nIndex;
	WORD				wChairID;
}CMD_C_SK_YuYin;

//托管
typedef struct {
	WORD wChairID;
	bool bTrustee;
}CMD_C_SK_Trustee;

//用户下注
typedef struct {
	bool						bManageControl;							//是否控制
	BYTE						cbControlArea;							//区域控制
	SK_tagClientSerial				ClientSerial;							//机器序列号
}CMD_C_SK_ManageControl;

typedef unsigned long long  ULONGLONG;

#pragma pack()

