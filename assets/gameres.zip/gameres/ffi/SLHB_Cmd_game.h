#pragma pack(1)

typedef struct
{
    SCORE   lScore;
    BYTE    cbSplitCount;
    BYTE    cbLeidian;
}SLHB_CMD_C_SEND_REDPACKECT;

typedef struct
{
    SCORE lRpID;
}SLHB_CMD_C_RECEIVE_REDPACKECT;

typedef struct
{
    SCORE lScore; //身上还有多少钱
    int nRet; //成功或者失败
}SLHB_CMD_S_SEND_REDPACKECT;

typedef struct
{
    SCORE lScore; //身上还有多少钱
    SCORE lCaijin;//获取的彩金
    int nAutoCount;//还剩多少自动红包
    BYTE cbSplitCount;
    BYTE cbLeidian;
    int nRet; //成功或者失败
}SLHB_CMD_S_SEND_REDPACKECT_EX;

typedef struct
{
    int nRet;//成功或者失败
    SCORE lGet; //得到的钱
    SCORE lGive; //踩雷送出的钱
    SCORE lRpID; //红包ID
    SCORE lScore; //身上还有多少钱
}SLHB_CMD_S_RECEIVE_REDPACKECT;

typedef struct
{
    int nRet;//成功或者失败
    SCORE lGet; //得到的钱
    SCORE lGive; //踩雷送出的钱
    SCORE lRpID; //红包ID
    SCORE lScore; //身上还有多少钱
    SCORE lCaijin;//获取的彩金
    SCORE lTax;//纳税
}SLHB_CMD_S_RECEIVE_REDPACKECT_EX;

typedef struct
{
    DWORD dwUserID;
    SCORE lGet;
    SCORE lGive;
}ReceiveInfo;

typedef struct
{
    DWORD dwUserID;
    SCORE lGet;
    SCORE lGive;
}tinfo;

//被领取完后的广播
typedef struct
{
    SCORE lRpID; //红包ID
    int nCount;
    ReceiveInfo info[4];
}SLHB_CMD_S_BROADCASTREDPACKET;

typedef struct
{
    SCORE lRpID;
    DWORD dwUserID;
    TCHAR szName[32]; //昵称
    SCORE lTotalScore;
    BYTE cbSplitCount;
    BYTE cbReceviedCount;
    BYTE cbLeidian;
    int fmultiple;
    int nCreatTime;
    int nFaceID;
    int nGender;
}tRedPackect;

typedef struct
{
    int nCount;
    tRedPackect redPackectList[10];
}SLHB_CMD_S_GET_REDPACKECTLIST;

typedef struct
{
    int nCount;
    SCORE lCaichi;
    SCORE lScore;
    int  nSplitCount;//5-10,  -1随机
    int  nLeidian;   //0-10， -1随机
    int nSendCount; // >0，  -1随机
    int nLeftCount; // >0，  -1随机
    SCORE lBetScore[4];
    tRedPackect redPackectList[10];
}SLHB_CMD_S_GET_REDPACKECTLIST_EX;

typedef struct
{
    SCORE lTotal;
    int nRet;//1被领完了，2有人踩了你的雷
}SLHB_CMD_S_REDPACKET_INFO;

typedef struct
{
  BYTE cbType;//0全部可见 1仅显示可抢红包 2指定范围
  SCORE lUp;
  SCORE lDown;
}SLHB_CMD_C_SETCONFIG;

typedef struct
{
  BYTE cbResult;//0成功 1参数不合法
  BYTE cbType;//0全部可见 1仅显示可抢红包 2指定范围
  SCORE lUp;
  SCORE lDown;
}SLHB_CMD_S_SETCONFIG;

//自动发包 请求
typedef struct 
{
    SCORE lScore;
    int nSplitCount;//5-10,  -1随机
    int nLeidian;   //0-10， -1随机
    int nSendCount; // >0，  -1一直发
}SLHB_CMD_C_AUTO_SEND;

//自动发包 返回
typedef struct
{
    SCORE lScore;
    int nSplitCount;//5-10,  -1随机
    int nLeidian;   //0-10， -1随机
    int nSendCount; // >0，  -1随机
}SLHB_CMD_S_AUTO_SEND;

//刷新彩池
typedef struct
{
    SCORE lScore;
}SLHB_CMD_S_REFRESH_CAICHI;

#pragma pack()

