#pragma pack(push)
#pragma pack(1)

//游戏状态
typedef struct
{
	LONGLONG			lCellScore;
	LONGLONG			lTotalWinScore;									//累计赢分
	BYTE				cbCardArray[240];							//牌型数据
	int					nCookies;										//剩余钻头数量
	WORD				wBetMultiple[12];								//可下注的筹码
	INT					nFreeTimes;										//剩余免费次数
	LONGLONG			lMiniJackpot;									//奖池
	LONGLONG			lMinorJackpot;									//奖池
	LONGLONG			lMajorJackpot;									//奖池
	LONGLONG			lGrandJackpot;									//奖池
}TGPD_CMD_S_Status;

//用户下注
typedef struct
{
	BYTE				cbCardArray[240];//牌型数据
	LONGLONG			lWinScore;//开奖赢分
	LONGLONG			lTotalWinScore;//累计赢分
	int					nCookies;//剩余钻头数量
	LONGLONG			lJettonScore;//下注分数
	LONGLONG   lJettonScoreEx;         //下注分数  
	LONGLONG			lJackpot;//中奖池分数
	INT					nFreeTimes;										//剩余免费次数
}TGPD_CMD_S_Bet;

//奖池更新
typedef struct
{
	DWORD    				dwUserID;
	LONGLONG			lMiniJackpot;
	LONGLONG			lMinorJackpot;
	LONGLONG			lMajorJackpot;
	LONGLONG			lGrandJackpot;
}TGPD_CMD_S_BroadcastJackpot;

//广播中高倍奖
typedef struct
{
	TCHAR				szNickName[32];						//中奖用户
	TCHAR				szServerName[32];						//房间名称
	LONGLONG			lJackpot;										//中了奖池
	LONGLONG			lWinScore;										//中了高倍奖
}TGPD_CMD_S_BroadcastAwards;
//////////////////////////////////////////////////////////////////////////
//客户端命令结构
//水浒传游戏
typedef struct
{
	WORD				wMultiple;										//下注倍数
	WORD				wLine;											//下注线数
}TGPD_CMD_C_Bet;
//////////////////////////////////////////////////////////////////////////

#pragma pack(pop)
