#pragma pack(1)

//记录信息
typedef struct {
    bool							bWinTianMen;						//顺门胜利
    bool							bWinDiMen;							//对门胜利
    bool							bWinXuanMen;						//倒门胜利
    bool							bWinHuangMen;						//倒门胜利
}BRNN_tagClientGameRecord;

//记录信息
typedef struct {
    bool							bWinTian;						//顺门胜利
    bool							bWinDi;							//对门胜利
    bool							bWinXuan;							//倒门胜利
    bool							bWinHuang;							//倒门胜利
}BRNN_tagServerGameRecord;

//更新库存
typedef struct {
    LONGLONG						lStorage;							//新库存值
    LONGLONG						lStorageDeduct;						//库存衰减
}BRNN_CMD_S_UpdateStorage;

typedef struct {
    BYTE cbAckType;					//回复类型
    BYTE cbResult;
    BYTE cbExtendData[20];			//附加数据
}BRNN_CMD_S_CommandResult;

//失败结构
typedef struct {
    WORD							wPlaceUser;							//下注玩家
    BYTE							lJettonArea;						//下注区域
    LONGLONG						lPlaceScore;						//当前下注
}BRNN_CMD_S_PlaceJettonFail;

typedef struct {
    WORD							wChairID;							//椅子号码
    LONGLONG							lScore;								//玩家积分

    WORD							wCurrentBankerChairID;				//当前庄家
    BYTE							cbBankerTime;						//庄家局数
    LONGLONG							lCurrentBankerScore;				//庄家分数
}BRNN_CMD_S_ChangeUserScore;

//申请庄家
typedef struct {
    WORD							wApplyUser;							//申请玩家
}BRNN_CMD_S_ApplyBanker;

//取消申请
typedef struct {
    WORD			wCancelUser;					//取消玩家
}BRNN_CMD_S_CancelBanker;

//切换庄家
typedef struct {
    WORD							wBankerUser;						//当庄玩家
    LONGLONG						lBankerScore;						//庄家游戏币
}BRNN_CMD_S_ChangeBanker;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    LONGLONG						lUserMaxScore;						//玩家欢乐豆

    WORD							wBankerUser;						//当前庄家
    WORD							cbBankerTime;						//庄家局数
    LONGLONG						lBankerWinScore;					//庄家成绩
    LONGLONG						lBankerScore;						//庄家分数
    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制
    LONGLONG                        lQiangConition;
    LONGLONG                        lQiangScore;

    DWORD                           dwServerID;
}BRNN_CMD_S_StatusFree;

typedef struct {
    TCHAR                           szUserName[32];
    LONGLONG                        lWInScore;
}BRNN_tagRankUser;

typedef struct {
    LONGLONG						lAllJettonScore[4+1];		//全体总注

    LONGLONG						lUserJettonScore[4+1];		//个人总注

    LONGLONG						lUserMaxScore;						//最大下注

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制
    LONGLONG                        lQiangConition;
    LONGLONG                        lQiangScore;

    BYTE							cbTableCardArray[5][5];				//桌面扑克

    WORD							wBankerUser;						//当前庄家
    WORD							cbBankerTime;						//庄家局数
    LONGLONG						lBankerWinScore;					//庄家赢分
    LONGLONG						lBankerScore;						//庄家分数
    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lEndBankerScore;					//庄家成绩
    LONGLONG						lEndUserScore;						//玩家成绩
    LONGLONG						lEndUserReturnScore;				//返回积分
    LONGLONG						lEndRevenue;						//游戏税收

    BYTE							cbTimeLeave;						//剩余时间
    BYTE							cbGameStatus;						//游戏状态

    DWORD                           dwServerID;

    BYTE                            cbRankCount;
    BRNN_tagRankUser                     RankUser[5];
    SCORE                           lAreaScore[4];
}BRNN_CMD_S_StatusPlay;

//游戏空闲
typedef struct {
    BYTE							cbTimeLeave;						//剩余时间
    LONGLONG                           nListUserCount;						//列表人数
    LONGLONG						lStorageStart;						//
}BRNN_CMD_S_GameFree;

//游戏开始
typedef struct {
    WORD							wBankerUser;						//庄家位置
    LONGLONG						lBankerScore;						//庄家游戏币
    LONGLONG						lUserMaxScore;						//我的游戏币
    BYTE							cbTimeLeave;						//剩余时间
    bool							bContiueCard;						//继续发牌
    int								nChipRobotCount;					//人数上限 (下注机器人)
}BRNN_CMD_S_GameStart;

//用户下注
typedef struct {
    WORD							wChairID;							//用户位置
    BYTE							cbJettonArea;						//筹码区域
    LONGLONG						lJettonScore;						//加注数目
    bool							bIsAndroid;							//是否机器人
    bool							bAndroid;						//机器标识
}BRNN_CMD_S_PlaceJetton;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    BYTE							cbTableCardArray[5][5];				//桌面扑克
    BYTE							cbLeftCardCount;					//扑克数目

    BYTE							bcFirstCard;

    LONGLONG						lBankerScore;						//庄家成绩
    LONGLONG						lBankerTotallScore;					//庄家成绩
    INT								nBankerTime;						//做庄次数

    LONGLONG						lUserScore;							//玩家成绩
    LONGLONG						lUserReturnScore;					//返回积分

    LONGLONG						lRevenue;							//游戏税收

    BYTE                            cbRankCount;                        //结算实际人数
    BRNN_tagRankUser                     RankUser[5];                        //结算玩家结果

    LONGLONG                        lAreaScore[4];             //区域分数
}BRNN_CMD_S_GameEnd;

//控制区域信息
typedef struct {
    BYTE cbControlArea[3];			//控制区域
}BRNN_tagControlInfo;

typedef struct {
    BYTE							m_cbExcuteTimes;					//执行次数
    BYTE							m_cbControlStyle;					//控制方式
    bool							m_bWinArea[3];						//赢家区域
}BRNN_tagAdminReq;

typedef struct {
    BYTE cbReqType;
    BYTE cbExtendData[20];			//附加数据
}BRNN_CMD_C_AdminReq;
//用户下注
typedef struct {
    BYTE							cbJettonArea;						//筹码区域
    LONGLONG						lJettonScore;						//加注数目
}BRNN_CMD_C_PlaceJetton;

//更新库存
typedef struct {
    BYTE                            cbReqType;						//请求类型
    LONGLONG						lStorage;						//新库存值
    LONGLONG						lStorageDeduct;					//库存衰减
}BRNN_CMD_C_UpdateStorage;

#pragma pack()
