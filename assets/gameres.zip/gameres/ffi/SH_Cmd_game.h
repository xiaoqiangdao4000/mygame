#pragma pack(1)

typedef struct {
    LONGLONG								lCellScore;							//基础积分
    BYTE									lHandCard;							//几张能梭
    BYTE									lGameType;							//游戏类型
    LONGLONG								lTurnScore[2];			//积分信息
    LONGLONG								lCollectScore[2];			//积分信息
}SH_CMD_S_StatusFree;

typedef struct {
    BYTE								bShowHand;							//梭哈标志
    BYTE								bAddScore;							//加注标志

    LONGLONG								lMaxScore;							//最大下注
    LONGLONG								lCellScore;							//单元下注
    LONGLONG								lTurnMaxScore;						//最大下注
    LONGLONG								lTurnLessScore;						//最小下注

    WORD				 				wCurrentUser;						//当前玩家
    BYTE								cbPlayStatus[2];			//游戏状态
    LONGLONG						lTableScore[2*2];			//下注数目

    BYTE								cbCardCount[2];			//扑克数目
    BYTE								cbHandCardData[2][5];		//桌面扑克
    BYTE								lHandCard;							//几张能梭
    BYTE								lGameType;							//游戏类型
    BYTE								cbUsrCount;
    LONGLONG								lTurnScore[2];			//积分信息
    LONGLONG								lCollectScore[2];			//积分信息
    bool                                bCanShowHand;

}SH_CMD_S_StatusPlay;

typedef struct {
    LONGLONG								lMaxGold;							//最大下注
    LONGLONG								lBasicGold;							//单元下注
    LONGLONG								lTurnMaxGold;						//最大下注
    LONGLONG								lTurnBasicGold;						//最小下注
    BYTE									lHandCard;							//几张能梭
    BYTE									lGameType;							//游戏类型
    BYTE                                    cbUsrCount;

    WORD				 					wCurrentUser;						//当前玩家

    BYTE										cbObscureCard;						//底牌扑克
    BYTE										bCardData[2];			//用户扑克
    BYTE                                        cbCardDataToAndRoid[2][5];
    bool                                    bProSet;
}SH_CMD_S_GameStart;

//用户下注
typedef struct {
    WORD								wCurrentUser;						//当前用户
    WORD								wLastChairID;						//加注用户
    LONGLONG								lLastAddGold;						//加注数目
    LONGLONG								lCurrentLessGold;						//最少加注
    BYTE                                cbTimes;
}SH_CMD_S_AddScore;

//用户放弃
typedef struct {
    WORD								wUserChairID;						//放弃用户
    BYTE cbObscureCard; //底牌扑克
}SH_CMD_S_GiveUp;

//发牌数据包
typedef struct {
    WORD								wCurrentUser;						//当前用户
    WORD								wStartChairId;						//上次最大用户
    LONGLONG								lMaxGold;						//最大下注
    LONGLONG								lTurnLessScore;						//最小下注
    BYTE								cbSendCardCount;					//发牌数目
    BYTE								bUserCard[2][2];			//用户扑克
}SH_CMD_S_SendCard;

//游戏结束
typedef struct {
    LONGLONG								lGameTax[2];				//游戏税收
    LONGLONG								lGameGold[2];			//游戏得分
    BYTE								bUserCard[2];			//用户扑克
}SH_CMD_S_GameEnd;

typedef struct {
    LONGLONG								lUserCount;							//用户数目
    LONGLONG								lBlackCount;						//用户数目

    LONGLONG								lMaxScore;							//最大变化
    LONGLONG								lMaxWinScore;						//最大赢分
    LONGLONG								lMaxLoseScore;						//最大输分
}SH_CMD_S_ScoreOption;
//看牌
typedef struct {
    int								dwUserID;
    BYTE cbObscureCard; //底牌扑克
}SH_CMD_S_LookCard;
typedef struct {
    BYTE cbCard;
    BYTE cbIndex;
}SH_CMD_S_KongZhi;

//用户加注
typedef struct {
    LONGLONG                                nServriValue;
    LONGLONG								lScore;								//加注数目
    BYTE								    cbTimes;								//倍数
}SH_CMD_C_AddScore;

//获取胜者
typedef struct {
    int								dwUserID;							//用户标识
}SH_CMD_C_GetWinner;

//积分信息
typedef struct {
    LONGLONG								lScore;								//积分信息
}SH_CMD_C_ScoreInfo;

//用户信息
typedef struct {
    int								dwUserID;							//用户标识
}SH_CMD_C_UserIDInfo;

//看牌
typedef struct {
    int								dwUserID;
}SH_CMD_C_LookCard;

typedef struct {
    BYTE cbCard;
    LONGLONG nServalValue;
}SH_CMD_C_KongZhi;

#pragma pack()
