#pragma pack(push)
#pragma pack(1)

typedef struct {
    DWORD dwUserId;
    DWORD dwCatchFishCount;
    DWORD dwCatchScore;
    DWORD dwRanking;
    TCHAR szNickName[32];

}FISHINGJOY_CompetitionRanking;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
}FISHINGJOY_CMD_S_SCORE_SYNC;

typedef struct {
    DWORD dwRanking;
    LONG  lScore;
    LONG  lCatchScore;
}FISHINGJOY_CMD_S_MATCH_END;

typedef struct {
    WORD wChairId;
    DWORD dwRanking;
    LONG  lScore;
    DWORD MatchUserCount;
    LONG  lMaxScore;
}FISHINGJOY_CMD_S_CUR_RANKING;

typedef struct {
    DWORD dwUserId;
    DWORD dwCatchFishCount;
    DWORD dwCatchScore;
    DWORD dwRanking;
    LONG  lScore;
    TCHAR szNickName[32];
}FISHINGJOY_CMD_S_UPDATE_RANKING;

typedef struct {
    DWORD	nFishID;
    int		nMul;
}FISHINGJOY_CMD_S_FISHINGJOY_MUL;

typedef struct {
    TCHAR	szFishName[256];
    int		nActivityTime;
    bool	bStart;
}FISHINGJOY_CMD_S_ACTIVITY_NOTIFY;

typedef struct {
    int		nBufferType;
    float	fBufferParam;
    float	fBufferTime;
}FISHINGJOY_CMD_S_ADD_BUFFER;

typedef struct {
    int						nMulriple;
    int						nSpeed;
    int						nMaxCatch;
    int						nBulletSize;
    int						nCatchRadio;
    int						nCannonType;
    bool					bFirst;
}FISHINGJOY_CMD_S_BULLET_SET;

typedef struct {
    int			nCount;
    TCHAR		szDes[4][256];
}FISHINGJOY_CMD_S_SEND_DES;

typedef struct {
    WORD	wChairID;
    DWORD	dwLockID;
}FISHINGJOY_CMD_S_LOCK_FISH;

typedef struct {
    int		FishCount;
    float	dir;
}FISHINGJOY_AndroidUpdata;

typedef struct {
    bool	m_bAllowFire;
}FISHINGJOY_CMD_S_ALLOW_FIRE;

typedef struct {
    int		nst;
    bool	bSwitching;
}FISHINGJOY_CMD_S_SWITCH_SCENE;

typedef struct {
    WORD		wChairID;
    DWORD		dwBulletID;
}FISHINGJOY_CMD_S_KILL_BULLET;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
    DWORD		dwFishID;
    int			nBScoe;
    DWORD  dwBulletID;
}FISHINGJOY_CMD_S_KILL_FISH;

typedef struct {
    DWORD		dwID;
    WORD		wChairID;
    DWORD		dwCreateTick;
    float		fXpos;
    float		fYPos;
    int			nCannonType;
    int			nMultiply;
    LONGLONG	lScore;
    float		fDirection;
    bool		bNew;
    DWORD		dwServerTick;
    bool		IsDouble;
}FISHINGJOY_CMD_S_SEND_BULLET;

typedef struct {
    WORD		wChairID;
    int			cannonType;
    int			cannonMul;
    int			cannonSet;
}FISHINGJOY_CMD_S_CANNON_SET;

typedef struct {
    WORD		wChairID;
    LONGLONG	lFishScore;
    LONGLONG	lWastageScore;
}FISHINGJOY_CMD_S_CHANGE_SCORE;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
    int			nCannonType;
    int			nCannonMul;
    LONGLONG	lWastage;
}FISHINGJOY_CMD_S_USER_INFO;

typedef struct {
    DWORD	dwFishID;
    int		nTypeID;
    int		nPathID;
    DWORD	dwCreateTick;
    float	fOffestX;
    float	fOffestY;
    float	fDir;
    float	fDelay;
    DWORD	dwServerTick;
    float	FishSpeed;
    int		FisType;
    bool	bTroop;
    DWORD	nRefershID;
}FISHINGJOY_CMD_S_SendFish;

typedef struct {
    WORD	wServerID;
    int		nChangeRatioUserScore;
    int		nChangeRatioFishScore;
    int		nExchangeOnce;
    int		nFireInterval;
    int		nMaxInterval;
    int		nMinInterval;
    int		nShowGoldMinMul;
    int		nMaxBulletCount;
    int		nMaxCannon;
}FISHINGJOY_CMD_S_GameConfig;

typedef struct {
    WORD	wChiarID;
    DWORD	dwServerTick;
    DWORD	dwClientTick;
}FISHINGJOY_CMD_S_TIME_SYNC;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
}FISHINGJOY_CMD_C_TREASURE_END;

typedef struct {
    WORD		wChairID;
    bool		bAdd;
}FISHINGJOY_CMD_C_CHANGE_CANNONSET;

typedef struct {
    DWORD	dwBulletID;
    DWORD	dwData;
    DWORD	dwFishID;
}FISHINGJOY_CMD_C_NETCAST;

typedef struct {
    WORD	wChairID;
    bool	bLock;
}FISHINGJOY_CMD_C_LOCK_FISH;

typedef struct {
    WORD		wChairID;
    float		fDirection;
    DWORD		dwFireTime;
    DWORD		dwClientID;
}FISHINGJOY_CMD_C_FIRE;

typedef struct
{
 DWORD dwBulletID;
 DWORD dwData;
 DWORD dwFishID[50];
 int  nCount;
}FISHINGJOY_CMD_C_NETCAST_TEQUAN;

typedef struct {
    WORD wChairID;
    bool bAdd;
}FISHINGJOY_CMD_C_CHANGE_CANNON;

typedef struct {
    WORD	wChairID;
    bool	bAdd;
    bool	bAddAll;
}FISHINGJOY_CMD_C_CHANGE_SCORE;

typedef struct {
    WORD	wChairID;
    DWORD	dwClientTick;
}FISHINGJOY_CMD_C_TIME_SYNC;

typedef struct {
    DWORD    dwFishID;
}FISHINGJOY_CMD_C_LOCK_SOME_FISH;

typedef struct {
    BYTE    cbMulti;
}FISHINGJOY_CMD_C_SPEEDUP;

typedef struct {
    WORD        wChairID;
    BYTE        cbSpeedMul;
    DWORD       dwStartTick;
}FISHINGJOY_CMD_S_SPEEDUP;

typedef struct 
{
	DWORD		wChairID;
	DWORD		dwFishID;
	int			    nBScoe;
	int			    effectType;
	DWORD		fishes[100];
	LONGLONG	scores[100];
}FISHINGJOY_CMD_S_EFFECT_KILL;

typedef struct
{
	DWORD	caster;
	DWORD	fishes[100];
	int		nBufferType;
	float	fBufferParam;
	float	fBufferTime;
}FISHINGJOY_CMD_S_ADD_BUFFER_EX;
#pragma pack(pop)
