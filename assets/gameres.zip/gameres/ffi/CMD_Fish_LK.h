#pragma pack(push)
#pragma pack(1)

typedef struct {
    DWORD dwUserId;
    DWORD dwCatchFishCount;
    DWORD dwCatchScore;
    DWORD dwRanking;
    TCHAR szNickName[32];

}FISH_CompetitionRanking;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
}FISH_LK_CMD_S_SCORE_SYNC;

typedef struct {
    DWORD dwRanking;
    LONG  lScore;
    LONG  lCatchScore;
}FISH_LK_CMD_S_MATCH_END;

typedef struct {
    WORD wChairId;
    DWORD dwRanking;
    LONG  lScore;
    DWORD MatchUserCount;
    LONG  lMaxScore;
}FISH_LK_CMD_S_CUR_RANKING;

typedef struct {
    DWORD dwUserId;
    DWORD dwCatchFishCount;
    DWORD dwCatchScore;
    DWORD dwRanking;
    LONG  lScore;
    TCHAR szNickName[32];
}FISH_LK_CMD_S_UPDATE_RANKING;

typedef struct {
    DWORD	nFishID;
    int		nMul;
}FISH_LK_CMD_S_FISH_MUL;

typedef struct {
    TCHAR	szFishName[256];
    int		nActivityTime;
    bool	bStart;
}FISH_LK_CMD_S_ACTIVITY_NOTIFY;

typedef struct {
    int		nBufferType;
    float	fBufferParam;
    float	fBufferTime;
    DWORD  dwServerTick;
}FISH_LK_CMD_S_ADD_BUFFER;

typedef struct {
    int						nMulriple;
    int						nSpeed;
    int						nMaxCatch;
    int						nBulletSize;
    int						nCatchRadio;
    int						nCannonType;
    bool					bFirst;
}FISH_LK_CMD_S_BULLET_SET;

typedef struct {
    int			nCount;
    TCHAR		szDes[4][256];
}FISH_LK_CMD_S_SEND_DES;

typedef struct {
    WORD	wChairID;
    DWORD	dwLockID;
}FISH_LK_CMD_S_LOCK_FISH;

typedef struct {
    int		FishCount;
    float	dir;
}FISH_AndroidUpdata;

typedef struct {
    bool	m_bAllowFire;
}FISH_LK_CMD_S_ALLOW_FIRE;

typedef struct {
    int		nst;
    bool	bSwitching;
}FISH_LK_CMD_S_SWITCH_SCENE;

typedef struct {
    WORD		wChairID;
    DWORD		dwBulletID;
}FISH_LK_CMD_S_KILL_BULLET;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
    DWORD		dwFishID;
    int			nBScoe;
    LONGLONG    lTotalScore;
    DWORD  dwServerTick;
}FISH_LK_CMD_S_KILL_FISH;

typedef struct {
    DWORD		dwID;
    WORD		wChairID;
    DWORD		dwCreateTick;
    float		fXpos;
    float		fYPos;
    int			nCannonType;
    int			nMultiply;
    LONGLONG	lScore;
    float		fDirection;
    bool		bNew;
    DWORD		dwServerTick;
    bool		IsDouble;
}FISH_LK_CMD_S_SEND_BULLET;

typedef struct {
    WORD		wChairID;
    int			cannonType;
    int			cannonMul;
    int			cannonSet;
    DWORD       dwServerTick; 

}FISH_LK_CMD_S_CANNON_SET;

typedef struct {
    WORD		wChairID;
    LONGLONG	lFishScore;
    LONGLONG	lWastageScore;
}FISH_LK_CMD_S_CHANGE_SCORE;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
    int			nCannonType;
    int			nCannonMul;
    LONGLONG	lWastage;
    int         nCannonSet;
}FISH_LK_CMD_S_USER_INFO;

typedef struct {
    DWORD	dwFishID;
    int		nTypeID;
    int		nPathID;
    DWORD	dwCreateTick;
    float	fOffestX;
    float	fOffestY;
    float	fDir;
    float	fDelay;
    DWORD	dwServerTick;
    float	FishSpeed;
    int		FisType;
    bool	bTroop;
    DWORD	nRefershID;
}FISH_LK_CMD_S_SendFish;

typedef struct {
    WORD	wServerID;
    int		nChangeRatioUserScore;
    int		nChangeRatioFishScore;
    int		nExchangeOnce;
    int		nFireInterval;
    int		nMaxInterval;
    int		nMinInterval;
    int		nShowGoldMinMul;
    int		nMaxBulletCount;
    int		nMaxCannon;
}FISH_LK_CMD_S_GameConfig;

typedef struct {
    WORD	wChiarID;
    DWORD	dwServerTick;
    DWORD	dwClientTick;
}FISH_LK_CMD_S_TIME_SYNC;

typedef struct {
    WORD		wChairID;
    LONGLONG	lScore;
}FISH_LK_CMD_C_TREASURE_END;

typedef struct {
    WORD		wChairID;
    bool		bAdd;
}FISH_LK_CMD_C_CHANGE_CANNONSET;

typedef struct {
    DWORD	dwBulletID;
    DWORD	dwData;
    DWORD	dwFishID;
}FISH_LK_CMD_C_NETCAST;

typedef struct {
    WORD	wChairID;
    bool	bLock;
}FISH_LK_CMD_C_LOCK_FISH;

typedef struct {
    WORD		wChairID;
    float		fDirection;
    DWORD		dwFireTime;
    DWORD		dwClientID;
}FISH_LK_CMD_C_FIRE;

typedef struct {
    WORD wChairID;
    bool bAdd;
}FISH_LK_CMD_C_CHANGE_CANNON;

typedef struct {
    WORD	wChairID;
    bool	bAdd;
    bool	bAddAll;
}FISH_LK_CMD_C_CHANGE_SCORE;

typedef struct {
    WORD	wChairID;
    DWORD	dwClientTick;
}FISH_LK_CMD_C_TIME_SYNC;

typedef struct {
    DWORD    dwFishID;
}FISH_LK_CMD_C_LOCK_SOME_FISH;

typedef struct {
    BYTE    cbMulti;
}FISH_LK_CMD_C_SPEEDUP;

typedef struct {
    WORD        wChairID;
    BYTE        cbSpeedMul;
    DWORD       dwStartTick;
}FISH_LK_CMD_S_SPEEDUP;

typedef struct 
{
	DWORD		wChairID;
	DWORD		dwFishID;
	int			nBScoe;
	int			effectType;
	DWORD		fishes[100];
	LONGLONG	scores[100];
}FISH_LK_CMD_S_EFFECT_KILL;

typedef struct
{
	DWORD	caster;
	DWORD	fishes[100];
	int		nBufferType;
	float	fBufferParam;
	float	fBufferTime;
}FISH_LK_CMD_S_ADD_BUFFER_EX;

typedef struct
{
    DWORD  dwKillID; //李逵id
    LONGLONG lTotalScore; //总分
    DWORD  dwFishID[256]; //死鱼的id
    DWORD  dwServerTick;
}FISH_LK_CMD_S_LIKUI_KILL_FISH;

typedef struct 
{  
    DWORD nFishID;  
    float fSpeed;
    DWORD  dwServerTick; 
}FISH_LK_CMD_S_CHANGE_SPEED;

typedef struct 
{  
    DWORD nFishID;  
    int x;
    int y;
    DWORD  dwServerTick; 
     
}FISH_LK_CMD_S_UPDATE_POSE;

typedef struct {  
    WORD  wChairID;  
    LONGLONG lScore;  
    LONGLONG lTotalScore;  
    DWORD  dwFishID;  
    int   nBScoe;  
    DWORD  dwTargetID[100];
    DWORD  dwServerTick; 
}FISH_LK_CMD_S_KILL_SPECIAL;

typedef struct {  
    DWORD nFishID; 
}FISH_LK_CMD_S_LANGLAILE;

typedef struct {  
    DWORD  dwServerTick; 
}FISH_LK_CMD_S_TIME_SYNC_FORCE;

#pragma pack(pop)
