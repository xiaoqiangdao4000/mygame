#pragma pack(1)

#pragma mark -
#pragma mark 登录模式

#pragma mark -
#pragma mark 登录结果

#pragma mark -
#pragma mark 升级提示

#pragma mark -
#pragma mark 设备类型

#pragma mark -
#pragma mark 视图模式

#pragma mark -
#pragma mark 信息模式

#pragma mark -
#pragma mark 其他配置

#pragma mark -
#pragma mark 行为标识

typedef struct{
	DWORD							dwPlazaVersion;						//广场版本
	DWORD							dwFrameVersion;						//框架版本
	DWORD							dwProcessVersion;					//进程版本

	DWORD							dwUserID;							//用户id
	TCHAR							szPassword[33];				//登录密码
    TCHAR                           szServerPasswd[33];       //房间密码
	TCHAR							szMachineID[33];		//机器序列
    WORD                            wKindID;                            //类型索引

}CMD_GR_LogonUserID;

typedef	struct
{
	//版本信息
	WORD							wGameID;							//游戏标识
	DWORD							dwProcessVersion;					//进程版本

	//桌子区域
	DWORD                           dwDeviceType;                       //设备类型
	WORD                            wBehaviorFlags;                     //行为标识
	WORD                            wPageTableCount;                    //分页桌数

	//登录信息
	DWORD							dwUserID;							//用户 I D
	CHAR							szPassword[33];				//登录密码
	CHAR							szMachineID[33];		//机器标识
	CHAR							szToken[33];					//登录密码
}CMD_GR_LogonMobile_Lua;

typedef struct{
	DWORD							dwPlazaVersion;						//广场版本
	DWORD							dwFrameVersion;						//框架版本
	DWORD							dwProcessVersion;					//进程版本

	TCHAR							szAccounts[32];			//登录帐号
	TCHAR							szPassword[33];				//登录密码
	TCHAR							szMachineID[33];		//机器序列

}CMD_GR_LogonAccounts;

//登录成功
typedef struct{
	DWORD							dwUserRight;						//用户权限
	DWORD							dwMasterRight;						//管理权限
}CMD_GR_LogonSuccess;

//登录失败
typedef struct{
	INT                         lErrorCode;							//错误代码
	CHAR						szDescribeString[128];				//错误描述
}CMD_GR_LogonFailure;

//登录完成
typedef struct{

    bool                            bGuideTask ;                        //引导任务
}CMD_GR_LogonFinish;

typedef struct{	
	BYTE							cbMustUpdatePlaza;					//强行升级
	BYTE							cbMustUpdateClient;					//强行升级
	BYTE							cbAdviceUpdateClient;				//建议升级

	DWORD							dwCurrentPlazaVersion;				//当前版本
	DWORD							dwCurrentFrameVersion;				//当前版本
	DWORD							dwCurrentClientVersion;				//当前版本
}CMD_GR_UpdateNotify;

#pragma mark -
#pragma mark 配置命令

//列表配置
typedef struct{
	BYTE							cbColumnCount;						//列表数目
	tagColumnItem					ColumnItem[32];				//列表描述
}CMD_GR_ConfigColumn;

typedef struct{
	WORD							wTableCount;						//桌子数目
	WORD							wChairCount;						//椅子数目

	WORD							wServerType;						//房间类型
	DWORD							dwServerRule;						//房间规则
}CMD_GR_ConfigServer;

//道具配置
typedef struct{
	BYTE							cbPropertyCount;					//道具数目
	tagPropertyInfo					PropertyInfo[128];			//道具描述
}CMD_GR_ConfigProperty;

//玩家权限
typedef struct{

    DWORD                           dwUserRight;                        //玩家权限
}CMD_GR_ConfigUserRight;

#pragma mark -
#pragma mark 用户命令

//旁观请求
typedef struct{
	WORD							wTableID;							//桌子位置
	WORD							wChairID;							//椅子位置
}CMD_GR_UserLookon;

//坐下请求
typedef struct{
	WORD							wTableID;							//桌子位置
	WORD							wChairID;							//椅子位置
	CHAR							szPassword[33];			//桌子密码
}CMD_GR_UserSitDown;

//起立请求
typedef struct{
	WORD							wTableID;							//桌子位置
	WORD							wChairID;							//椅子位置
	BYTE							cbForceLeave;						//强行离开
}CMD_GR_UserStandUp;

//邀请用户
typedef struct{
    WORD                            wTableID;                           //桌号码
    DWORD                           dwUserID;                           //用户id

}CMD_GR_UserInvite;

//邀请用户请求
typedef struct{
    WORD                            wTableID;                           //桌号码
    DWORD                           dwUserID;                           //用户id

}CMD_GR_UserInviteReq;

//请求用户信息
typedef struct{
    DWORD           dwUserIDReq;            //请求用户
    WORD            wTablePos;              //桌子位置
}CMD_GR_UserInfoReq;

//请求椅子信息
typedef struct{
    WORD							wTableID;							//桌子号码
    WORD							wChairID;							//椅子号码
}CMD_GR_ChairUserInfoReq;

//用户分数
typedef struct{
	DWORD							dwUserID;							//用户标识
	tagUserScore					UserScore;							//积分信息
}CMD_GR_UserScore;

#pragma mark -
#pragma mark 用户分数
typedef struct{
	DWORD							dwUserID;							//用户标识
	tagMobileUserScore				UserScore;							//积分信息
}CMD_GR_MobileUserScore;

//用户状态
typedef struct{
	DWORD							dwUserID;							//用户标识
	tagUserStatus					UserStatus;							//用户状态
}CMD_GR_UserStatus;

//请求失败
typedef struct{
	INT                             cbFailureCode;						//错误代码
	CHAR							szDescribeString[256];				//描述信息
}CMD_GR_RequestFailure;

typedef struct{
	BYTE                            cbRet;                              //返回结果
}CMD_GR_StandUp_Return;

//用户聊天
typedef struct{
	WORD							wChatLength;						//信息长度
	DWORD							dwChatColor;						//信息颜色
	DWORD							dwTargerUserID;						//目标用户
	TCHAR							szChatString[128];		//聊天信息
}CMD_GR_C_UserChat;

//用户聊天
typedef struct{
	WORD							wChatLength;						//信息长度
	DWORD							dwChatColor;						//信息颜色
	DWORD							dwSendUserID;						//发送用户
	DWORD							dwTargetUserID;						//目标用户
	TCHAR							szChatString[128];		//聊天信息
}CMD_GR_S_UserChat;

//用户表情
typedef struct{
	WORD							wItemIndex;							//表情索引
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_C_UserExpression;

//用户表情
typedef struct{
	WORD							wItemIndex;							//表情索引
	DWORD							dwSendUserID;						//发送用户
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_S_UserExpression;

//用户私聊
typedef struct{
	WORD							wChatLength;						//信息长度
	DWORD							dwChatColor;						//信息颜色
    DWORD                           dwSendUserID;                       //发送用户
	DWORD							dwTargetUserID;						//目标用户
	TCHAR							szChatString[128];		//聊天信息
}CMD_GR_C_WisperChat;

//用户私聊
typedef struct{
	WORD							wChatLength;						//信息长度
	DWORD							dwChatColor;						//信息颜色
	DWORD							dwSendUserID;						//发送用户
	DWORD							dwTargetUserID;						//目标用户
	TCHAR							szChatString[128];		//聊天信息
}CMD_GR_S_WisperChat;

//私聊表情
typedef struct{
	WORD							wItemIndex;							//表情索引
    DWORD                           dwSendUserID;                       //发送用户
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_C_WisperExpression;

//私聊表情
typedef struct{
	DWORD							wItemIndex;							//表情索引
	DWORD							dwSendUserID;						//发送用户
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_S_WisperExpression;

//用户会话
typedef struct{
	WORD							wChatLength;						//信息长度
	DWORD							dwChatColor;						//信息颜色
	DWORD							dwSendUserID;						//发送用户
	DWORD							dwConversationID;					//会话标识
	DWORD							dwTargetUserID[16];					//目标用户
	TCHAR							szChatString[128];		//聊天信息
}CMD_GR_GR_ColloquyChat;

//邀请用户
typedef struct{
	WORD							wTableID;							//桌子号码
	DWORD							dwSendUserID;						//发送用户
}CMD_GR_C_InviteUser;

//邀请用户
typedef struct{
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_S_InviteUser;

//购买道具
typedef struct {
    BYTE                            cbRequestArea;                      //请求范围
    BYTE                            cbConsumScore;                      //积分消费
	WORD							wItemCount;							//购买数目
	WORD							wPropertyIndex;						//道具索引
	DWORD							dwTargetUserID;						//使用对象
}CMD_GR_C_BuyProperty;

//道具成功
typedef struct {
    BYTE                            cbRequestArea;                      //使用环境
	WORD							wItemCount;							//购买数目
	WORD							wPropertyIndex;						//道具索引
	DWORD							dwSourceUserID;						//目标对象
    DWORD                           dwTargetUserID;                     //使用对象
}CMD_GR_S_PropertySuccess;

//道具失败
typedef struct {
    WORD                            wRequestArea;                       //请求区域
    INT                            lErrorCode;                         //错误代码
    TCHAR                           szDescribeString[256];              //描述信息
}CMD_GR_S_PropertyFailure;

//道具消息
typedef struct {
    WORD                            wPropertyIndex;                     //道具索引
    WORD                            wPropertyCount;                     //道具数目
    DWORD                           dwSourceUserID;                     //目标对象
    DWORD                           dwTargetUserID;                     //使用对象
}CMD_GR_S_PropertyMessage;

//道具效应
typedef struct {
    DWORD                           wUserID;                            //用户I D
    BYTE                            cbMemberOrder;                      //会员等级
}CMD_GR_S_PropertyEffect;

//发送喇叭
typedef struct {
    BYTE                            cbRequestArea;                      //
    WORD                            wPropertyIndex;
    DWORD                           TrumpetColor;
    TCHAR                           szTrumpetContent[128];
}CMD_GR_C_SendTrumpet;

//发送喇叭
typedef struct {
    WORD                            wPropertyIndex;
    DWORD                           dwSendUserID;
    DWORD                           TrumpetColor;
    TCHAR                           szSendNickName[32];
    TCHAR                           szTrumpetContent[128];
    TCHAR                           szTrumpetContent2[128];
}CMD_GR_S_SendTrumpet;
typedef struct {
    WORD                            wPropertyIndex;
    DWORD                           dwSendUserID;
    DWORD                           TrumpetColor;
    TCHAR                           szSendNickName[32];
    TCHAR                           szTrumpetContent[128];
    TCHAR                           szTrumpetContent2[128];
    int                             nAgentID;                       //商人代理后台的id
    TCHAR                           szStoreName[64];                //商人代理后台的店铺名称
}CMD_GR_S_SendTrumpet_New;

//用户拒绝黑名单坐下
typedef struct{
    WORD                            wTableID;
    WORD                            wChairID;
    DWORD                           dwUserID;                       //用户id
    DWORD                           dwrepulseUserID;                //用户id
}CMD_GR_UserRepulseSit;

//赠送通知
typedef struct {
    DWORD    dwPlayTimeCount;    //游戏时间
    DWORD    dwPresentPlayTime;  //赠送时间
}CMD_GR_PlayTimePresentNotify;

//赠送领取
typedef struct {
    BYTE     cbActionGame;     //游戏操作   大厅领取0  游戏领取1
}CMD_gr_playTimePresentDraw;

//用户规则
typedef struct{
	BYTE							cbRuleMask;							//规则掩码
	WORD							wMinWinRate;						//最低胜率
	WORD							wMaxFleeRate;						//最高逃率
	INT							lMaxGameScore;						//最高分数
	INT							lMinGameScore;						//最低分数

}CMD_GR_UserRule;

#pragma mark -
#pragma mark 状态命令

//桌子信息
typedef struct{
	WORD							wTableCount;						//桌子数目
	tagTableStatus					TableStatusArray[512];				//桌子状态
}CMD_GR_TableInfo;

//桌子状态
typedef struct{
	WORD							wTableID;							//桌子号码
	tagTableStatus					TableStatus;						//桌子状态
}CMD_GR_TableStatus;

typedef struct{
    BYTE                cbActivityGame;                     //游戏动作
    LONGLONG            lTakeScore;              //取款数目
    char               szInsurePass[33];      //银行密码
}CMD_GR_C_TakeGameScoreRequest;

//开通银行
typedef struct{

    BYTE                            cbActivityGame;                     //游戏动作
    DWORD                           dwUserID;                           //用户id
    TCHAR                           szLogonPass[33];          //登录密码
    TCHAR                           szInsurePass[33];         //银行密码
    TCHAR                           szMachineID[33];        //机器序列

}CMD_GR_C_EnableInsureRequest;

#pragma mark -
#pragma mark 客户端结构体
typedef struct{
	BYTE	cbActivityGame;							//游戏动作
}CMD_GR_C_QueryInsureInfoRequest;

//存款请求
typedef struct{
	BYTE	cbActivityGame;							//游戏动作
	SCORE	lSaveScore;								//存款数目
}CMD_GR_C_SaveScoreRequest;

//取款请求
typedef struct{
	BYTE	cbAvtivityGame;							//游戏动作
	SCORE	lTakeScore;								//取款数目
	TCHAR	szInsurePass[33];				//银行密码
}CMD_GR_C_TakeScoreRequest;

//查询用户
typedef struct{
    BYTE	cbActivityGame;                         //游戏动作
    BYTE	cbByNickName;                           //昵称赠送
    TCHAR	szAccounts[32];				//目标用户
}CMD_GR_C_QueryUserInfoRequest;

//转帐金币
typedef struct{
	BYTE	cbActivityGame;							//游戏动作
	SCORE	lTransferScore;							//转帐金币
	TCHAR	szAccounts[32];				//目标用户
	TCHAR	szInsurePass[33];				//银行密码
    TCHAR   szTransRemark[32];        //转帐备注
}CMD_GR_C_TransferScoreRequest;

#pragma mark -
#pragma mark 服务器发送结构体
//银行资料
typedef struct{
    BYTE                  cbActivityGame;                     //游戏动作
    WORD				  wRevenueTake;            //税收比例
    WORD				  wRevenueTransfer;          //税收比例
    WORD				  wServerID;              //房间标识
    LONGLONG              lUserScore;              //用户金币
    LONGLONG              lUserInsure;            //银行金币
    LONGLONG              lTransferPrerequisite;        //转账条件
}CMD_GR_S_UserInsureInfo;

//银行成功
typedef struct{
	BYTE	cbActivityGame;							//游戏动作
	SCORE	lUserScore;								//用户金币
	SCORE	lUserInsure;							//银行金币
	CHAR	szDescribrString[128];					//描述信息
}CMD_GR_S_UserInsureSuccess;

//银行失败
typedef struct{
	BYTE	cbActivityGame;							//游戏动作
	INT     lErrorCode;								//错误代码
	CHAR	szDescribeString[128];					//描述消息
}CMD_GR_S_UserInsureFailure;

//用户信息
typedef struct{
	BYTE	cbActivityGame;							//游戏动作
	DWORD   dwTargerUserID;                         //目标用户
	TCHAR   szAccounts[32];              //目标用户
}CMD_GR_S_UserTransferUserInfo;

//开通结果
typedef struct{
    BYTE     cbActivityGame;                        //游戏动作
    BYTE     cbInsureEnabled;                       //使能标识
    TCHAR    szDescribeString[128];                 //描述消息

}CMD_GR_S_UserInsureEnableResult;

//加载任务
typedef struct{

    DWORD              dwUserID;
    TCHAR              szPassword[33];                        //用户密码

}CMD_GR_C_LoadTaskInfo;

//领取任务
typedef struct{

    WORD               wTaskID;                                         //任务标识
    DWORD              dwUserID;                                        //用户标识
    TCHAR              szPassword[33];                        //登录密码
    TCHAR              szMachineID[33];                     //机器序列

}CMD_GR_C_TakeTask;

//领取奖励
typedef struct{
    WORD                wTaskID;                                        //任务标识
    DWORD               dwUserID;                                       //用户标识
    TCHAR               szPassword[33];                        //登录密码
    TCHAR               szMachineID[33];                    //机器序列

}CMD_GR_C_TakeReward;

//任务信息
typedef struct{
    WORD                wTaskCount;                                     //任务数量
    tagTaskStatus       TaskStatus[128];                     //任务状态

}CMD_GR_S_TaskInfo;

//任务完成
typedef struct{
    WORD                wFinishTaskID;                                  //任务标识
    TCHAR               szTaskName[64];                      //任务名称

}CMD_GR_S_TaskFinish;

typedef struct{
    bool                bSuccessed;                                     //成功标识
    WORD                wCommandID;                                     //命令标识

    SCORE               lCurrScore;                                     //当前金币
    SCORE               lCurIngot;                                      //当前元宝

    TCHAR               szNotifyContent[128];                           //提示内容

}CMD_GR_S_TaskResult;

//查询参数
typedef struct{
    DWORD							wExchangeRate;						//元宝游戏币兑换比率
    DWORD							wPresentExchangeRate;				//魅力游戏币兑换率
    DWORD							wRateGold;							//游戏豆游戏币兑换率
    WORD							wMemberCount;						//会员数目
    tagMemberParameter				MemberParameter[10];				//会员参数
}CMD_GR_ExchangeParameter;

//购买会员
typedef struct{

    DWORD                           dwUserID;                           //用户标识
    BYTE                            cbMemberOrder;                      //会员标识
    WORD                            wPurchaseTime;                      //购买时间
    TCHAR                           szMachineID[33];        //机器标识

}CMD_GR_PurchaseMember;

//购买结果
typedef struct{
    bool                            bSuccessed;                         //成功标识
    BYTE                            cbMemberOrder;                      //会员系列
    SCORE                           lCurrScore;                         //当前游戏币
    DWORD                           dCurrBeans;                         //当前游戏豆
    TCHAR                           szNotifyContent[128];               //提示内容
}CMD_GR_PurchaseResult;

//兑换游戏比
typedef struct{
    DWORD                           dwUserID;                           //用户标识
    SCORE                           lExchangeIngot;                     //兑换元宝
    TCHAR                           szMachineID[33];        //机器标识
}CMD_GR_ExchangeScore;

//兑换游戏币
typedef struct{

    DWORD							dwUserID;							//用户标识
    double							dExchangeBean;						//兑换元宝
    TCHAR							szMachineID[33];		//机器标识
}CMD_GR_ExchangeScoreByBean;

//兑换结果
typedef struct{
    bool                            bSuccessed;                         //成功标识
    SCORE                           lCurrScore;                         //当前游戏币
    SCORE                           lCurIngot;                          //当前元宝
    TCHAR                           szNotifyContent[128];               //提示内容

}CMD_GR_ExchangeResult;

//发送警告
typedef struct{
    WORD                            wChatLength;                            //信息长度
    DWORD                           dwTargerUserID;                         //目标用户
    TCHAR                           szWarningMessage[128];        //警告消息

}CMD_GR_SendWarning;

//系统消息
typedef struct{
    BYTE                            cbGame;                                 //游戏消息
    BYTE                            cbRoom;                                 //游戏消息
    BYTE                            cbAllRoom;                              //游戏消息
    BYTE                            cbLoop;                                 //循环标识
    DWORD                           dwTimeRate;                             //循环间隔
    INT                            lConcludeTime;                          //结束时间
    WORD                            wChatLength;                            //信息长度
    TCHAR                           szSystemMessage[128];         //系统消息

}CMD_GR_SendMessage;

//查看地址
typedef struct{
    DWORD                           dwTargerUserID;

}CMD_GR_LookUserIP;

//剔出用户
typedef struct{
    DWORD                           dwTargerUserID;
}CMD_GR_KickUser;

//禁用帐户
typedef struct{
    DWORD                           dwTargerUserID;

}CMD_GR_limitAccounts;

typedef struct{
    WORD                            dwTargerUserID;

    BYTE                            cbGameRight;                            //帐号权限
    BYTE                            cbAccountsRight;                        //帐号权限

    BYTE                            cbLimitRoomChat;                        //大厅聊天
    BYTE                            cbLimitGameChat;                        //游戏聊天
    BYTE                            cbLimitPlayGame;                        //游戏权限
    BYTE                            cbLimitSendWisper;                      //发送消息
    BYTE                            cbLimitLookonGame;                      //旁观权限

}CMD_GR_SetUserRight;

//房间设置
typedef struct{
    DWORD                           dwRuleMask;                             //规则掩码
    tagServerOptionInfo             ServerOptionInfo;                       //房间配置

}CMD_GR_OptionCurrent;

//房间设置
typedef struct{
    tagServerOptionInfo             ServerOptionInfo;                       //房间配置

}CMD_GR_ServerOption;

//剔出所有用户
typedef struct{
    TCHAR                           szKickMessage[128];           //剔出提示

}CMD_GR_KickAllUser;

typedef struct{

    WORD                            wDissmissTableNum;                  //解算桌号
}CMD_GR_DissmissGame;

//房间设置
typedef struct{
    BYTE                              cbOptionFlags;                    //设置标识
    BYTE                              cbOptionValue;                    //设置标识

}CMD_GR_OPtionServer;

//限制聊天
typedef struct{
    DWORD                              dwTargerUserID;
    BYTE                                cbLimitFlags;                   //限制标志
    BYTE                                cbLimitValue;                   //限制与否

}CMD_GR_LimitUserChat;

typedef struct {

    SCORE                           lMatchFee;                          //报名费用
    TCHAR                           szNotifyContent[128];               //提示内容

}CMD_GR_Match_Fee;

//比赛人数
typedef struct {
	DWORD							dwWaitting;							//等待人数
	DWORD							dwTotal;							//开赛人数
}CMD_GR_Match_Num;

//赛事信息
typedef struct {
	TCHAR							szTitle[4][64];						//信息标题
    WORD							wGameCount;							//游戏局数
}CMD_GR_Match_Info;

//提示信息
typedef struct {
	SCORE							lScore;								//当前积分
	WORD							wRank;								//当前名次
	WORD							wCurTableRank;						//本桌名次
	WORD							wUserCount;							//当前人数

    WORD                            wCurGameCount;                      //当前局数
    WORD                            wGameCount;                         //总共局数

	WORD							wPlayingTable;						//游戏桌数
    TCHAR							szMatchName[32];			//比赛名称

}CMD_GR_Match_Wait_Tip;

//比赛结果
typedef struct {

    SCORE                           lGold;								//金币奖励
    DWORD							dwIngot;							//元宝奖励
    DWORD							dwExperience;						//经验奖励
    TCHAR							szDescribe[256];					//得奖描述
}CMD_GR_MatchResult;

//比赛描述
typedef struct {

    TCHAR							szTitle[4][16];		//信息标题
    TCHAR							szDescribe[4][64];		//描述内容

    DWORD                           crTitleColor;						//标题颜色
    DWORD                           crDescribeColor;					//描述颜色
}CMD_GR_MatchDesc;

//金币更新
typedef struct {
    SCORE                             lCurrScore;                       //当前金币
    SCORE                             lCurIngot;                        //当前元宝
    DWORD                             dwCurrExprience;                  //当前经验

}CMD_GR_MatchGoldUpdate;

//游戏配置
typedef struct{
	BYTE							cbAllowLookon;						//旁观标志
	DWORD							dwFrameVersion;						//框架版本
	DWORD							dwClientVersion;					//游戏版本

}CMD_GF_GameOption;

//旁观配置
typedef struct{
	DWORD							dwUserID;							//用户标识
	BYTE							cbAllowLookon;						//允许旁观
}CMD_GF_LookonConfig;

//旁观状态
typedef struct{
	BYTE							cbAllowLookon;						//允许旁观
}CMD_GF_LookonStatus;

//游戏环境
typedef struct{
	BYTE							cbGameStatus;						//游戏状态
	BYTE							cbAllowLookon;						//旁观标志
}CMD_GF_GameStatus;

//用户聊天
typedef struct{

    WORD                            wChatLength;
    DWORD                           dwChatColor;
    DWORD                           dwTargerUserID;
    TCHAR                           szChatString[128];
}CMD_GF_C_UserChat;

typedef struct{
    WORD                            wChatLength;
    DWORD                           dwChatColor;
    DWORD                           dwSendUserID;
    DWORD                           dwTargerUserID;
    TCHAR                           szChatString[128];

}CMD_GF_S_UserChat;

//用户表情
typedef struct{
    WORD                            wItemIndex;
    DWORD                           dwTargerUserID;

}CMD_GF_C_UserExpression;

typedef struct{
    WORD                            wItemIndex;
    DWORD                           dwSendUserID;
    DWORD                           dwTargerUserID;

}CMD_GF_S_UserExpression;

typedef struct
{  
	BYTE       cbIsActiviting;      //活动是否开启
 	DWORD       dwUserID;       //用户id
 	LONGLONG      lCount;        //我的红包数
 	DWORD       dwParam;       //备用参数
}CMD_GF_S_LuckyMoney;

//碎片信息
typedef struct
{
	BYTE              cbIsActiviting;            //活动是否开启
	DWORD              dwUserID;              //用户id
	WORD              wCurrentType;            //当前获得类型
	WORD              wTypeCount;              //种类数量
	LONGLONG            lCount[32];              //我的碎片数
	DWORD              dwParam;              //备用参数
}CMD_GF_S_Tatter;
#pragma pack()

