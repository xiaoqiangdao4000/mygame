
#pragma pack(1)

//兑换筹码
typedef struct 
{
    LONGLONG		lExchangeScore;						//兑换成筹码的总分数（不是本次要兑换的分数，而是总的分数）
}CMD_C_SGJ_Exchange;

//猜大小
typedef struct 
{
    BYTE			cbBigSmall;							//猜大小，0为小（0-7），1为大（8-15）
    LONGLONG		lJettonScore;						//赌注
}CMD_C_SGJ_BigSmall;

//用户下注
typedef struct 
{
    LONGLONG		lJettonScore[8];						//加注数目
}CMD_C_SGJ_PlaceJetton;


//////////////////////////////////////////////////////////////////////////
//服务器命令结构
//猜大小
typedef struct 
{
    bool			bWin;								//猜大小成功
    BYTE			cbBigSmall;							//大小的实际数值
    LONGLONG		lWinScore;							//玩家成绩
    LONGLONG		lUserScore;							//玩家积分
}CMD_S_SGJ_BigSmall;

//游戏开始
typedef struct 
{
    LONGLONG		lUserScore;							//我的金币
    DWORD           wExchangeRatio;      //兑换比例
}CMD_S_SGJ_GameStart;

//广播奖励 
typedef struct 
{   TCHAR     szNickName[32];
    TCHAR     szServerName[32];
    TCHAR     szEventName[32];       
    LONGLONG  lScore;
}CMD_S_SGJ_BroadcastAward;

typedef struct 
{
    WORD			wEventId;							//时间id
    BYTE			cbCount;							//开奖区域数量
    BYTE			cbStep[24];			//开奖格子
    BYTE			cbArea[24];			//开奖区域
    WORD			wTimes[24];			//倍数
    LONGLONG        lScore[24];			//倍数
}SGJ_tagEventData;

//开奖
typedef struct 
{
    WORD			wChairID;							//用户位置
    BYTE			cbStep;								//开奖格子
    BYTE			cbArea;								//开奖区域
    WORD			wTimes;								//倍数
    LONGLONG		lWinScore;							//开奖赢分
    LONGLONG		lUserScore;							//玩家积分
    
    //特殊事件
    SGJ_tagEventData    stEvents;							//特殊事件
    
    //历史记录
    BYTE			cbRecord[8];		//历史记录
}CMD_S_SGJ_GameSqueeze;

#pragma pack()
