#pragma pack(push)
#pragma pack(1)

typedef struct
{
	int nType;   //开奖类型
	int nTimes;  //闪电的倍数，初始化为1
	int nAwardIndex[15];//命中的选项，设置为1
	int nJettonAreaTimes[15];
}SLWH_OpenAward;

typedef struct
{  
	BYTE cbType;//中奖类型  
	BYTE cbZHX; //庄和闲数据  
	BYTE cbAwardIndex;//命中的选项 
}SLWH_AwardRecord;

typedef struct
{
	int nJettonArea;
	SCORE lBet;
}SLWH_CMD_C_Jetton;

typedef struct  
{  
	SCORE lBet[15];
}SLWH_CMD_C_Jetton_Continue;

typedef struct
{
	int nArea;
	WORD wChairID;
	SCORE lScore;     //本次下注的量
	SCORE lJetton;         //此门下注的总量
	SCORE lTotalJetton;    //这个区域的总注
	BYTE  cbRet;     //0成功 1失败达到此门下注上限 2达到个人下注上限
}SLWH_CMD_S_Jetton;

typedef struct  
{  
	WORD wChairID;
	SCORE lBet[15];
	SCORE lTotalJetton[15]; 
	BYTE  cbRet;
}SLWH_CMD_S_Jetton_Continue;

//开始协议
typedef struct
{
	SCORE lJettonConfig[5];//可下注的筹码
	int nJettonAreaTimes[15];  
	BYTE cbTimeLeave;      //剩余时间
	int  nSeed;        //随机种子
}SLWH_CMD_S_GameStart;

//游戏空闲
typedef struct
{
	BYTE						cbTimeLeave;						//剩余时间
	BYTE                     cbStatus;
	int        				nSeed;        //随机种子
}SLWH_CMD_S_GameStatus;

//场景协议
typedef struct
{
	BYTE							cbTimeLeave;		  //剩余时间
	BYTE                         cbStatus;//游戏状态
	SCORE				lJettonConfig[5];//可下注的筹码
	SCORE                 lJettoned[15];	//各个区域已下注总额
	SLWH_OpenAward       tAward;  		//已经开出的奖
	int        				nJettonAreaTimes[15];   //下注区的倍数  
	SCORE       		lPlayerJettoned[15];   //各个区域玩家已下注总额
	SLWH_AwardRecord  		tAwardRecord[40];  //中奖纪录 
    int        	nSeed; 
}SLWH_CMD_S_GameScene;

//失败结构
typedef struct
{
	WORD wChairID;				//下注玩家
	LONGLONG lJettonScore[15];  //已下注
	SCORE lPlayerJettoned[15];  //各个区域玩家已下注总额 
}SLWH_CMD_S_PlaceBetFail;

//游戏结束
typedef struct
{
	SLWH_OpenAward tAward;
	SCORE lScore;
	SCORE lCaijin; 
	SCORE lJettoned; 
	SCORE lEndScore; 
	BYTE cbTimeLeave;      //剩余时间
	SLWH_AwardRecord tAwardRecord[40]; //中奖纪录
	int  nSeed; 
}SLWH_CMD_S_GameEnd;

#pragma pack(pop)