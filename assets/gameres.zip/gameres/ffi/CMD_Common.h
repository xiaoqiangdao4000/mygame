#pragma pack(1)

//系统消息
typedef struct
{
	WORD								wType;							//消息类型
	WORD								wLength;						//消息长度
	CHAR								szString[1024];					//消息内容
}CMD_CM_SystemMessage;
#pragma pack()