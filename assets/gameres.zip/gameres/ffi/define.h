#pragma pack(1)
typedef unsigned char		BYTE;
typedef unsigned short		WORD;
typedef unsigned int		DWORD;
typedef unsigned short      TCHAR;
typedef unsigned int        UINT;

typedef	long long			LONGLONG;
typedef long long			SCORE;
typedef double              DOUBLE;
typedef short               SHORT;
typedef int                 INT;
typedef float               FLOAT;
typedef DWORD               COLORREF;
typedef char                CHAR;
typedef unsigned int        LONG;

typedef const char c_char;
typedef const char* pConstChar;

typedef struct {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
} 	SYSTEMTIME;

#pragma mark 数值定义

#pragma mark 系统参数

#pragma mark 索引质数

#pragma mark 数据长度

#pragma mark 好友关系

#pragma mark 性别定义

#pragma mark 分数模式

#pragma mark 任务类型

#pragma mark 用户状态

#pragma mark 房间规则

#pragma mark 列表数据

#pragma mark 数据库定义

#pragma pack(0)

