#pragma pack(1)

typedef struct {

    DWORD							dwPlazaVersion;             //广场版本
    TCHAR							szMachineID[33];//机器序列

	DWORD							dwGameID;                   //游戏 I D
    TCHAR							szPassword[33];        //登录密码
    BYTE							cbValidateFlags;            //校验标识
}CMD_GP_LogonGameID;

typedef struct {

    DWORD							dwPlazaVersion;                 //广场版本
    TCHAR							szMachineID[33];    //机器序列

    BYTE							cbValidateFlags;                //校验标识
    TCHAR							szPassword[33];            //登录密码
    TCHAR							szAccounts[32];       //登录帐号
    TCHAR							szPassPortID[19]; //身份证号
}CMD_GP_LogonAccounts;

typedef struct {
    DWORD							dwPlazaVersion;                     //广场版本
    TCHAR							szMachineID[33];        //机器序列

    TCHAR							szLogonPass[33];               //登录密码

    WORD							wFaceID;                            //头像标识
    BYTE							cbGender;                           //用户性别
    TCHAR							szAccounts[32];           //登录帐号
    TCHAR							szNickName[32];           //用户昵称
    TCHAR							szSpreader[32];           //推荐帐号
    TCHAR							szPassPortID[19];     //证件号码
    TCHAR							szCompellation[16];   //真实名字
    BYTE							cbValidateFlags;                    //校验标识
}CMD_GP_RegisterAccounts;

typedef struct {
    DWORD							dwPlazaVersion;                     //广场版本

    WORD							wVerifyMask;                        //验证掩码
}CMD_GP_VerifyIndividual;

typedef struct {

    WORD							wFaceID;            //头像标识
    DWORD							dwUserID;           //用户 I D
    DWORD							dwGameID;           //游戏 I D
    DWORD							dwGroupID;          //社团标识
    DWORD							dwCustomID;         //自定标识
    DWORD							dwExperience;       //经验数值
    DWORD							dwLoveLiness;       //用户魅力

    SCORE							lUserScore;         //用户金币
    SCORE							lUserInsure;        //用户银行
    SCORE							lUserIngot;         //用户元宝
    DOUBLE							dUserBeans;         //用户游戏豆

    BYTE							cbGender;                   //用户性别
    BYTE							cbMoorMachine;              //锁定机器
    TCHAR							szAccounts[32];   //登录帐号
    TCHAR							szNickName[32];   //用户昵称
    TCHAR							szDynamicPass[33]; //动态密码
    TCHAR							szGroupName[32];//社团名字

    BYTE							cbInsureEnabled;            //银行使能标识
    BYTE                            cbShowServerStatus;         //显示服务器状态
}CMD_GP_LogonSuccess;

//登录失败
typedef struct {
    INT							lResultCode;                    //错误代码
    TCHAR							szDescribeString[128];

}CMD_GP_LogonFailure;
//登陆完成
typedef struct {
    WORD							wIntermitTime;                    //中断时间
    WORD							wOnLineCountTime;                //更新时间
}CMD_GP_LogonFinish;

//登录失败
typedef struct {
    UINT								uMBCardID;                   //机器序列
}CMD_GP_ValidateMBCard;
//验证结果
typedef struct {
    bool							bVerifyPassage;                  //验证通过
    WORD							wVerifyMask;                     //验证掩码
    TCHAR							szErrorMsg[128];                 //错误信息

}CMD_GP_VerifyIndividualResult;

//升级提示
typedef struct {
    BYTE							cbMustUpdate;                       //强行升级
    BYTE							cbAdviceUpdate;                     //建议升级
    DWORD							dwCurrentVersion;                   //当前版本
}CMD_GP_UpdateNotify;

//社团信息
typedef struct {
    DWORD							dwGroupID;							//社团索引
    TCHAR							szGroupName[32];		//社团名字
}DTP_GP_GroupInfo;

//会员信息
typedef struct {
    BYTE							cbMemberOrder;						//会员等级
    SYSTEMTIME						MemberOverDate;						//到期时间
}DTP_GP_MemberInfo;

//获取在线
typedef struct {
    WORD							wServerCount;						//房间数目
    WORD							wOnLineServerID[1024];		//房间标识
}CMD_GP_GetOnline;

//类型在线
typedef struct {
    WORD							wKindCount;							//类型数目
    tagOnLineInfoKind				OnLineInfoKind[256];			//类型在线
}CMD_GP_KindOnline;

//房间在线
typedef struct {
    WORD							wServerCount;						//房间数目
    tagOnLineInfoServer				OnLineInfoServer[1024];		//房间在线
}CMD_GP_ServerOnline;

//房间滚动消息
typedef struct {
    int m_MsgCount;
    CHAR  szTopMsg[5][250];
}CMD_S_GP_TopMsgInfo;

//手机银行失败
typedef struct {
    int                                 lResultCode;					//错误代码
    char                                szDescribeString[128];			//描述消息
}CMD_GP_UserInsureFailure_MB;
//存取成功
typedef struct {
    DWORD                               dwUserID;						//用户 I D
    LONGLONG                            lUserScore;						//用户金币
    LONGLONG                            lUserInsure;					//银行金币
    CHAR                                szDescribeString[128];			//描述消息
}CMD_GP_UserInsureSuccess_MB;
//提取金币请求
typedef struct {
    DWORD                               dwUserID;						//用户 I D
    WORD                                wKindID;                        //游戏KINDID
    LONGLONG                            lTakeScore;                     //提取金币
    CHAR                                szToken[33];				//银行密码
    CHAR                                szMachineID[33];	//机器序列
}CMD_GP_UserTakeScore_MB;
//存入金币请求
typedef struct {
    DWORD                               dwUserID;                       //用户 I D
    WORD                                wKindID;                        //游戏KINDID
    LONGLONG                            lSaveScore;                     //存入金币
    CHAR                                szToken[33];               //银行密码
    CHAR                                szMachineID[33];    //机器序列
}CMD_GP_UserSaveScore_MB;
typedef struct {
    LONGLONG							lUserScore;                     //用户金币
    LONGLONG							lUserInsure;                    //银行金币
    DWORD                               dwRecordID;                     //记录ID
    DWORD                               dwSourceUserID;                 //赠送用户ID
    DWORD                               dwTargetUserID;                 //获赠用户ID
    CHAR                                szSourceNickName[64];           //赠送用户昵称
    CHAR                                szTargetNickName[64];           //赠送
    LONGLONG							lScore;                         //用户游戏币
}CMD_GP_UserTransferResult_MB;

typedef struct {
    WORD                                wYear;
    WORD                                wMonth;
    WORD                                wDayOfWeek;
    WORD                                wDay;
    WORD                                wHour;
    WORD                                wMinute;
    WORD                                wSecond;
    WORD                                wMilliseconds;
}CMD_SYSTEMTIME;

typedef struct {
    LONGLONG                            lUserScore;                     //用户金币
    LONGLONG                            lUserInsure;                    //银行金币
    DWORD                               dwRecordID;                     //记录ID
    DWORD                               dwSourceUserID;                 //赠送用户ID
    DWORD                               dwTargetUserID;                 //获赠用户ID
    CHAR                                szSourceNickName[64];           //赠送用户昵称
    CHAR                                szTargetNickName[64];           //赠送
    LONGLONG                            lScore;                         //用户游戏币
    CMD_SYSTEMTIME                      dtTime;                         //赠送时间
}CMD_GP_UserTransferResult_MB1;

//转账请求
typedef struct {
    DWORD							dwUserID;							//用户 I D
    BYTE                            cbByNickName;                       //昵称赠送
    LONGLONG						lTransferScore;						//转账金币
    CHAR							szToken[33];                   //银行密码
    CHAR							szNickName[64];                     //目标用户
    CHAR							szMachineID[33];		//机器序列
}CMD_GP_UserTransferScore_MB;
//操作失败
typedef struct {
    int							lResultCode;						//错误代码
    CHAR						szDescribeString[128];				//描述消息
}CMD_GP_OperateFailure_MB;
//操作成功
typedef struct {
    int							lResultCode;						//操作代码
    CHAR						szDescribeString[128];				//成功消息
}CMD_GP_OperateSuccess_MB;
//修改密码
typedef struct {
    DWORD							dwUserID;							//用户 I D
    CHAR							szDesPassword[33];		//用户密码
    CHAR							szScrPassword[33];		//用户密码
}CMD_GP_ModifyInsurePass_MB;
//请求转账记录
typedef struct {
    DWORD							dwUserID;							//用户 I D
    CHAR							szToken[33];
}CMD_GP_TransferRecord_MB;

//银行记录
typedef struct {
    DWORD								dwSendUserID;					//客户端玩家ID
    CHAR								szSendNickName[64];		//对方(操作玩家)昵称
    LONGLONG							lBeforeScore;
    LONGLONG							lAfterScore;
    LONGLONG							lMyScore;						//积分数量
    CHAR								szDateTime1[64];					//时间
    CHAR								szDateTime2[64];					//时间
    WORD								wChangType;						//类型   101,102为存取;3为转账
}TransRecdinfo;

//转账记录
typedef struct {
    DWORD                           dwRecordID;                             //记录ID
    DWORD                           dwSourceUserID;                         //赠送用户ID
    DWORD                           dwTargetUserID;                           //获赠用户ID
    CHAR                           szSourceNickName[64];         //赠送用户昵称
    CHAR                           szTargetNickName[64];           //赠送
    LONGLONG						lScore;								    //用户游戏币
    WORD							wYear;
    WORD							wMonth;
    WORD							wDay;
    WORD							wHour;
    WORD							wMinu;
    WORD							wSecd;

}CMD_GP_UserTransferRecordResult_MB;

//重设银行密码
typedef struct 
{
    DWORD                           dwUserID;                          //用户标识
    CHAR                           szPassword[33];                    //用户密码
    CHAR                           szMobileNumber[12];                //手机号码 
    CHAR                           szSmsCode[7];                      //短信验证码
}CMD_GP_ModifyInsurePassWithSms_MB;

//手机用户查询
typedef struct {
    DWORD							dwTargetGameID;						//目标用户
    CHAR							szNickName[64];                     //目标用户
}CMD_GP_UserTransferUserInfo_MB;
//手机用户查询
typedef struct {
    DWORD                            dwTargetGameID;                       //昵称赠送
}CMD_GP_QueryUserInfoRequest_MB;

//游戏银行数据查询请求结果
typedef struct {
    LONGLONG							lUserScore;							//用户金币
    LONGLONG							lUserInsure;						//银行金币
}CMD_GP_UserGameInsureInfo;

//游戏银行数据查询请求
typedef struct {
    DWORD                           dwUserID;							//用户 I D
    WORD                            wKindID;                            //游戏KINDID
    CHAR							szToken[33];
}CMD_GP_QueryGameInsureInfo;

//银行用户登录请求
typedef struct {
    DWORD							dwUserID;							//用户 I D
    char							szPassword[33];		    //用户密码
    char							szMachineID[33];		//机器序列
}CMD_GP_UserInsureLogon_MB;

//修改密码
typedef struct{
    DWORD							dwUserID;							//用户 I D
    TCHAR							szDesPassword[33];		//用户密码
    TCHAR							szScrPassword[33];		//用户密码
}CMD_GP_ModifyLogonPass;
//修改密码
typedef struct{
    DWORD							dwUserID;							//用户 I D
    TCHAR							szDesPassword[33];		//用户密码
    TCHAR							szScrPassword[33];		//用户密码
}CMD_GP_ModifyInsurePass;

//修改签名
typedef struct {
    DWORD							dwUserID;							//用户 I D
    TCHAR							szPassword[33];			//用户密码
    TCHAR							szUnderWrite[32];		//个性签名
}CMD_GP_ModifyUnderWrite;

//排行榜
typedef struct {
    WORD		wFaceID;
    WORD		wGender;
    WORD		UserType;
    CHAR		szNickName[32];
    LONGLONG	lData;
    LONGLONG	GameID;
    CHAR		Tel[12];
    CHAR		UnWrite[128];
}UserRank;

typedef struct {
    WORD		wRankCount;
    UserRank	userRank[50];
}CMD_S_GP_Rank;

//修改头像
typedef struct{
    DWORD							dwUserID;							//用户 I D
    TCHAR							szPassword[33];			//用户密码
    TCHAR							szMachineID[33];		//机器序列
    DWORD							dwCustomFace[48*48];		//图片信息
}CMD_GP_CustomFaceInfo;

//绑定机器
typedef struct {
    BYTE							cbBind;								//绑定标志
    DWORD							dwUserID;							//用户标识
    TCHAR							szPassword[33];			//用户密码
    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_ModifyMachine;

//设置推荐人
typedef struct {
    DWORD                           dwMyUserID;
    DWORD                           dwSpreaderID;
}CMD_GP_UserSetSpreaderID;

//设置推荐人结果
typedef struct {
    LONGLONG                        lResultCode;
    CHAR                            szDescribeString[128];        //描述消息
}CMD_GP_SetSpreaderID_Rst;

//个人资料
typedef struct {
    DWORD							dwUserID;							//用户 I D
}CMD_GP_UserIndividual;

//查询信息
typedef struct {
    DWORD							dwUserID;							//用户 I D
    TCHAR							szPassword[33];			//用户密码
}CMD_GP_QueryIndividual;

//修改资料
typedef struct{
    BYTE							cbGender;							//用户性别
    DWORD							dwUserID;							//用户 I D
    TCHAR							szPassword[33];			//用户密码
}CMD_GP_ModifyIndividual;

//银行资料
typedef struct{
    BYTE							cbEnjoinTransfer;					//转帐开关
    WORD							wRevenueTake;						//税收比例
    WORD							wRevenueTransfer;					//税收比例
    WORD							wRevenueTransferMember;				//税收比例
    WORD							wServerID;							//房间标识
    SCORE							lUserScore;							//用户金币
    SCORE							lUserInsure;						//银行金币
    SCORE							lTransferPrerequisite;				//转帐条件
}CMD_GP_UserInsureInfo;

//开通银行
typedef struct {
    DWORD							dwUserID;							//用户I D
    TCHAR							szLogonPass[33];			//登录密码
    TCHAR							szInsurePass[33];			//银行密码
    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_UserEnableInsure;

//存入金币
typedef struct {
    DWORD							dwUserID;							//用户 I D
    SCORE							lSaveScore;							//存入金币
    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_UserSaveScore;

//提取金币
typedef struct {
    DWORD							dwUserID;							//用户 I D
    SCORE							lTakeScore;							//提取金币
    TCHAR							szPassword[33];				//银行密码
    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_UserTakeScore;

//转帐金币
typedef struct {
    DWORD							dwUserID;							//用户 I D
    SCORE							lTransferScore;						//转帐金币
    TCHAR							szPassword[33];				//银行密码
    TCHAR							szAccounts[32];			//目标用户
    TCHAR							szMachineID[33];		//机器序列
    TCHAR							szTransRemark[32];	//转帐备注
}CMD_GP_UserTransferScore;
//银行成功
typedef struct{
    DWORD							dwUserID;							//用户 I D
    SCORE							lUserScore;							//用户金币
    SCORE							lUserInsure;						//银行金币
    TCHAR							szDescribeString[128];				//描述消息
}CMD_GP_UserInsureSuccess;

//银行失败
typedef struct {
    INT							lResultCode;						//错误代码
    TCHAR							szDescribeString[128];				//描述消息
}CMD_GP_UserInsureFailure;

typedef struct {
    DWORD							dwUserID;							//用户 I D
    SCORE							lUserScore;							//用户金币
    SCORE							lUserInsure;						//银行金币
}CMD_GP_UserTakeResult;

//查询银行
typedef struct {
    DWORD							dwUserID;							//用户 I D
    TCHAR							szPassword[33];				//银行密码
}CMD_GP_QueryInsureInfo;

//查询用户
typedef struct {
    BYTE                            cbByNickName;                       //昵称赠送
    TCHAR							szAccounts[32];			//目标用户
}CMD_GP_QueryUserInfoRequest;

//用户信息
typedef struct {
    DWORD							dwTargetGameID;						//目标用户
    TCHAR							szAccounts[32];			//目标用户
}CMD_GP_UserTransferUserInfo;

//开通结果
typedef struct {

    BYTE							cbInsureEnabled;					//使能标识
    TCHAR							szDescribeString[128];				//描述消息
}CMD_GP_UserInsureEnableResult;

//查询签到
typedef struct {
    DWORD							dwUserID;							//用户标识
}CMD_GP_CheckInQueryInfo;

//查询结果
typedef struct {
    BYTE                            cbSign[7];
    int                             nScorePresent[7];
}CMD_GP_CheckInResult;

//执行签到
typedef struct {
    CHAR							szMachineID[33];		//机器序列
    INT							dwUserID;							//用户标识
}CMD_GP_CheckInDone;

//签到结果
typedef struct {
    CHAR		szDescribeString[256];				//描述消息
    int			nResultCode;
    LONGLONG	lInsureScore;
}CMD_SC_MB_SignInRes;

typedef struct {
    CHAR						szMachineID[33];		//机器标识
    int							dwUserID;							//用户 I D
}CMD_MB_ClickLikesInfo;

typedef struct {
    int								nSigns;
    int								nClickLikes;
}CMD_MB_SC_ClickLikesInfo;

//加载任务
typedef struct {

    DWORD							dwUserID;							//用户标识
    TCHAR							szPassword[33];			//用户密码
}CMD_GP_TaskLoadInfo;

//领取任务
typedef struct {
    WORD							wTaskID;							//任务标识
    DWORD							dwUserID;							//用户标识
    TCHAR							szPassword[33];			//登录密码
    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_TaskTake;

//领取奖励
typedef struct {
    WORD							wTaskID;							//任务标识
    DWORD							dwUserID;							//用户标识
    TCHAR							szPassword[33];			//登录密码
    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_TaskReward;

//任务信息
typedef struct {
    WORD							wTaskCount;							//任务数量
    tagTaskStatus					TaskStatus[128];			//任务状态
}CMD_GP_TaskInfo;

typedef struct {
    bool							bSuccessed;							//成功标识
    WORD							wCommandID;							//命令标识

    SCORE							lCurrScore;							//当前金币
    SCORE							lCurrIngot;							//当前元宝

    TCHAR							szNotifyContent[128];				//提示内容
}CMD_GP_TaskResult;

//领取低保
typedef struct {
    DWORD							dwUserID;							//用户 I D
    TCHAR							szPassword[33];			//登录密码
    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_BaseEnsureTake;

//低保参数
typedef struct {
    SCORE							lScoreCondition;					//游戏币条件
    SCORE							lScoreAmount;						//游戏币数量
    BYTE							cbTakeTimes;						//领取次数
}CMD_GP_BaseEnsureParamter;

//低保结果
typedef struct {
    bool							bSuccessed;							//成功标识
    SCORE							lGameScore;							//当前游戏币
    TCHAR							szNotifyContent[128];				//提示内容
}CMD_GP_BaseEnsureResult;

//推广查询
typedef struct {
    DWORD							dwUserID;							//用户标识
}CMD_GP_UserSpreadQuery;
//推广参数
typedef struct {
    DWORD							dwSpreadCount;						//推广人数
    SCORE							lSpreadReward;						//推广奖励
}CMD_GP_UserSpreadInfo;

typedef struct {
    DWORD							dwUserID;							//用户标识
    TCHAR							szPassword[33];			//用户密码

    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_GrowLevelQueryInfo;

//等级配置
typedef struct {
    WORD							wLevelCount;						//等级数目
    tagGrowLevelConfig				GrowLevelItem[60];					//等级配置
}CMD_GP_GrowLevelConfig;
//等级参数
typedef struct {
    WORD							wCurrLevelID;						//当前等级
    DWORD							dwExperience;						//当前经验
    DWORD							dwUpgradeExperience;				//下级经验
    SCORE							lUpgradeRewardGold;					//升级奖励
    SCORE							lUpgradeRewardIngot;				//升级奖励
}CMD_GP_GrowLevelParameter;

//等级升级
typedef struct {
    SCORE							lCurrScore;							//当前游戏币
    SCORE							lCurrIngot;							//当前元宝
    TCHAR							szNotifyContent[128];				//提示内容
}CMD_GP_GrowLevelUpgrade;

//查询参数
typedef struct {
    DWORD							wExchangeRate;						//元宝游戏币兑换比率
    DWORD							wPresentExchangeRate;				//魅力游戏币兑换率
    DWORD							wRateGold;							//游戏豆游戏币兑换率
    WORD							wMemberCount;						//会员数目
    tagMemberParameter				MemberParameter[10];				//会员参数
}CMD_GP_ExchangeParameter;

//兑换游戏币
typedef struct {

    DWORD							dwUserID;							//用户标识
    SCORE							lExchangeIngot;						//兑换元宝
    TCHAR							szMachineID[33];		//机器标识
}CMD_GP_ExchangeScoreByIngot;

//兑换游戏币
typedef struct {

    DWORD							dwUserID;							//用户标识
    double							dExchangeBean;						//兑换元宝
    TCHAR							szMachineID[33];		//机器标识
}CMD_GP_ExchangeScoreByBean;

//兑换结果
typedef struct {
    bool							bSuccessed;							//成功标识
    SCORE							lCurrScore;							//当前游戏币
    SCORE							lCurrIngot;							//当前元宝
    double                          dCurrBeans;                         //当前游戏豆
    TCHAR							szNotifyContent[128];				//提示内容
}CMD_GP_ExchangeResult;

//请求配置
typedef struct {
    WORD							wKindID;								//游戏标识
    DWORD							dwUserID;							//用户标识
    TCHAR							szLogonPass[33];					//登录密码
}CMD_GP_LotteryConfigReq;

//抽奖配置
typedef struct {
    WORD							wLotteryCount;						//奖项个数
    tagLotteryItem					LotteryItem[16];				//奖项内容
}CMD_GP_LotteryConfig;

//抽奖信息
typedef struct {
    BYTE								cbFreeCount;							//免费次数
    BYTE								cbAlreadyCount;						//已领次数
    WORD							wKindID;								//游戏标识
    DWORD							dwUserID;							//用户标识
    SCORE							lChargeFee;							//抽奖费用
}CMD_GP_LotteryUserInfo;

//开始抽奖
typedef struct {
    WORD							wKindID;								//游戏标识
    DWORD							dwUserID;							//用户标识
    TCHAR							szLogonPass[33];					//登录密码
    TCHAR							szMachineID[33];			//机器序列
}CMD_GP_LotteryStart;

//抽奖结果
typedef struct {
    bool								bWined;								//中奖标识
    WORD							wKindID;								//游戏标识
    DWORD							dwUserID;							//用户标识
    SCORE							lUserScore;							//用户分数
    DOUBLE							dUserBeans;							//用户游戏豆
    tagLotteryItem					LotteryItem;							//中奖内容
}CMD_GP_LotteryResult;

typedef struct {
    WORD							wKindID;					//游戏标识
    DWORD							dwUserID;					//用户标识
    TCHAR							szDynamicPass[33];				//用户密码
}CMD_GP_QueryUserGameData;

typedef struct {
    WORD							wServerID;							//房间标识
    DWORD							dwMatchID;							//比赛标识
    DWORD							dwMatchNO;							//比赛场次

    DWORD							dwUserID;							//用户标识
    TCHAR							szPassword[33];				//登录密码

    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_MatchSignup;

typedef struct {
    WORD							wServerID;							//房间标识
    DWORD							dwMatchID;							//比赛标识
    DWORD							dwMatchNO;							//比赛场次
    DWORD							dwUserID;							//用户标识
    TCHAR							szPassword[33];				//登录密码

    TCHAR							szMachineID[33];		//机器序列
}CMD_GP_MatchUnSignup;

//报名结果
typedef struct {
    bool							bSignup;							//报名标识
    bool							bSuccessed;							//成功标识
    TCHAR							szDescribeString[128];				//描述信息
}CMD_GP_MatchSignupResult;
//操作失败
typedef struct{
    INT							lResultCode;						//错误代码
    TCHAR							szDescribeString[128];				//描述消息
}CMD_GP_OperateFailure;

//操作成功
typedef struct{
    INT							lResultCode;						//操作代码
    TCHAR							szDescribeString[128];				//成功消息
}CMD_GP_OperateSuccess;

//协调查找
typedef struct {
    DWORD							dwGameID;							//游戏标识
    TCHAR							szNickName[32];			//用户昵称
}CMD_GP_C_SearchCorrespond;

//协调查找
typedef struct {
    WORD							wUserCount;							//用户数目
    tagUserRemoteInfo				UserRemoteInfo[16];					//用户信息
}CMD_GP_S_SearchCorrespond;

typedef struct{
    WORD                wModuleID;                  //模块标识
    DWORD               dwPlazaVersion;             //广场版本
    BYTE                cbDeviceType;               //设备类型

    TCHAR	szMachineID[33];			//机器标识
    TCHAR	szMobilePhone[12];		//电话号码
}CMD_MB_LogonVisitor;

//游客验证
typedef struct{
    DWORD               dwUserID;                   //用户ID
}CMD_MB_OnlineCheck;

//锁房间
typedef struct{
    DWORD               dwServerID;                   //锁房间ID
}CMD_MB_LockServer;


typedef struct{
    DWORD             dwVersion;                 //版本id
    CHAR              szVersion[21];             //版本信息

    WORD	wModuleID;								//模块标识
    DWORD	dwPlazaVersion;							//广场版本
    DWORD	dwDeviceType;							//设备类型

    CHAR              szPassword550[33];        //550登录密码
    CHAR              szPassword2050[33];      //2050登录密码
    CHAR              szAccounts[32];      //登录帐号
    CHAR              szAccounts850[32];    //850登录帐号

    CHAR              szMachineID[33];    //机器标识
    CHAR              szMobilePhone[12];  //电话号码

    BYTE              cbPassPortID;
    CHAR              szPassPortID[19];

    CHAR              szUnionID[33];            //微信标识
    CHAR              szNickName[64];
    BYTE              cbGenter;                      //登录帐号

}CMD_MB_LogonAccounts_Lua;


typedef struct{
    DWORD             dwVersion;                 //版本id
    CHAR              szVersion[21];             //版本信息

    WORD    wModuleID;                              //模块标识
    DWORD   dwPlazaVersion;                         //广场版本
    DWORD   dwDeviceType;                           //设备类型

    CHAR              szPassword550[33];        //550登录密码
    CHAR              szPassword2050[33];      //2050登录密码
    CHAR              szAccounts[32];      //登录帐号
    CHAR              szAccounts850[32];    //850登录帐号

    CHAR              szMachineID[33];    //机器标识
    CHAR              szMobilePhone[12];  //电话号码

    BYTE              cbPassPortID;
    CHAR              szPassPortID[33];

    CHAR              szUnionID[33];            //微信标识
    CHAR              szNickName[64];
    BYTE              cbGenter;                      //登录帐号

}CMD_MB_LogonAccounts_Lua_Validate;

typedef struct{
    DWORD                           dwVersion;                          //版本id
    CHAR                            szVersion[21];             //版本信息
  //系统信息
    WORD              wModuleID;              //模块标识
    DWORD             dwPlazaVersion;            //广场版本
    DWORD             dwDeviceType;                       //设备类型
    CHAR              szAccounts[32];      //potato帐号
    CHAR             szOpenID[50];                 //OPENID
    CHAR              szMachineID[33];    //机器标识
    DWORD             dwSpreaderID;                       //推荐人ID
    CHAR              szSpreaderCode[33];                 //推广标识
    LONG              lReserved;              //保留字段
} CMD_MB_LogonPotato;


typedef struct{
    //系统信息
    DWORD                           dwPlazaVersion;                     //广场版本
    DWORD                           dwDeviceType;                       //设备类型

    //登录信息
    DWORD                           dwUserID;                           //用户ID
    CHAR                           szToken[33];                   //登录口令
}CMD_MB_LogonAccounts_Trump;

typedef struct {
    WORD              wModuleID;              //模块标识
    DWORD             dwPlazaVersion;            //广场版本
    BYTE              cbDeviceType;                       //设备类型

    CHAR              szPassword550[33];        //550登录密码
    CHAR              szPassword2050[33];      //2050登录密码
    CHAR              szAccounts[32];      //登录帐号
    CHAR              szAccounts850[32];    //850登录帐号

    CHAR              szMachineID[33];    //机器标识
    CHAR              szMobilePhone[12];  //电话号码

    BYTE              cbPassPortID;
    CHAR              szPassPortID[19];

    CHAR              szUnionID[33];            //微信标识
    CHAR              szNickName[64];
    BYTE              cbGenter;                      //登录帐号
    CHAR              szIdentityID[41];                   //标识
    CHAR              szChooseIndex[10];                  //坐标值
}CMD_MB_LogonAccounts_Validate;

typedef struct {
    int             ValidationFlag;       // 验证类型
    CHAR              szString[128];        // 验收参数（手机号码）
}CMD_GP_ValidatePassportIDFailure;

typedef struct{
        //版本信息
    DWORD       dwVersion;                          //版本id
    CHAR        szVersion[21];                      //版本信息

    WORD		wModuleID;							//模块标识
    DWORD		dwPlazaVersion;						//广场版本
    DWORD       dwDeviceType;                       //设备类型

    CHAR		szLogonPass[33];				//登录密码
    CHAR		szInsurePass[33];				//银行密码

    DWORD		dwSpreaderID;                       //推荐人
    BYTE		cbGender;							//用户性别
    CHAR		szAccounts[32];			//登录帐号
    CHAR		szPassPortID[19];                   //证件号码
    CHAR		szQQ[16];

    CHAR		szMachineID[33];		//机器标识
    CHAR		szMobilePhone[12];	//电话号码

}CMD_MB_RegisterAccountsWithSpreaderID_Lua;

typedef struct {
    //版本信息
    DWORD             dwVersion;                            //版本id
    CHAR              szVersion[21];                        //版本信息

    WORD              wModuleID;                            //模块标识
    DWORD             dwPlazaVersion;                       //广场版本
    DWORD             dwDeviceType;                         //设备类型

    CHAR              szAccounts[12];         //这里以手机号码做账号
    CHAR              szLogonPass[33];                 //登录密码
    CHAR              szInsurePass[33];                //银行密码

    DWORD             dwSpreaderID;                         //头像标识
    BYTE              cbGender;                             //用户性别
    CHAR              szNickName[32];             //登录帐号
    CHAR              szPassPortID[19];                     //证件号码
    CHAR              szQQ[16];
    CHAR              szMachineID[33];          //机器标识
    CHAR              szMobilePhone[12];      //号码
    CHAR              szSMSCode[7];                         //验证码
}CMD_MB_RegisterAccountsWithSMS_Lua;

typedef struct{
    //版本信息
    DWORD             dwVersion;                            //版本id
    CHAR              szVersion[21];                        //版本信息
    WORD		wModuleID;							//模块标识
    DWORD		dwPlazaVersion;						//广场版本
    BYTE        cbDeviceType;                       //设备类型

    BYTE        cbGender;                           //用户性别
    BYTE        cbPlatformID;                       //平台编号
    TCHAR       szUserUin[33];            //登录帐号
    TCHAR		szNickName[32];			//用户昵称
    TCHAR       zsCompellation[16];   //真实名字

    TCHAR		szMachineID[33];		//机器标识
    TCHAR		szMobilePhone[12];	//电话号码

}CMD_MB_LogonOtherPlatform;

//登陆成功
typedef struct{
    //版本信息
    DWORD   dwVersion;                              //版本id
    CHAR    szVersion[21];                          //版本信息

    WORD	wFaceID;								//头像标识
    BYTE	cbGender;								//用户性别
    DWORD	dwUserID;								//用户ID
    DWORD	dwGameID;								//游戏ID
    DWORD	dwExperience;							//经验数值
    DWORD	dwNewbie;							//用户魅力
    CHAR	szNickName[64];                         //用户昵称
    CHAR	szToken[33];                       //临时口令
    SCORE   lUserScore;	
}CMD_MB_LogonSuccess;

//快速登录成功
typedef struct{
    //版本信息
    DWORD             dwVersion;                          //版本id
    CHAR              szVersion[21];             //版本信息
    WORD              wFaceID;                      //头像标识
    BYTE              cbGender;                     //用户性别
    DWORD             dwUserID;                     //用户 I D
    DWORD             dwGameID;                     //游戏 I D
    DWORD             dwExperience;                 //经验数值
    DWORD             dwNewbie;                 //用户魅力
    int               nGuestState;                  //是否需要修改保险箱密码
    CHAR              szNickName[64];               //用户昵称
    CHAR              szToken[33];
    SCORE             lUserScore;
}CMD_MB_Guest_LogonSuccess;

//微信登录成功
typedef struct {
    //版本信息
    DWORD             dwVersion;                          //版本id
    CHAR              szVersion[21];             //版本信息
    WORD              wFaceID;                      //头像标识
    BYTE              cbGender;                     //用户性别
    DWORD             dwUserID;                     //用户 I D
    DWORD             dwGameID;                     //游戏 I D
    DWORD             dwExperience;                 //经验数值
    DWORD             dwNewbie;                 //用户魅力
    BYTE              cbChangeInsurePass;           //是否需要修改保险箱密码
    CHAR              szNickName[64];     //用户昵称
    CHAR              szLogonPass[33];
    SCORE             lUserScore;
}CMD_MB_WeiXin_LogonSuccess;

//QQ登录成功
typedef struct {
    DWORD             dwVersion;                    //版本id
    CHAR              szVersion[21];                //版本信息
    WORD              wFaceID;                      //头像标识
    BYTE              cbGender;                     //用户性别
    DWORD             dwUserID;                     //用户 I D
    DWORD             dwGameID;                     //游戏 I D
    DWORD             dwExperience;                 //经验数值
    DWORD             dwNewbie;                 //用户魅力
    BYTE              cbChangeInsurePass;           //是否需要修改保险箱密码
    CHAR              szNickName[64];     //用户昵称
    CHAR              szLogonPass[33];
    SCORE             lUserScore;
}CMD_MB_QQ_LogonSuccess;

//OPPO登录
typedef struct{
    //版本信息
    DWORD                           dwVersion;                          //版本id
    CHAR                            szVersion[21];             //版本信息

    //系统信息
    WORD                            wModuleID;                          //模块标识
    DWORD                           dwPlazaVersion;                     //广场版本
    DWORD                           dwDeviceType;                       //设备类型

    CHAR                            szAccounts[32];           //Oppo帐号
    CHAR                            szOpenID[50];                      //OPENID


    CHAR                            szMachineID[33];        //机器标识
    DWORD                           dwSpreaderID;                       //推荐人ID
    CHAR                            szSpreaderCode[33];                 //推广标识

    LONG                            lReserved;                          //保留字段
}CMD_MB_LogonOppo;

//vivo登录
typedef struct{
    //版本信息
    DWORD                           dwVersion;                          //版本id
    CHAR                            szVersion[21];             //版本信息
    //系统信息
    WORD                            wModuleID;                          //模块标识
    DWORD                           dwPlazaVersion;                     //广场版本
    DWORD                           dwDeviceType;                       //设备类型

    CHAR                            szAccounts[32];           //Oppo帐号
    CHAR                            szOpenID[50];                      //OPENID


    CHAR                            szMachineID[33];        //机器标识
    DWORD                           dwSpreaderID;                       //推荐人ID
    CHAR                            szSpreaderCode[33];                 //推广标识

    LONG                            lReserved;                          //保留字段
}CMD_MB_LogonVivo;

//第三方登录
typedef struct{
    //版本信息
    DWORD                           dwVersion;                          //版本id
    CHAR                            szVersion[21];             //版本信息

    //系统信息
    WORD                            wModuleID;                          //模块标识
    DWORD                           dwPlazaVersion;                     //广场版本
    DWORD                           dwDeviceType;                       //设备类型

    CHAR                            szAccounts[32];           //Oppo帐号
    CHAR                            szOpenID[50];                      //OPENID


    CHAR                            szMachineID[33];        //机器标识
    DWORD                           dwSpreaderID;                       //推荐人ID
    CHAR                            szSpreaderCode[33];                 //推广标识
    DWORD                           dwThirdPlatform;                    //第三方平台标识
    LONG                            lReserved;                          //保留字段
}CMD_MB_LogonThirdPlatform;

//oppo登录成功
typedef struct {
    //版本信息
    DWORD                           dwVersion;                          //版本id
    CHAR                            szVersion[21];             //版本信息
    WORD                            wFaceID;                            //头像标识
    BYTE                            cbGender;                           //用户性别
    DWORD                           dwUserID;                           //用户 I D
    DWORD                           dwGameID;                           //游戏 I D
    DWORD                           dwExperience;                       //经验数值
    DWORD                           dwNewbie;                       //用户魅力
    BYTE                            cbChangeInsurePass;                 //是否需要修改保险箱密码
    CHAR                            szNickName[64];           //用户昵称
    CHAR                            szLogonPass[33];
    SCORE                           lUserScore;                         //携带金币
}CMD_MB_Oppo_LogonSuccess;

//vivo登录成功
typedef struct {
    //版本信息
    DWORD                           dwVersion;                          //版本id
    CHAR                            szVersion[21];             //版本信息
    WORD                            wFaceID;                            //头像标识
    BYTE                            cbGender;                           //用户性别
    DWORD                           dwUserID;                           //用户 I D
    DWORD                           dwGameID;                           //游戏 I D
    DWORD                           dwExperience;                       //经验数值
    DWORD                           dwNewbie;                       //用户魅力
    BYTE                            cbChangeInsurePass;                 //是否需要修改保险箱密码
    CHAR                            szNickName[64];           //用户昵称
    CHAR                            szLogonPass[33];
    SCORE                           lUserScore;                         //携带金币
}CMD_MB_Vivo_LogonSuccess;

//第三方登录成功
typedef struct {
    //版本信息
    DWORD                           dwVersion;                          //版本id
    CHAR                            szVersion[21];             //版本信息
    WORD                            wFaceID;                            //头像标识
    BYTE                            cbGender;                           //用户性别
    DWORD                           dwUserID;                           //用户 I D
    DWORD                           dwGameID;                           //游戏 I D
    DWORD                           dwExperience;                       //经验数值
    DWORD                           dwNewbie;                       //用户魅力
    BYTE                            cbChangeInsurePass;                 //是否需要修改保险箱密码
    CHAR                            szNickName[64];           //用户昵称
    CHAR                            szLogonPass[33];
    SCORE                           lUserScore;                         //携带金币
    DWORD                           dwThirdPlatform;                    //第三方平台
}CMD_MB_ThirdPlatform_LogonSuccess;

//登陆失败
typedef struct{
	INT	lErrorCode;                                 //错误代码
	CHAR	szDescribeString[128];					//错误消息
}CMD_MB_LogonFailure;

//升级提示
typedef struct{
	BYTE	cbMustUpdate;							//强行升级
	BYTE	cbAdviceUpdate;							//建议版本
	DWORD	dwCurrentVersion;						//当前版本
}CMD_MB_UpdateNotify;

// 获取财神任务列表
typedef struct
{
    DWORD                           dwUserID;
}CMD_MB_C_TaskList;

// 领取财神任务奖励
typedef struct
{
    DWORD                           dwUserID;
    WORD                            dwEntryID;
    CHAR                            szToken[33];                   //临时密码
    CHAR                            szMachineID[33];               //机器标识
}CMD_MB_C_TaskPrize;

// 财神任务列表返回
typedef struct
{
    DWORD                           dwUserID;
    WORD                            wTaskCount;
    tagUserTaskItem                 tTaskItem[128];
}CMD_MB_S_TaskList;

// 财神任务奖励返回
typedef struct
{
    DWORD                           dwUserID;                           //用户id
    WORD                            wTaskID;                            //任务id
    LONGLONG                        lPrize;                             //奖励金额
}CMD_MB_S_TaskPrize;

//刷新金币
typedef struct{
    DWORD	dwUserID;                               //用户 I D
    WORD	wKindID;                                //游戏ID
}CMD_GP_UpdateUserData;

//获取在线
typedef struct{
    WORD							wServerCount;						//房间数目
    WORD							wOnLineServerID[1024];		//房间标识
}CMD_MB_GetOnline;

//类型在线
typedef struct{
    WORD							wKindCount;							//类型数目
    tagOnLineInfoKind				OnLineInfoKind[256];			//类型在线
}CMD_MB_KindOnline;

//房间在线
typedef struct{
    WORD							wServerCount;						//房间数目
    tagOnLineInfoServer				OnLineInfoServer[1024];		//房间在线
}CMD_MB_ServerOnline;

//房间列表
typedef struct{
    DWORD       dwDevice;      //设备号
}CMD_MB_GetServerList_Lua;

//查询玩家手机绑定和完善信息
typedef struct {
    DWORD                           dwUserID;
    CHAR                            szTempPassWord[33];                //临时密码
}CMD_GP_MB_CheckBindMobileAndInvali;

//查询结果
typedef struct  {
    BYTE                            isBindMobile;                           //是否绑定手机
    BYTE                            isAddInvali;                            //是否完善资料
    BYTE                            isBindWechat;                           //是否绑定微信
}DBO_CheckBindMobileAndInvali;

//新版绑定手机需要带验证码
typedef struct {
    DWORD                           dwUserID;
    CHAR                            szTempPassword[33];           //临时密码
    CHAR                            szMobilePhone[12];        //移动电话
    CHAR                            szSMSCode[7];                           //短信验证码
}CMD_GP_MB_BindMobile;

//绑定手机结果
typedef struct {
    LONGLONG                        lResultCode;
    CHAR                            szDescribeString[128];        //描述消息
}CMD_GP_RESULT_MB;

//游客账号绑定手机号
typedef struct
{
    BYTE                  cbType;
    DWORD                 dwUserID;
    DWORD                 dwDevice;
    CHAR                  szPassword[33];        //登录密码
    CHAR                  szAccounts[32];      //登录帐号
    CHAR                  szMachineID[33];    //机器标识
    CHAR                  szMobilePhone[12];  //电话号码
    CHAR                  szToken[33];        //登录密码
    CHAR                  szPassPortID[19];
    CHAR                  szQQ[16];
    CHAR                  szSMSCode[7];                     //短信验证码
    CHAR                  szNickName[32];     //昵称
}CMD_GP_AddInvali_MB_WithSMS_Lua;

typedef struct {
    BYTE                  cbType;
    DWORD                 dwUserID;
    DWORD                 dwDevice;
    CHAR                  szPassword[33];        //登录密码
    CHAR                  szAccounts[32];      //登录帐号
    CHAR                  szMachineID[33];    //机器标识
    CHAR                  szMobilePhone[12];  //电话号码
    CHAR                  szToken[33];        //登录密码
    CHAR                  szPassPortID[19];
    CHAR                  szQQ[16];
    CHAR                  szSMSCode[7];
    CHAR                  szNickName[32];    //昵称
}CMD_GP_Wechat_AddInvali_MB_WithSMS_Lua;

typedef struct {
    int                            nReturnCode;
    CHAR                           szAccounts[32];
    CHAR                           szDescribeString[128];          
}CMD_GP_SetGuest_Rev;

typedef struct {
    int                            nReturnCode;
    CHAR                           szAccounts[32];
    CHAR                           szDescribeString[128];          
}DBO_GP_SetWechat_Rev;

typedef struct {
    WORD                           wFaceID;                            //头像标识
    DWORD                          dwUserID;                           //用户 I D
    CHAR                           szPassword[33];           //用户密码
    CHAR                           szMachineID[33];        //机器序列
}CMD_GP_SystemFaceInfo;

typedef struct {
    WORD                            wFaceID;                            //头像标识
    DWORD                           dwCustomID;                         //自定标识
}CMD_GP_UserFaceInfo;

//操作失败
typedef struct {
    LONG                            lResultCode;                        //操作代码
    TCHAR                           szDescribeString[128];              //描述消息
}DBO_GP_OperateFailure;

#pragma pack()

