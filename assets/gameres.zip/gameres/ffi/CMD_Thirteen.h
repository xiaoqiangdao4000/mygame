#pragma pack(1)

typedef struct 
{
    BYTE                                bFrontCard[3];           //前墩扑克
    BYTE                                bMidCard[5];             //中墩扑克
    BYTE                                bBackCard[5];            //后墩扑克
    BYTE                                bCardType[3];
}Sss_tagCardInfo;
  
//发送扑克
typedef struct 
{
    BYTE                                bCardData[13];           //手上扑克
    BYTE                                enAnalySe;               //特殊牌型标识
    BYTE                                enShui;                  //特殊牌型水数
    BYTE                                chairid[4];              //有效椅子号
    Sss_tagCardInfo                     cardinfo[4];             //牌型提示                          
}Sss_CMD_S_GameStart;

//信息
typedef struct 
{
    WORD        wWinPlayer;
    WORD        wLosePlayer;
}Sss_tagShootInfo;

typedef struct 
{
    int         basewin;  
    int         Frontbase;  
    int         Midbase;  
    int         Backbase;     
    int         allWin;
    int         FrontWin;
    int         MidWin;
    int         BackWin;
}Sss_CompareShui;

//游戏结束
typedef struct 
{
    LONGLONG                            lGameScore[4];                  //游戏总成绩
    WORD                                wSwatPlayer;                    //全垒打玩家     INVALID_CHAIR 表示没有全垒打玩家                        
    BYTE                                enSpecial[4];                   //特殊牌型
    Sss_tagCardInfo                     cardinfo[4];                    //玩家分段信息
    Sss_CompareShui                     allwinsui[4];                   //总盈利水数
    Sss_tagShootInfo                    comparisonInfo[6];              //玩家比牌信息
}Sss_CMD_S_GameEnd;

//玩家摊牌
typedef struct 
{
    WORD                                wUser;                              //当前玩家
}Sss_CMD_S_ShowCard;

typedef struct 
{
    BYTE                                code;                               //自己开牌结果
}Sss_CMD_S_ShowCardRes;

//用户强退
typedef struct 
{
    WORD                                wUserChairID;                       //强退用户
}Sss_CMD_S_UserLeft;


//空闲状态
typedef struct 
{
    LONGLONG                            cellScore;                          //下注大小 
}Sss_CMD_S_StatusFree;

//游戏状态
typedef struct 
{
    LONGLONG                            cellScore;                          //下注大小 
    BYTE                                bHandCardData[13];                  //扑克数据  
    bool                                bFinishSegment[4];                  //完成分段  
    Sss_tagCardInfo                     bCardinfo[4];                       //自己默认分段 
    BYTE                                bRemainSecond;                      //剩余时间
    BYTE                                enAnalySe;
    BYTE                                enShui;
    BYTE                                bPlayChair[4];
}Sss_CMD_S_StatusPlay;

//结算状态
typedef struct 
{
    LONGLONG                            cellScore;                          //下注大小   
    LONGLONG                            lGameScore[4];                      //游戏总成绩
    WORD                                wSwatPlayer;
    BYTE                                enSpecial[4];                       //特殊牌型
    Sss_tagCardInfo                     bSegmentCard[4];                    //分段扑克
    Sss_CompareShui                     allwinsui[4];
    Sss_tagShootInfo                    comparisonInfo[6];
    BYTE                                bPlayChair[4];
    BYTE                                bRemainSecond;
}Sss_CMD_S_StatusEnding;

//分段信息
typedef struct 
{
    Sss_tagCardInfo                     cardinfo;                           //分段
    bool                                bRegister;                          //是否选择特殊牌型
}Sss_CMD_C_ShowCard;

#pragma pack()

