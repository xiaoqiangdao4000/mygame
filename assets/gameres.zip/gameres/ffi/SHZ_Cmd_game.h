#pragma pack(1)


//水浒传游戏
typedef struct {
	LONGLONG						lJettonScore;							//单线下注数目
}SHZ_CMD_C_Bet;

//猜大小游戏
typedef struct {
	BYTE						cbBigSmall;							//猜大小，0为小（0-6），1为和（7）， 2为大（8-12）
}SHZ_CMD_C_BigSmall;


//游戏状态
typedef struct {
	LONGLONG				lWinScore;							//开奖赢分
	LONGLONG				lJettonScore;						//下注分数
	BYTE					cbCardArray[15];					//水浒传牌型数据
	BYTE     				cbFullID;       					//全屏将对应的元素ID  
	WORD					cbMaryGames;						//Mary游戏次数
	BYTE     				cbLines[9][5];  					//中奖线数据 
	BYTE					cbExternalData;						//Mary游戏外圈数据
	BYTE					cbInternalArray[4];					//Mary游戏内圈牌型数据
	LONGLONG				lMaryScore;							//最近一次Mary游戏分数
	BYTE					cbBigSmallRecord[10];					//Mary游戏内圈牌型数据
	LONGLONG   				lBetScore[5];       //可下注的筹码 };
}SHZ_CMD_S_Status;

//用户下注
typedef struct {
	  BYTE     cbCardArray[15];    		//牌型数据
	  LONGLONG lWinScore;       			//开奖赢分  
	  BYTE     cbFullID;       			//全屏将对应的元素ID  
	  BYTE     cbMaryGames;      			//Mary游戏次数  
	  BYTE     cbLines[9][5];  	//中奖线数据 
}SHZ_CMD_S_Bet;

//收分
typedef struct {
	LONGLONG				lWinScore;							//开奖赢分
	LONGLONG				lUserScore;							//玩家积分
}SHZ_CMD_S_GetScore;

//Mary游戏
typedef struct {
	WORD					cbMaryGames;						//Mary游戏次数
	BYTE					cbExternalData;						//外圈第几个中奖
	BYTE					cbInternalArray[4];					//内圈牌型数据
	LONGLONG				lWinScore;							//开奖赢分
	LONGLONG				lMaryScore;							//最近一次Mary游戏分数
}SHZ_CMD_S_Mary;

//猜大小
typedef struct {
	BYTE					cbBigSmall[2];						//大小的实际数值
	LONGLONG				lWinScore;							//玩家成绩
	LONGLONG				lScore;								//本次获的游戏分数
}SHZ_CMD_S_BigSmall;


typedef unsigned long long  ULONGLONG;

#pragma pack()

