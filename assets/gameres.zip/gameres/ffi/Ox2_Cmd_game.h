#pragma pack(1)

//空闲状态
typedef struct {
    LONGLONG								lCellScore;
}Ox2_CMD_S_StatusFree;

//抢庄状态
typedef struct {
    WORD								wCallBanker;						//叫庄用户
}Ox2_CMD_S_StatusBank;

//下注信息
typedef struct {
    LONGLONG								lTurnMaxScore;					//最大下注
    LONGLONG								lBet[2];              //下注数目
    WORD                                    wBankUser;                      //庄家用户
}Ox2_CMD_S_StatusBet;

typedef struct {
    LONGLONG								lTurnMaxScore;                          //最大下注
    LONGLONG								lBet[2];                      //下注数目
    WORD                                    wBankUser;                              //庄家用户

    BYTE                                    bCardData[2][5];      //桌面扑克
    BYTE                                    bOperateType[2];				//牛牛数据
}Ox2_CMD_S_StatusPlay;

typedef struct {
    LONGLONG								lTurnMaxScore;                          //最大下注
    WORD                                    wBankUser;                              //庄家用户
}Ox2_CMD_S_GameStart;

//用户叫庄
typedef struct {
    WORD                                    wCallBanker;						//叫庄用户
    bool                                    bStart;
}Ox2_CMD_S_CallBank;

//用户下注
typedef struct {
    WORD                                    wCurrentUser;						//加注用户
    LONGLONG                                lBaseBet;                           //加注数目
}Ox2_CMD_S_GameBet;

//发牌数据包
typedef struct {
    BYTE                                    cbCardData[2][5];	//用户扑克
}Ox2_CMD_S_SendCard;

//用户摊牌
typedef struct {
    WORD								wCurrentUser;							//摊牌用户
    BYTE								cbOperateType;							//摊牌标志
}Ox2_CMD_S_OperateCard;

//用户强退
typedef struct {
    WORD                                wCurrentUser;                           //当前用户
}Ox2_CMD_S_GameQuit;

//游戏结束
typedef struct {
    LONGLONG								lGameTax[2];				//游戏税收
    LONGLONG								lGameScore[2];			//游戏得分
    BYTE									cbCardData[2];			//用户扑克
}Ox2_CMD_S_GameEnd;

//游戏定庄
typedef struct {
    BYTE 				 			bBankUser;						    //庄家用户
}Ox2_CMD_C_GameSetBank;

//游戏下注
typedef struct {
    LONGLONG                         nServriValue;
    LONGLONG                         lBet;                               //下注数目
}Ox2_CMD_C_GameBet;

//用户摊牌
typedef struct {
    LONGLONG                            nServriValue;
    BYTE								cbOperateType;								//牛牛标志
}Ox2_CMD_C_OperateCard;

#pragma pack()
