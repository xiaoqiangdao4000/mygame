#pragma pack(1)

//核实下注
typedef struct {
	LONGLONG						llPlaceScore;						//当前下注
}CMD_S_SDB_CheckPlaceJetton;

typedef struct {
	BYTE							byTimeLeave;						//剩余时间
	LONGLONG						lApplyBankerCondition;				//申请条件
	WORD							wBankerUser;						//当前庄家
	WORD							wBankerTimes;						//庄家局数
	LONGLONG						lBankerWinScore;					//庄家成绩
	int								nRobBanker;							//抢庄人数
	LONGLONG						lAreaLimitScore;					//区域限制
}CMD_S_SDB_StatusFree;

//下注状态
typedef struct {
	CMD_S_SDB_StatusFree StatusFree;
	LONGLONG lPlaceJetton[150];			//玩家下注
	LONGLONG lTotalJetton;							//下注总数
}CMD_S_SDB_StatusPlace;

//庄家要牌状态
typedef struct {
	CMD_S_SDB_StatusFree StatusFree;
	LONGLONG lPlaceJetton[150];			//玩家下注
	LONGLONG lTotalJetton;							//下注总数
	BYTE byBankerCardData[5];
	int nBankerCardCount;
	BYTE byPlayerCardData[5];
	int nPlayerCardCount;
	bool bStopGet;
}CMD_S_SDB_StatusBanker;

//闲家要牌状态
typedef struct {
	CMD_S_SDB_StatusFree StatusFree;
	LONGLONG lPlaceJetton[150];			//玩家下注
	LONGLONG lTotalJetton;							//下注总数
	BYTE byBankerCardData[5];
	int nBankerCardCount;
	BYTE byPlayerCardData[5];
	int nPlayerCardCount;
	bool bStopGet;
}CMD_S_SDB_StatusPlayer;

typedef struct {
    TCHAR                           szUserName[32];
    LONGLONG                        lWInScore;
}SDB_tagRankUser;

//结束状态
typedef struct {
	CMD_S_SDB_StatusFree StatusFree;
	LONGLONG lPlaceJetton[150];			//玩家下注
	LONGLONG lTotalJetton;							//下注总数
	BYTE byBankerCardData[5];
	int nBankerCardCount;
	BYTE byPlayerCardData[5];
	int nPlayerCardCount;
    BYTE                            cbRankCount;                        //结算实际人数
    SDB_tagRankUser                     RankUser[5];                        //结算玩家结果
}CMD_S_SDB_StatusGameEnd;

typedef struct {
	BYTE							byTimeLeave;						//剩余时间
	LONGLONG						lAreaLimitScore;					//区域限制
	LONGLONG						lUserMaxScore;						//分数上限

	WORD							wBankerUser;						//庄家用户
}CMD_S_SDB_GameStart;

//用户下注
typedef struct {
	WORD							wChairID;						//当前用户
	LONGLONG						lJettonScore;						//当前倍数
	LONGLONG						lMaxScore;						//最大筹码
}CMD_S_SDB_PlaceJetton;

//下注分满
typedef struct {
	BYTE							byTimeLeave;
}CMD_S_SDB_ScoreFull;

//用户下注
typedef struct {
	WORD							wAddUser;						//当前用户
	LONGLONG						lAddScore;						//当前倍数
}CMD_S_SDB_AddScoreFailed;

//系统发牌
typedef struct {
	WORD							wCurrentUser;					//要牌用户
	BYTE							byCardData;						//牌数据
}CMD_S_SDB_SendCard;

//开始要牌
typedef struct {
	BYTE							byTimeLeave;					//剩余时间
	bool							bBankerUser;					//是否为庄家
}CMD_S_SDB_BeginGet;

//玩家要牌
typedef struct {
	WORD							wCurrentUser;					//要牌用户
	BYTE							byCardData;						//牌数据
}CMD_S_SDB_GetCard;

//停止要牌
typedef struct {
	bool							bStopGet;						//是否还能要牌
	BYTE							bSendCard;						//是否是要牌阶段
}CMD_S_SDB_StopGet;

//游戏结束
typedef struct {
	BYTE							byTimeLeave;					//剩余时间
	int								nWinType;
	LONGLONG						lBankerWinScore;				//庄家得分
	LONGLONG						lPlayerWinScore;				//玩家得分
	LONGLONG						lBankerRevenue;					//游戏税收
	LONGLONG						lPlayerRevenue;					//游戏税收
	BYTE							byBankerCardData[5];	//比牌用户
	int							nBankerCardCount;				//庄家牌数量
	LONGLONG						iBankerTotallScore;					//庄家累计输赢分数
	int								nBankerTime;						//做庄次数

    BYTE                            cbRankCount;                        //结算实际人数
    SDB_tagRankUser                     RankUser[5];                        //结算玩家结果
}CMD_S_SDB_GameEnd;

//游戏空闲
typedef struct {
	BYTE							byTimeLeave;					//剩余时间
	WORD							wBankerTimes;//坐庄次数
	LONGLONG						lBankerWinScore;	//庄家成绩
}CMD_S_SDB_GameFree;

//申请上庄
typedef struct {
	WORD							wApplyUser;			//申请玩家
	int								nRobBanker;			//抢庄的人数
}CMD_S_SDB_ApplyBanker;

//取消申请
typedef struct {
	WORD							wApplyUser;			//申请玩家
	int								nRobBanker;			//抢庄的人数
}CMD_S_SDB_CancelApply;

//我要下庄
typedef struct {
	WORD							wBankerUser;			//庄家
	int								nRobBanker;			//抢庄的人数
}CMD_S_SDB_ChangeBanker;
//申请抢庄
typedef struct {
	WORD							wApplyUser;			//申请抢庄
	int								nRobBanker;			//抢庄的人数
}CMD_S_SDB_RobBanker;
//玩家结果
typedef struct {
	WORD wChairID;
	BYTE byCardType;
	BYTE byCardPoint;
	LONGLONG lWinScore;
}SDB_tagGameResult;
typedef struct {
	LONGLONG							lMoney;								//金额
}SDB_CMD_S_RobotGetMoney;
//确认状态
typedef struct {
	LONGLONG						lPlaceJetton;						//玩家下注
	BYTE							cbStopGet;							//是否已停止要牌
	BYTE							cbCardCount;						//玩家牌数
	BYTE							cbCardData[5];				//玩家牌信息
}CMD_S_SDB_CheckState;

//用户加注
typedef struct {
	LONGLONG							lJettonScore;								//加注数目
}CMD_C_SDB_PlaceJetton;

//输赢控制
typedef struct {
	bool bWin;
	WORD wChairID;
	WORD wTableID;
}CMD_C_SDB_ManageControl;
//确认状态
typedef struct {
	BYTE							cbClientState;							//客户端状态
	BYTE							cbStopGet;								//是否已停牌
	BYTE							cbWantedCardCount;						//应该几张牌
}CMD_C_SDB_CheckState;

#pragma pack()
