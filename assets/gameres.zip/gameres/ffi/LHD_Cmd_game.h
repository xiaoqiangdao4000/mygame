#pragma pack(1)


//游戏状态
typedef struct 
{
	BYTE							cbGameStatus;						//游戏状态
	BYTE							cbTimeLeave;						//剩余时间

	LONGLONG						lAllBet[3];							//总下注
	LONGLONG						lPlayBet[3];						//玩家下注

	LONGLONG						lAllPlayScore[3];					//区域输赢
	LONGLONG						lPlayScore[3];						//玩家输赢
	LONGLONG						lPlayAllScore;						//玩家成绩

	LONGLONG						lPlayBetScore;						//玩家最大下注	
	LONGLONG						lPlayFreeSocre;						//玩家自由金币

	BYTE							cbTableCardArray[2];				//桌面扑克
	BYTE							cbWinner;							//哪方赢（0没意义，1龙，2虎，3和）
	
	LONGLONG						lAreaLimitScore[3];					//各区域限制
	LONGLONG						lUserLimitScore;					//每局总下注限制

	DWORD							dwResultHistory[100];				//趋势

	DWORD                   		dwServerId;
    DWORD                           dwResultIndex;                      //历史记录个数
    LONGLONG                        lBetMin;        //最小下注限制
}LHD_CMD_S_Status;

//用户下注
typedef struct 
{
	WORD							wChairID;							//用户位置
	BYTE							cbBetArea;							//筹码区域
	LONGLONG						lBetScore;							//加注数目
}LHD_CMD_S_PlaceBet;

typedef struct
{
	WORD							wChairID;							//用户位置
	BYTE							cbBetArea;
	LONGLONG                        lBetScore[10];						//筹码金额
	LONGLONG                        lBetNumber[10];						//筹码数量
	bool       						bSucees;       						//下注结果  
	TCHAR       					bFailureDesc[256];     				//失败描述
}LHD_CMD_S_PlaceBetEx;

//失败结构
typedef struct 
{
	WORD							wPlaceUser;							//下注玩家
	BYTE							lBetArea;							//下注区域
	LONGLONG						lPlaceScore;						//当前下注
}LHD_CMD_S_PlaceBetFail;

//游戏空闲
typedef struct 
{
	BYTE							cbTimeLeave;						//剩余时间
}LHD_CMD_S_GameFree;

//游戏开始
typedef struct 
{
	BYTE							cbTimeLeave;						//剩余时间
	LONGLONG						lPlayBetScore;						//玩家最大下注	
	LONGLONG						lPlayFreeSocre;						//玩家自由金币
	int								nChipRobotCount;					//人数上限 (下注机器人)
	LONGLONG						lAreaLimitScore[3];					//各区域限制
	LONGLONG						lUserLimitScore;					//每局总下注限制
}LHD_CMD_S_GameStart;

//游戏结束
typedef struct 
{
	BYTE							cbTimeLeave;						//剩余时
	BYTE							cbTableCardArray[2];				//桌面扑克
	LONGLONG						lAllPlayScore[3];					//区域输赢
	LONGLONG						lPlayScore[3];						//玩家成绩
	LONGLONG						lPlayAllScore;						//玩家成绩
	BYTE							cbWinner;							//哪方赢（0没意义，1龙，2虎, 3和）
    DWORD                           dwResultIndex;                      //历史记录个数
}LHD_CMD_S_GameEnd;


//用户下注
typedef struct 
{
	BYTE							cbBetArea;							//筹码区域
	LONGLONG						lBetScore;							//加注数目
}LHD_CMD_C_PlaceBet;	

//续压
typedef struct 
{
	BYTE							cbBetArea;							//下注区域
	LONGLONG                        lBetScore[10];						//筹码金额
	LONGLONG                        lBetNumber[10];						//筹码数量
}LHD_CMD_C_PlaceBetEx;

#pragma pack()
