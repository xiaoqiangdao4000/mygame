#pragma pack(1)

typedef struct{
    WORD				wTypeID;					//类型索引
	WORD				wSortID;					//排序索引
	CHAR				szTypeName[32];		//种类名字
}tagGameType;

typedef struct{
	WORD				wTypeID;					//类型索引
	WORD				wJoinID;					//挂接索引
	WORD				wSortID;					//排序索引
	WORD				wKindID;					//类型索引
	WORD				wGameID;					//模块索引 
	DWORD				dwOnLineCount;				//在线人数
	DWORD				dwFullCount;				//满员人数
	CHAR				szKindName[32];             //游戏名字
	CHAR				szProcessName[32];			//进程名字
}tagGameKind;

typedef struct{
    WORD				wSortID;					//排序号码
    WORD				wKindID;					//名称号码
    WORD				wJoinID;					//挂接号码
    WORD				wStationID;					//站点号码
    CHAR				szStationName[32];          //站点名称
}tagGameNode;

typedef struct{
    WORD				wJoinID;					//挂接索引
    WORD				wSortID;					//排序索引
    WORD				wTypeID;					//类型索引
    CHAR				szTypeName[32];				//种类名字
}tagGameServerType;

typedef struct{
    WORD				wKindID;					//名称索引
    WORD				wNodeID;					//节点索引
    WORD				wSortID;					//排序索引
    WORD				wServerID;					//房间索引
    WORD				wServerPort;				//房间端口
    DWORD               dwOnLineCount;				//在线人数
    DWORD               dwFullCount;				//满员人数
    DWORD               dwMinEnterScore;            //进入分数
    CHAR                szServerAddr[32];			//房间名称
    CHAR				szServerName[32];			//房间名称
}tagGameServer;

typedef struct{
    WORD				wKindID;					//名称索引
    WORD				wNodeID;					//节点索引
    WORD				wSortID;					//排序索引
    WORD				wServerID;					//房间索引
    WORD				wServerPort;				//房间端口
    DWORD               dwOnLineCount;				//在线人数
    DWORD               dwFullCount;				//满员人数
    DWORD               dwMinEnterScore;            //进入分数
    CHAR                szServerAddr[32];			//房间名称
    CHAR				szServerName[32];			//房间名称
    DWORD               dwCellScore;				//房间底分
}tagGameServer_MB;

//比赛报名
typedef struct {
	WORD							wServerID;							//房间标识
	DWORD							dwMatchID;							//比赛标识
	DWORD							dwMatchNO;							//比赛场次
}tagSignupMatchInfo;

typedef struct {
	WORD							wServerID;							//房间标识
    DWORD							dwMatchID;							//比赛标识
	DWORD							dwMatchNO;							//比赛场次
	BYTE							cbMatchType;						//比赛类型
	TCHAR							szMatchName[32];					//比赛名称

	BYTE							cbMemberOrder;						//会员等级
	BYTE							cbMatchFeeType;						//扣费类型
	SCORE							lMatchFee;							//比赛费用

	WORD							wStartUserCount;					//开赛人数
	WORD							wMatchPlayCount;					//比赛局数

    WORD                            wRewardCount;                       //奖励人数

	SYSTEMTIME						MatchStartTime;						//开始时间
	SYSTEMTIME						MatchEndTime;						//结束时间
}tagGameMatch;

//视频配置
typedef struct {
	WORD							wAVServerPort;						//视频端口
	DWORD							dwAVServerAddr;						//视频地址
}tagAVServerOption;

//在线信息
typedef struct{
	WORD				wKindID;					//类型标识
	DWORD				dwOnLineCount;				//在线人数
}tagOnLineInfoKind;

//在线统计
typedef struct {
	WORD							wKindID;							//类型标识
	DWORD							dwOnLineCount;						//在线人数
	DWORD							dwAndroidCount;						//机器人数
}tagOnLineInfoKindEx;

//在线信息
typedef struct{
	WORD				wServerID;					//房间标识
	DWORD				dwOnLineCount;				//在线人数
}tagOnLineInfoServer;

typedef struct {
    WORD								wFaceID;							//头像索引
    DWORD								dwCustomFaceVer;					//上传头像
    DWORD								dwUserID;							//用户 I D
    DWORD								dwGroupID;							//社团索引
    DWORD								dwGameID;							//用户 I D
    DWORD								dwUserRight;						//用户等级
    int                                 lLoveliness;						//用户魅力
    DWORD								dwMasterRight;						//管理权限
    char								szName[64];					//用户名字
    char								szNickName[64];				//用户昵称
    char								szGroupName[32];				//社团名字
    char								szUnderWrite[32];		//个性签名

    WORD								wGender;							//用户性别
    BYTE								cbMemberOrder;						//会员等级
    BYTE								cbMasterOrder;						//管理等级

    LONGLONG							lInsureScore;						//消费金币
    LONGLONG							lGameGold;							//游戏金币
    LONGLONG							lScore;								//用户分数

    LONGLONG							lSilverScore;						//银币
    LONGLONG							lInsureSilverScore;					//银行银币

    LONGLONG							lIngot;								//元宝
    LONGLONG							lHappyBear;							//欢乐豆

    LONGLONG							lBodyScore;							//身上灵珠
    LONGLONG							lBodySilverScore;					//身上银币
    LONGLONG							lBodyChip;							//身上筹码

    int								lWinCount;							//胜利盘数
    int								lLostCount;							//失败盘数
    int								lDrawCount;							//和局盘数
    int								lFleeCount;							//断线数目
    int								lExperience;						//用户经验

    WORD								wTableID;							//桌子号码
    WORD								wChairID;							//椅子位置
    BYTE								cbUserStatus;						//用户状态

    BYTE								cbCompanion;						//用户关系
    DWORD								dwPropResidualTime[15];	//道具时间

    LONGLONG							lLostMoney;							//游戏输分
    char                               szUserAddress[32];                       //用户地址
}tagUserData;

#pragma mark -
#pragma mark 用户信息

typedef struct{
	BYTE				cbTableLock;				//锁定标志
	BYTE				cbPlayStatus;				//游戏标志
}tagTableStatus;

typedef struct{
	WORD				wTableID;					//桌子索引
	WORD				wChairID;					//椅子位置
	BYTE				cbUserStatus;				//用户状态
}tagUserStatus;

typedef struct{
    BYTE               cbCompanion;                 //用户关系

}tagUserAttrib;

typedef	struct{
	LONGLONG			lScore;						//用户分数
    LONGLONG            lGrade;                     //用户成绩
	LONGLONG			lBanker;					//银行分数
    LONGLONG            lIngot;                     //用户元宝

	DWORD				dwWinCount;					//胜利盘数
	DWORD				dwLostCount;				//失败盘数
	DWORD				dwDrawCount;				//和局盘数
	DWORD				dwFleeCount;				//逃跑盘数

	DWORD				dwUserMedal;				//用户奖牌
	DWORD				dwExperience;				//用户经验
	DWORD				dwLoveLiness;				//用户魅力

}tagUserScore;

#pragma mark -
#pragma mark 用户积分
typedef struct{
	SCORE							lScore;								//用户分数
	DWORD							dwWinCount;							//胜利盘数
	DWORD							dwLostCount;						//失败盘数
	DWORD							dwDrawCount;						//和局盘数
	DWORD							dwFleeCount;						//逃跑盘数

	DWORD							dwExperience;						//用户经验
}tagMobileUserScore;

//道具使用
typedef struct {
    WORD                            wPropertyCount;                     //道具数目
    WORD                            dwValidNum;                         //有效数字
    DWORD                           dwEffectTime;                       //生效时间
}tagUsePropertyInfo;

typedef struct {
    WORD                            wPropertyUseMark;                   //道具标示
    tagUsePropertyInfo              PropertyInfo[4];           //使用信息
}tagUserProperty;

//道具包裹
typedef struct {

    WORD                            wTrumpetCount;                      //小喇叭数
    WORD                            wTyphonCount;                       //大喇叭数
}tagPropertyPackage;

//时间信息
typedef struct {

	DWORD						dwEnterTableTimer;						//进出桌子时间
	DWORD						dwLeaveTableTimer;						//离开桌子时间
	DWORD						dwStartGameTimer;						//开始游戏时间
	DWORD						dwEndGameTimer;							//离开游戏时间
}tagTimeInfo;

typedef struct{
	DWORD				dwUserID;						//用户I D
	DWORD				dwGameID;						//游戏I D
	DWORD				dwGroupID;						//社团I D

	TCHAR				szNickName[32];		//用户昵称
	TCHAR				szGroupName[32];	//社团名字
	TCHAR				szUnderWrite[32];	//个性签名

	DWORD				wFaceID;						//头像索引
	DWORD				dwCustomID;						//自定标识

	BYTE				cbGender;						//用户性别
	BYTE				cbMemberOrder;					//会员等级
	BYTE				cbMasterOrder;					//管理等级

	WORD				wTableID;						//桌子索引
    WORD                wLastTableID;                   //游戏桌子
	WORD				wChairID;						//椅子索引
	BYTE				cbUserStatus;					//用户状态

	SCORE				lScore;							//用户分数
	SCORE				lGrade;							//用户成绩
	SCORE				lInsure;						//银行分数
	SCORE               lIngot;                         //用户元宝

	DWORD				dwWinCount;						//胜利盘数
	DWORD				dwLostCount;					//失败盘数
	DWORD				dwDrawCount;					//和局盘数
	DWORD				dwFleeCount;					//逃跑盘数
	DWORD				dwExperience;					//用户经验
	INT				dwLoveLiness;					//用户魅力

    tagTimeInfo         TimerInfo;                      //时间信息

}tagUserInfo;

typedef struct {

	DWORD				dwGameID;						//游戏I D
	DWORD				dwUserID;						//用户I D
    DWORD               dwGroupID;                      //社团id

	WORD				wFaceID;						//头像索引
	DWORD				dwCustomID;						//自定标识

    bool                BIsAndroid;                     //机器标示
	BYTE				cbGender;						//用户性别
	BYTE				cbMemberOrder;					//会员等级
    BYTE                cbMasterOrder;                  //管理等级

	WORD				wTableID;						//桌子索引
	WORD				wChairID;						//椅子索引
	BYTE				cbUserStatus;					//用户状态

	SCORE				lScore;							//用户分数
    SCORE               lGrade;                         //用户成绩
    SCORE               lInsure;                        //用户银行
    SCORE               lIngot;                         //用户元宝

	DWORD				dwWinCount;						//胜利盘数
	DWORD				dwLostCount;					//失败盘数
	DWORD				dwDrawCount;					//和局盘数
	DWORD				dwFleeCount;					//逃跑盘数
	DWORD				dwExperience;					//用户经验
    INT                lLoveliness;                    //用户魅力
}tagUserInfoHead;

typedef struct{
	DWORD				dwDataSize;						//数据大小
	DWORD				dwCutstomFace[48*48];	//图片信息
}tagCustomFaceInfo;

typedef struct{
	DWORD							dwUserID;							//用户标识
	DWORD							dwGameID;							//游戏标识
	TCHAR							szNickName[32];			//用户昵称

	BYTE							cbGender;							//用户性别
	BYTE							cbMemberOrder;						//会员等级
	BYTE							cbMasterOrder;						//管理等级

	WORD							wKindID;							//类型标识
	WORD							wServerID;							//房间标识
	TCHAR							szGameServer[32];			//房间位置
}tagUserRemoteInfo;

typedef struct {
	WORD							wTaskID;							//任务标识
	WORD							wTaskType;							//任务类型
    WORD							wTaskObject;						//任务目标
	BYTE							cbPlayerType;						//玩家类型
	WORD							wKindID;							//类型标识
	DWORD							dwTimeLimit;						//时间限制

	SCORE							lStandardAwardGold;					//奖励金币
	SCORE							lStandardAwardMedal;				//奖励奖牌
	SCORE							lMemberAwardGold;					//奖励金币
	SCORE							lMemberAwardMedal;					//奖励奖牌

	TCHAR							szTaskName[64];			//任务名称
	TCHAR							szTaskDescribe[320];				//任务描述
}tagTaskParameter;

//任务状态
typedef struct {
	WORD							wTaskID;							//任务标识
	WORD							wTaskProgress;						//任务进度
	BYTE							cbTaskStatus;						//任务状态
}tagTaskStatus;

//低保参数
typedef struct {
	SCORE							lScoreCondition;					//游戏币条件
	SCORE							lScoreAmount;						//游戏币数量
	BYTE							cbTakeTimes;						//领取次数
}tagBaseEnsureParameter;

//推广信息
typedef struct {
	DWORD							dwSpreadCount;						//推广人数
	SCORE							lSpreadReward;						//推广奖励
}tagUserSpreadInfo;

//等级配置
typedef struct{
	WORD							wLevelID;							//等级 I D
	DWORD							dwExperience;						//相应经验
}tagGrowLevelConfig;

//等级参数
typedef struct {
	WORD							wCurrLevelID;						//当前等级
	DWORD							dwExperience;						//当前经验
	DWORD							dwUpgradeExperience;				//下级经验
	SCORE							lUpgradeRewardGold;					//升级奖励
	SCORE							lUpgradeRewardIngot;				//升级奖励
}tagGrowLevelParameter;

//会员参数
typedef struct{
	BYTE							cbMemberOrder;						//会员标识
	TCHAR							szMemberName[16];					//会员名称
	SCORE							lMemberPrice;						//会员价格
	SCORE							lPresentScore;						//赠送游戏币
}tagMemberParameter;

typedef struct{
	WORD							wKindID;							//挂接类型
	WORD							wNodeID;							//挂接节点
    WORD							wSortID;							//排列标识

	WORD							wRevenueRatio;						//税收比例
	SCORE							lServiceScore;						//服务费用
	SCORE							lRestrictScore;						//限制积分
	SCORE							lMinTableScore;						//最低积分
	SCORE							lMinEnterScore;						//最低积分
	SCORE							lMaxEnterScore;						//最高积分
	BYTE							cbMinEnterMember;					//最低会员
	BYTE							cbMaxEnterMember;					//最高会员

	DWORD							dwServerRule;						//房间规则
	TCHAR							szServerName[32];			//房间名称
}tagServerOptionInfo;

//数据描述头
typedef struct {
    WORD							wDataSize;						//数据大小
    WORD							wDataDescribe;					//数据描述
}tagDataDescribe;

typedef struct{
    DWORD							dwGameID;							//游戏 I D
	DWORD							dwUserID;							//用户 I D

	WORD							wFaceID;							//头像索引
	DWORD							dwCustomID;							//自定标识

	BYTE							cbGender;							//用户性别
	BYTE							cbMemberOrder;						//会员等级

	WORD							wTableID;							//桌子索引
	WORD							wChairID;							//椅子索引
	BYTE							cbUserStatus;						//用户状态

	LONGLONG							lScore;								//用户分数
	DWORD							dwWinCount;							//胜利盘数
	DWORD							dwLostCount;						//失败盘数
	DWORD							dwDrawCount;						//和局盘数
	DWORD							dwFleeCount;						//逃跑盘数
	DWORD							dwExperience;						//用户经验
}tagMobileUserInfoHead;

typedef struct{
	WORD				wPlazaID;						//广场标识
	TCHAR				szServerAddr[32];				//服务地址
	TCHAR				szServerName[32];				//服务器名
}tagGamePlaza;

typedef struct{
	INT				lLevelScore;					//级别积分
	TCHAR				szLevelName[16];				//级别描述
}tagLevelItem;

typedef struct{
	BYTE				cbMemberOrder;					//等级标识
	TCHAR				szMemberName[16];				//等级名字
}tagMemberItem;

typedef struct{
	BYTE				cbMasterOrder;					//等级标识
	TCHAR				szMasterName[16];				//等级名字
}tagMasterItem;

typedef struct{
	BYTE				cbColumnWidth;					//列表宽度
	BYTE				cbDataDescribe;					//字段类型
	TCHAR				szColumnName[16];				//列表名字
}tagColumnItem;

typedef struct{
	TCHAR				szAddress[32];					//服务器地址
}tagAddressInfo;

typedef struct{
	WORD				wDataBasePort;					//数据库端口
	TCHAR				szDataBaseAddr[32];				//数据库地址
	TCHAR				szDataBaseUser[32];				//数据库用户
	TCHAR				szDataBasePass[32];				//数据库密码
	TCHAR				szDataBaseName[32];				//数据库名字
}tagDataBaseParameter;

//玩家协议通讯任务结构
typedef struct
{
	DWORD							dwID;								//唯一id
	DWORD							dwEntryID;							//任务标识id
	LONGLONG						lQuantity;							//已完成数量
	WORD							wKindID;
	WORD							wRoomType;
	DWORD							dwActionID;
	LONGLONG						lQuantityMax;
	LONGLONG						lPrize;
}tagUserTaskItem;
//转盘奖励，奖项子项
typedef struct {
    BYTE				cbItemIndex;					//奖项索引(1-N)
    BYTE				cbItemType;						//奖励类型(0游戏币，1游戏豆)
    SCORE               lItemQuota;						//奖励额度
}tagLotteryItem;

//----------------------------------月卡炮台 start---------------------
//修改炮台
typedef struct 
{
	INT                             nFortID;
	TCHAR                           szTempPassword[33];
}CMD_GR_ChangeFort;

//修改炮台失败
typedef struct 
{
	INT                              nErrorCode;
	TCHAR                            szDescribeString[128];
}CMD_GR_ChangeFortFailure;

//捕鱼成功炮台（群发）
typedef struct 
{
	DWORD							dwUserID;							//用户标识
	INT                             nFortID;                            //当前炮台，仅针对捕鱼         
}CMD_GR_User_VIPLevel_Fort;
//----------------------------------月卡炮台 end---------------------

#pragma pack()

