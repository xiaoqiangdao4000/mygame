#pragma pack(1)

typedef enum{
	INVALID_TYPE,
	PLAYER_WIN,
	PLAYER_LOSE,
}CONCLUDE_TYPE;

typedef struct{
	CONCLUDE_TYPE	AreaConclude[5 - 1];
	bool			bInvalid;							//有效标志
}ZaJinHuaBattle_SHEET_RECORD;

typedef enum{
	OCCUPYVIP_CONSUMETYPE,

}OCCUPYVIPTYPE;

typedef struct{
	OCCUPYVIPTYPE		occupyvipType;					//占位类型
	SCORE				lOccupyVipConsume;	    		//占位消耗
	SCORE				lOccupyVipFree;					//金币上限
	SCORE				lForceStandUpCondition;			//强制站立条件
}ZaJinHuaBattle_OCCUPYVIPCONFIG;

typedef struct {
	bool							nEnableRobotBanker;				//是否做庄
	LONGLONG						lRobotBankerCountMin;			//坐庄次数
	LONGLONG						lRobotBankerCountMax;			//坐庄次数
	LONGLONG						lRobotListMinCount;				//列表人数
	LONGLONG						lRobotListMaxCount;				//列表人数
	LONGLONG						lRobotApplyBanker;				//最多申请个数
	LONGLONG						lRobotWaitBanker;				//空盘重申

	LONGLONG						lRobotMinBetTime;				//下注筹码个数
	LONGLONG						lRobotMaxBetTime;				//下注筹码个数
	LONGLONG						lRobotMinJetton;				//下注筹码金额
	LONGLONG						lRobotMaxJetton;				//下注筹码金额
	LONGLONG						lRobotBetMinCount;				//下注机器人数
	LONGLONG						lRobotBetMaxCount;				//下注机器人数
	LONGLONG						lRobotAreaLimit;				//区域限制

	LONGLONG						lRobotScoreMin;					//金币下限
	LONGLONG						lRobotScoreMax;					//金币上限
	LONGLONG						lRobotBankGetMin;				//取款最小值(非庄)
	LONGLONG						lRobotBankGetMax;				//取款最大值(非庄)
	LONGLONG						lRobotBankGetBankerMin;			//取款最小值(坐庄)
	LONGLONG						lRobotBankGetBankerMax;			//取款最大值(坐庄)
	LONGLONG						lRobotBankStoMul;				//存款百分比

}ZaJinHuaBattle_tagCustomAndroid;

//更新库存
typedef struct {
	BYTE                            cbReqType;						//请求类型
	LONGLONG						lStorageStart;					//起始库存
	LONGLONG						lStorageDeduct;					//库存衰减
	LONGLONG						lStorageCurrent;				//当前库存
	LONGLONG						lStorageMax1;					//库存上限1
	LONGLONG						lStorageMul1;					//系统输分概率1
	LONGLONG						lStorageMax2;					//库存上限2
	LONGLONG						lStorageMul2;					//系统输分概率2
}ZaJinHuaBattle_CMD_S_UpdateStorage;

//失败结构
typedef struct {
	WORD							wPlaceUser;									//下注玩家
	BYTE							cbBetArea;									//区域索引
	LONGLONG						lBetScore;									//当前下注
	bool							bFleeFlag;									//逃跑标识
}ZaJinHuaBattle_CMD_S_PlaceBetFail;

typedef struct {
	BYTE							cbTimeLeave;								//剩余时间
	BYTE							cbGameStatus;								//游戏状态

	LONGLONG						lUserMaxScore;								//玩家金币

	WORD							wBankerUser;								//当前庄家
	LONGLONG						lBankerScore;								//庄家分数
	bool							bEnableSysBanker;							//系统做庄
	LONGLONG						lSysBankerScore;							//系统坐庄积分
	LONGLONG						lEndGameMul;								//提前开牌百分比

	LONGLONG						lApplyBankerCondition;						//申请条件
	LONGLONG						lAreaLimitScore;							//区域限制
	ZaJinHuaBattle_SHEET_RECORD					sheetRecord[10];				//记录结果

	WORD							wVIPChairID[4];					//占位椅子ID
	ZaJinHuaBattle_OCCUPYVIPCONFIG					occupyvipConfig;

	LONGLONG						lCurrentBonus;								//当前彩金
	bool							bExistUser[100];						//用户存在标识

	ZaJinHuaBattle_tagCustomAndroid				CustomAndroid;								//机器人配置
}ZaJinHuaBattle_CMD_S_StatusFree;

typedef struct {
	BYTE							cbTimeLeave;								//剩余时间
	BYTE							cbGameStatus;								//游戏状态

	LONGLONG						lUserMaxScore;								//玩家金币

	WORD							wBankerUser;								//当前庄家
	LONGLONG						lBankerScore;								//庄家分数
	bool							bEnableSysBanker;							//系统做庄
	LONGLONG						lSysBankerScore;							//系统坐庄积分
	LONGLONG						lEndGameMul;								//提前开牌百分比

	LONGLONG						lApplyBankerCondition;						//申请条件
	LONGLONG						lAreaLimitScore;							//区域限制
	ZaJinHuaBattle_SHEET_RECORD					sheetRecord[10];				//记录结果

	LONGLONG						lAllAreaBet[5 - 1];					//区域总下注
	LONGLONG						lPlayerAreaBet[100][5 - 1];	//玩家区域下注

	WORD							wVIPChairID[4];					//占位椅子ID
	ZaJinHuaBattle_OCCUPYVIPCONFIG					occupyvipConfig;

	LONGLONG						lCurrentBonus;								//当前彩金
	bool							bExistUser[100];						//用户存在标识

	ZaJinHuaBattle_tagCustomAndroid				CustomAndroid;								//机器人配置
}ZaJinHuaBattle_CMD_S_StatusBet;

typedef struct {
	BYTE							cbTimeLeave;								//剩余时间
	BYTE							cbGameStatus;								//游戏状态

	LONGLONG						lUserMaxScore;								//玩家金币

	WORD							wBankerUser;								//当前庄家
	LONGLONG						lBankerScore;								//庄家分数
	bool							bEnableSysBanker;							//系统做庄
	LONGLONG						lSysBankerScore;							//系统坐庄积分
	bool							bSysReturnBonus;							//系统返回彩金标识
	LONGLONG						lEndGameMul;								//提前开牌百分比

	LONGLONG						lApplyBankerCondition;						//申请条件
	LONGLONG						lAreaLimitScore;							//区域限制
	ZaJinHuaBattle_SHEET_RECORD					sheetRecord[10];				//记录结果

	LONGLONG						lAllAreaBet[5 - 1];					//区域总下注
	LONGLONG						lPlayerAreaBet[100][5 - 1];	//玩家区域下注					//玩家下注
	CONCLUDE_TYPE					AreaConclude[5 - 1];

	BYTE							cbCardDataItem[5][3];	//扑克数据

	WORD							wVIPChairID[4];					//占位椅子ID
	ZaJinHuaBattle_OCCUPYVIPCONFIG					occupyvipConfig;

	LONGLONG						lCurrentBonus;								//当前彩金
	bool							bExistUser[100];						//用户存在标识

	ZaJinHuaBattle_tagCustomAndroid				CustomAndroid;								//机器人配置
}ZaJinHuaBattle_CMD_S_StatusEnd;

//申请庄家
typedef struct {
	WORD							wApplyUser;							//申请玩家
}ZaJinHuaBattle_CMD_S_ApplyBanker;

//取消申请
typedef struct {
	WORD							wCancelUser;						//取消玩家
}ZaJinHuaBattle_CMD_S_CancelBanker;

//切换庄家
typedef struct {
	WORD							wBankerUser;						//当庄玩家
	LONGLONG						lBankerScore;						//庄家金币
	LONGLONG						lSysBankerScore;					//系统坐庄积分
}ZaJinHuaBattle_CMD_S_ChangeBanker;

//游戏空闲
typedef struct {
	BYTE							cbTimeLeave;								//剩余时间
	LONGLONG						lListUserCount;								//上庄列表人数
	LONGLONG						lCurrentBonus;								//当前彩金
	LONGLONG						lSysBankerScore;							//系统坐庄积分
}ZaJinHuaBattle_CMD_S_GameFree;

//游戏开始
typedef struct {
	BYTE							cbTimeLeave;								//剩余时间
	WORD							wBankerUser;								//庄家位置
	LONGLONG						lBankerScore;								//庄家金币
	LONGLONG						lUserMaxScore;								//我的金币		

	int								nChipRobotCount;							//人数上限 (下注机器人)
	int								nAndriodApplyCount;							//机器人列表人数		
}ZaJinHuaBattle_CMD_S_GameStart;

typedef struct {
	WORD							wChairID;									//用户位置
	BYTE							cbBetArea;									//筹码区域
	LONGLONG						lBetScore;									//加注数目

	LONGLONG						lAllAreaBet[5 - 1];					//区域总下注
	LONGLONG						lPlayerAreaBet[100][5 - 1];	//玩家区域下注	
}ZaJinHuaBattle_CMD_S_PlaceBet;

typedef struct {
	BYTE							cbTimeLeave;								//剩余时间
	BYTE							cbCardDataItem[5][3];	//扑克数据
	ZaJinHuaBattle_SHEET_RECORD					sheetRecord[10];				//记录结果
	CONCLUDE_TYPE					AreaConclude[5 - 1];					//区域结果

	LONGLONG						lBankerScore;								//庄家成绩

	bool							bSysReturnBonus;							//返还彩金标识

	LONGLONG						lUserScore;									//玩家成绩
	LONGLONG						lUserReturnBonus;							//返回彩金
}ZaJinHuaBattle_CMD_S_GameEnd;

//占位
typedef struct {
	WORD							wOccupyVIPChairID;							//申请占位玩家ID
	BYTE							cbOccupyVIPIndex;							//占位索引
	WORD							wVIPChairID[4];					//占位椅子ID
}ZaJinHuaBattle_CMD_S_OccupyVIP;

//占位失败
typedef struct {
	WORD							wAlreadyOccupyVIPChairID;					//已申请占位玩家ID
	BYTE							cbAlreadyOccupyVIPIndex;					//已占位索引
	WORD							wVIPChairID[4];					//占位椅子ID
}ZaJinHuaBattle_CMD_S_OccupyVIP_Fail;

//更新占位
typedef struct {
	WORD							wVIPChairID[4];					//占位椅子ID
	WORD							wQuitVIPChairID;							//申请退出占位玩家
}ZaJinHuaBattle_CMD_S_UpdateVIP;

//更新用户
typedef struct {
	bool							bExistUser[100];						//用户存在标识
}ZaJinHuaBattle_CMD_S_UpdateUser;

//积分通知
typedef struct {
	bool							bEnableSysBanker;							//系统坐庄
	LONGLONG						lSysBankerScore;							//系统坐庄积分
	WORD							wBankerUser;								//当庄玩家
}ZaJinHuaBattle_CMD_S_UserScroeNotify;

//发送下注
typedef struct {
	LONGLONG						lUserStartScore[100];				//起始分数
	LONGLONG						lPlayerAreaBet[100][5 - 1];	//玩家区域下注
}ZaJinHuaBattle_CMD_S_SendUserBetInfo;

typedef struct {
	BYTE cbAckType;					//回复类型

	BYTE cbExcuteTimes;
	BYTE cbControlStyle;
	BYTE cbResult;
	bool bWinArea[5 - 1];
}ZaJinHuaBattle_CMD_S_CommandResult;

typedef struct {
	BYTE cbReqType;

	BYTE cbExcuteTimes;	
	BYTE cbControlStyle;
	bool bWinArea[5 - 1];
}ZaJinHuaBattle_CMD_C_AdminReq;

//用户下注
typedef struct {
	BYTE							cbBetArea;									//筹码区域
	LONGLONG						lBetScore;									//加注数目
}ZaJinHuaBattle_CMD_C_PlaceBet;

//更新库存
typedef struct {
	BYTE                            cbReqType;									//请求类型
	LONGLONG						lStorageDeduct;								//库存衰减
	LONGLONG						lStorageCurrent;							//当前库存
	LONGLONG						lStorageMax1;								//库存上限1
	LONGLONG						lStorageMul1;								//系统输分概率1
	LONGLONG						lStorageMax2;								//库存上限2
	LONGLONG						lStorageMul2;								//系统输分概率2
}ZaJinHuaBattle_CMD_C_UpdateStorage;

//占位
typedef struct {
	WORD							wOccupyChairID;								//占位玩家
	BYTE							cbOccupyVIPIndex;							//占位索引
}ZaJinHuaBattle_CMD_C_OccupyVIP;

#pragma pack()
