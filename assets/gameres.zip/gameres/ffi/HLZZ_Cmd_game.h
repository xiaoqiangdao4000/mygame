#pragma pack(1)

//彩金得主信息
typedef struct {
    LONGLONG lGetCajin;
    char nickName[32*2];
    char cardType[15*2];
}HLZZ_CajinInfo;

typedef struct {
    LONGLONG lCaijin;
}CMD_S_HLZZ_AllCaijin;

//游戏状态
typedef struct {
    WORD							    	wCallBanker;						//叫庄用户
    BYTE							        cbPlayStatus[6];          //用户状态
}CMD_S_HLZZ_StatusCall;

typedef struct {
    LONGLONG								lTurnMaxScore;						//最大下注
    LONGLONG								lTableScore[6];			//下注数目
    BYTE								    cbPlayStatus[6];          //用户状态
    WORD							    	wBankerUser;						//庄家用户
}CMD_S_HLZZ_StatusScore;

//用户叫庄
typedef struct {
    WORD							     	wCallBanker;						//叫庄用户
    bool							    	bFirstTimes;						//首次叫庄
}CMD_S_HLZZ_CallBanker;

//用户下注
typedef struct {
    WORD							    	wAddScoreUser;						//加注用户
    LONGLONG								lAddScoreCount;						//加注数目
}CMD_S_HLZZ_AddScore;

//发牌数据包
typedef struct {
    BYTE								    cbCardData[6][5];	//用户扑克

    BYTE									cbPlayStatus[6];			//游戏状态//
}CMD_S_HLZZ_SendCard;

//用户退出
typedef struct {
    WORD						      		wPlayerID;							//退出用户
}CMD_S_HLZZ_PlayerExit;

//用户摊牌
typedef struct {
    WORD							     	wPlayerID;							//摊牌用户
    BYTE							      	bOpen;								//摊牌标志
}CMD_S_HLZZ_Open_Card;

typedef struct {
    LONGLONG                           lStorage;
    int                                nStorageDeduct;
}CMD_S_HLZZ_AdminStorage;

typedef struct {
    BYTE                               cbEnable;
}CMD_S_HLZZ_AdminControlEnable;

typedef struct {
    BYTE                              cbType;   //0为ID,1为机器码，2为IP
    DWORD                          dwGameID; //控制ID
    INT                               nPercent; //概率
    INT                               nTimes;   //控制次数，-1表示不限次数
    char                              szMachineID[33]; //控制机器码
}CMD_S_HLZZ_AdminControl;

typedef struct {
    LONGLONG                           lStorage;//库存下限
    int                                nPercent ;
}CMD_S_HLZZ_AdminFloat;

typedef struct {
    BYTE                               cbEnable;
}CMD_S_HLZZ_AdminFloatEnable;

//用户叫庄
typedef struct {
    BYTE							    	bBanker;							//做庄标志
}CMD_C_HLZZ_CallBanker;

//用户加注
typedef struct {
    LONGLONG                            nServriValue;
    LONGLONG								lScore;								//加注数目
}CMD_C_HLZZ_AddScore;

//用户摊牌
typedef struct {
    LONGLONG                            nServriValue;
    BYTE							    	bOX;								//牛牛标志
}CMD_C_HLZZ_OxCard;

typedef struct {
    LONGLONG                           lStorage;
    INT                                nStorageDeduct;
}CMD_C_HLZZ_AdminStorageUpdate;

typedef struct {
    BYTE                              cbEnable;
}CMD_C_HLZZ_AdminControlEnableUpdate;

typedef struct {
    BYTE                              cbType;   //0为ID,1为机器码，2为IP
    DWORD                             dwGameID; //控制ID
    INT                               nPercent; //概率
    INT                               nTimes;   //控制次数，-1表示不限次数
    char                              szMachineID[33]; //控制机器码
}CMD_C_HLZZ_AdminControlAdd;

typedef struct {
    BYTE                              cbType;   //0为ID,1为机器码，2为IP
    DWORD                             dwGameID; //控制ID
    char                              szMachineID[33]; //控制机器码
}CMD_C_HLZZ_AdminControlDelete;

typedef struct {
    BYTE                              cbEnable;
}CMD_C_HLZZ_AdminFloatEnableUpdate;
typedef struct {
    LONGLONG                           lStorage;//库存下限
    int                                nPercent ;
}CMD_C_HLZZ_AdminFloatAdd;

typedef struct {
    LONGLONG                           lStorage;//库存下限
}CMD_C_HLZZ_AdminFloatDelete;

#pragma pack()
