
#pragma pack(1)

////客户端命令结构
//协议数据
typedef struct {
	BYTE cbOp;          //2 不抢， 1抢
}OxJD_CMD_C_CALL_BANKER;

typedef struct {
	LONGLONG lScore;
}OxJD_CMD_C_ADD_SCORE;

//用户摊牌
typedef struct {
	LONGLONG                            nServriValue;
	BYTE                                bOX;                                //牛牛标志
}OxJD_CMD_C_OxCard;


//服务器命令结构
//场景还原
typedef struct {
	BYTE                            cbState;
	LONGLONG                        lCellScore;
	BYTE                            cbCallStatus[5];            //叫庄状态
	bool                            bOpenCardStatus[5];        //亮牌状态
	BYTE                            cbMaxScore;              //最大下注
	BYTE                            cbScore[5];                 //玩家下注倍数
	LONGLONG                        lGameScore[5];               //游戏得分
	BYTE                            bOxCard[5];                 //牛牛数据
	BYTE                            cbHandCardData[5][5];            //桌面扑克
	BYTE                            cbPlayStatus[5];
	WORD                            wBankerUser;                 //庄家用户
	BYTE    						cbCanCallBanker;                    //0抢不了庄 1可以抢
	BYTE							cbFleeInfo[5];					//逃跑信息
}OxJD_CMD_S_StatusGame;

//状态数据结构（叫庄开始）
typedef struct {
	BYTE                            cbPlayStatus[5];
	BYTE    						cbCanCallBanker;                    //0抢不了庄 1可以抢
	WORD    						wServerID;                          //服务器id 
}OxJD_CMD_S_GAMESTART;

//玩家叫庄
typedef struct {
	WORD wChairID;     //位置编号
	BYTE cbOp;          //2 不抢， 1抢
}OxJD_CMD_S_CALL_BANKER;

//下注阶段（叫庄结束）
typedef struct {
	WORD wBankerUser; //庄家
	BYTE cbMaxScore;
}OxJD_CMD_S_SCORE;

//玩家下注
typedef struct {
	WORD wChairID;
	LONGLONG lScore;
}OxJD_CMD_S_ADD_SCORE;

//发牌阶段（摊牌开始）
typedef struct {
	BYTE cbCard[5];
}OxJD_CMD_S_SEND_CARD;

//玩家开牌
typedef struct {
	WORD wChairID;
}OxJD_CMD_S_OPEN_CARD;

//游戏结束
typedef struct {
	LONGLONG                                lGameTax[5];                //游戏税收
	LONGLONG                                lGameScore[5];          //游戏得分
	BYTE                                    cbCardData[5][5];          //用户扑克
	BYTE									cbFleeInfo[5];					//逃跑信息
}OxJD_CMD_S_GameEnd;

//用户退出
typedef struct {
	WORD                                wPlayerID;                          //退出用户
}OxJD_CMD_S_PlayerExit;
//////////////////////////////////////////////////////////////////////////
#pragma pack()