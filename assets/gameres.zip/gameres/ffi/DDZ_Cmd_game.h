#pragma pack(1)

typedef struct
{
    //游戏属性
    LONG                            lCellScore;                         //基础积分

    //时间信息
    BYTE                            cbTimeOutCard;                      //出牌时间
    BYTE                            cbTimeCallScore;                    //叫分时间
    BYTE                            cbTimeStartGame;                    //开始时间
    BYTE                            cbTimeHeadOutCard;                  //首出时间
    BYTE                            cbTimeAddTimes;                     //加倍时间

    //历史积分
    SCORE                           lTurnScore[3];            //积分信息
    SCORE                           lCollectScore[3];         //积分信息
    TCHAR              szGuid[37];                           // 为了回放新加数据 战报ID
}DDZ_CMD_S_StatusFree;

//叫分状态
 typedef struct
{
    //时间信息
    BYTE                            cbTimeOutCard;                      //出牌时间
    BYTE                            cbTimeCallScore;                    //叫分时间
    BYTE                            cbTimeStartGame;                    //开始时间
    BYTE                            cbTimeHeadOutCard;                  //首出时间
    BYTE                            cbTimeAddTimes;                     //加倍时间

    //游戏信息
    LONG                            lCellScore;                         //单元积分
    WORD                            wCurrentUser;                       //当前玩家
    WORD                            wStartUser;                         //首叫玩家
    WORD                            cbBankerScore;                      //庄家叫分
    BYTE                            cbScoreInfo[3];           //叫分信息
    BYTE                            cbHandCardData[17];       //手上扑克
    BYTE                            cbUserTrustee[3];         //托管标志
    //历史积分
    SCORE                           lTurnScore[3];            //积分信息
    SCORE                           lCollectScore[3];         //积分信息
    TCHAR              szGuid[37];                          // 为了回放新加数据 战报ID
}DDZ_CMD_S_StatusCall;

//加倍状态
typedef struct
{
    //时间信息
    BYTE                            cbTimeOutCard;                      //出牌时间
    BYTE                            cbTimeCallScore;                    //叫分时间
    BYTE                            cbTimeStartGame;                    //开始时间
    BYTE                            cbTimeHeadOutCard;                  //首出时间
    BYTE                            cbTimeAddTimes;                     //加倍时间

    //游戏信息
    LONG                            lCellScore;                         //单元积分
    WORD                            wCurrentUser;                       //当前玩家
    WORD                            wStartUser;                         //首叫玩家
    WORD                            wBankerUser;                        //庄家

    //叫分信息
    WORD                            cbBankerScore;                      //庄家叫分
    BYTE                            cbScoreInfo[3];           //叫分信息

    //扑克信息
    BYTE                            cbHandCardData[20];          //手上扑克
    BYTE                            cbHandCardCount[3];       //扑克数目
    BYTE                            cbBankerCard[3];                    //游戏底牌

    //加倍信息
    BYTE                            cbAddTimes[3];            //加倍信息

    //历史积分
    SCORE                           lTurnScore[3];            //积分信息
    SCORE                           lCollectScore[3];         //积分信息
    BYTE                            cbUserTrustee[3];         //托管标志

    BYTE                            cbBankerCardType;                   //底牌类型
    BYTE                            cbBankerCardTimes;                      //底牌倍数
    TCHAR              szGuid[37];                              // 为了回放新加数据 战报ID
}DDZ_CMD_S_StatusAddTimes;

//游戏状态
typedef struct
{
    //时间信息
    BYTE                            cbTimeOutCard;                      //出牌时间
    BYTE                            cbTimeCallScore;                    //叫分时间
    BYTE                            cbTimeStartGame;                    //开始时间
    BYTE                            cbTimeHeadOutCard;                  //首出时间

    //游戏变量
    LONG                            lCellScore;                         //单元积分
    BYTE                            cbBombCount;                        //炸弹次数
    WORD                            wBankerUser;                        //庄家用户
    WORD                            wCurrentUser;                       //当前玩家
    WORD                            cbBankerScore;                      //庄家叫分

    //出牌信息
    WORD                            wTurnWiner;                         //胜利玩家
    BYTE                            cbTurnCardCount;                    //出牌数目
    BYTE                            cbTurnCardData[20];          //出牌数据

    //扑克信息
    BYTE                            cbBankerCard[3];                    //游戏底牌
    BYTE                            cbHandCardData[20];          //手上扑克
    BYTE                            cbHandCardCount[3];       //扑克数目

    //历史积分
    SCORE                           lTurnScore[3];            //积分信息
    SCORE                           lCollectScore[3];         //积分信息
    BYTE                            cbUserTrustee[3];         //托管标志

    //加倍信息
    BYTE                            cbAddTimes[3];            //加倍信息

    BYTE                            cbBankerCardType;                   //底牌类型
    BYTE                            cbBankerCardTimes;                      //底牌倍数
    WORD                            wOpenUser;                      //明牌用户
    TCHAR              szGuid[37];              // 为了回放新加数据 战报ID
}DDZ_CMD_S_StatusPlay;

//发送扑克
typedef struct
{
    LONG                            lCellScore;                         //基础积分
    BYTE                            cbTimeOutCard;                      //出牌时间
    BYTE                            cbTimeCallScore;                    //叫分时间
    BYTE                            cbTimeStartGame;                    //开始时间
    BYTE                            cbTimeHeadOutCard;                  //首出时间
    BYTE                            cbTimeAddTimes;                     //加倍时间
    WORD                            wStartUser;                         //开始玩家
    WORD                            wCurrentUser;                       //当前玩家
    BYTE                            cbValidCardData;                    //明牌扑克
    BYTE                            cbValidCardIndex;                   //明牌位置
    BYTE                            cbCardData[17];           //扑克列表
    TCHAR              szGuid[37];                          // 为了回放新加数据 战报ID
}DDZ_CMD_S_GameStart;

//机器人扑克
typedef struct
{
    BYTE                            cbHandCard[3][17];//手上扑克
    BYTE                            cbBankerCard[3];
    WORD                            wCurrentUser;                      //当前玩家
}DDZ_CMD_S_AndroidCard;

//作弊扑克
typedef struct
{
    WORD                            wCardUser[3];              //作弊玩家
    BYTE                            cbUserCount;               //作弊数量
    BYTE                            cbCardData[3][20];         //扑克列表
    BYTE                            cbCardCount[3];            //扑克数量

}DDZ_CMD_S_CheatCard;
//用户叫分
typedef struct
{
    WORD                            wCurrentUser;                       //当前玩家
    WORD                            wCallScoreUser;                     //叫分玩家
    WORD                            cbCurrentScore;                     //当前叫分
    BYTE                            cbUserCallScore;                    //上次叫分
}DDZ_CMD_S_CallScore;

//庄家信息
typedef struct
{
    WORD                            wBankerUser;                        //庄家玩家
    WORD                            wCurrentUser;                       //当前玩家
    WORD                            cbBankerScore;                      //庄家叫分
    BYTE                            cbBankerCard[3];                    //庄家扑克
    BYTE                            cbBankerCardType;                   //底牌类型
    BYTE                            cbBankerTimes;                      //底牌倍数
}DDZ_CMD_S_BankerInfo;

//用户出牌
typedef struct
{
    BYTE                            cbCardCount;                        //出牌数目
    WORD                            wCurrentUser;                       //当前玩家
    WORD                            wOutCardUser;                       //出牌玩家
    BYTE                            cbCardData[20];              //扑克列表
}DDZ_CMD_S_OutCard;

//放弃出牌
typedef struct
{
    BYTE                            cbTurnOver;                         //一轮结束
    WORD                            wCurrentUser;                       //当前玩家
    WORD                            wPassCardUser;                      //放弃玩家
}DDZ_CMD_S_PassCard;

//游戏结束
typedef struct
{
    //积分变量
    LONG                            lCellScore;                         //单元积分
    SCORE                           lGameScore[3];            //游戏积分

    //春天标志
    BYTE                            bChunTian;                          //春天标志
    BYTE                            bFanChunTian;                       //春天标志

    //炸弹信息
    BYTE                            cbBombCount;                        //炸弹个数
    BYTE                            cbEachBombCount[3];       //炸弹个数

    //游戏信息
    WORD                            cbBankerScore;                      //叫分数目
    BYTE                            cbCardCount[3];           //扑克数目
    BYTE                            cbHandCardData[54];         //扑克列表

    //加倍信息
    BYTE                            cbAddTimes[3];            //加倍信息
    SCORE                           lRevenue[3];    //税收
}DDZ_CMD_S_GameConclude;

//托管
typedef struct
{
    WORD                            wTrusteeUser;                       //托管玩家
    BYTE                            bTrustee;                           //托管标志
}DDZ_CMD_S_TRUSTEE;

//用户加倍
typedef struct
{
    WORD                            wAddUser;                           //加倍用户
    BYTE                            cbTimes;                            //加倍倍数
}DDZ_CMD_S_AddTimes;

//开始出牌
typedef struct
{
    WORD                            wCurrentUser;                       //当前玩家
}DDZ_CMD_S_StartCard;

//明牌
typedef struct
{
    WORD                            wOpenUser;                          //明牌玩家
    BYTE                            cbPlusTimes;                        //明牌加倍
    BYTE                            cbCardData[20];              //扑克列表
}DDZ_CMD_S_OpenCard;

//实力架测试, 记得删除
typedef struct
{
    WORD                            wOpenUser;                          //明牌玩家
    BYTE                            cbPlusTimes;                        //明牌加倍
    BYTE                            cbCardData[20];              //扑克列表
}DDZ_CMD_S_OpenCard_Tmp;

//用户叫分
typedef struct
{
    BYTE                            cbCallScore;                        //叫分数目
}DDZ_CMD_C_CallScore;

//用户出牌
typedef struct
{
    BYTE                            cbCardCount;                        //出牌数目
    BYTE                            cbCardData[20];              //扑克数据
}DDZ_CMD_C_OutCard;

//托管
typedef struct
{
    BYTE                            bTrustee;                           //托管标志
}DDZ_CMD_C_TRUSTEE;

typedef struct
{
    BYTE                            cbTimes;                            //倍数
}DDZ_CMD_C_AddTimes;

typedef struct
{
    BYTE                            cbCount[20];  
}DDZ_CMD_S_Rembercard;

typedef struct
{

}DDZ_CMD_C_OpenCard;

typedef struct
{
    BYTE cbOpen; //0 关闭，1 开放
    int nScore[10];//对应类型倍数
    SCORE lBet[4]; //对应4个可以下注的筹码
    SCORE lGuessScore; //已下注
    int   nTax; //纳税点 百分比
    SCORE lMaxGuess;  //竞猜上限
}DDZ_CMD_S_GuessConfig;

typedef struct
{
    int nResult;//0成功 1下注后不能低于坐下最低分数 2已经下注，不要多次下注
    SCORE lScore;
}DDZ_CMD_S_Guess;

typedef struct
{
    SCORE lScore;
}DDZ_CMD_C_Guess;

//竞猜结果
typedef struct
{
    SCORE lScore; //大于0表示赢了多少，小于0表示输了多少
    int nTime;//时间
    int nType;//底牌牌型
    SCORE lGuessScore;//竞猜额度
}DDZ_CMD_S_GuessResult;
#pragma pack()

