#pragma pack(1)

typedef struct
{
	DWORD dwUserId;
	DWORD dwCatchFishCount;
	DWORD dwCatchScore;
	DWORD dwRanking;
	TCHAR szNickName[32];
}FISH3D_CompetitionRanking;


typedef struct
{
	DWORD dwRanking;
	LONG  lScore;
	LONG  lCatchScore;
}FISH3D_CMD_S_MATCH_END;

typedef struct 
{
	DWORD wChairId;
	DWORD dwRanking;
	LONG  lScore;
	DWORD MatchUserCount;
	LONG  lMaxScore;
}FISH3D_CMD_S_CUR_RANKING;

typedef struct 
{
	DWORD dwUserId;
	DWORD dwCatchFishCount;
	DWORD dwCatchScore;
	DWORD dwRanking;
	LONG  lScore;
	TCHAR szNickName[32];
}FISH3D_CMD_S_UPDATE_RANKING;


typedef struct 
{
	DWORD	nFishID;
	int		nMul;
}FISH3D_CMD_S_FISH_MUL;

typedef struct 
{
	TCHAR	szFishName[256];
	int		nActivityTime;
	bool	bStart;
}FISH3D_CMD_S_ACTIVITY_NOTIFY;

typedef struct 
{
	DWORD caster;
	DWORD fishes[100]; 
	int nBufferType;
	float fBufferParam;
	float fBufferTime; 
}FISH3D_CMD_S_ADD_BUFFER;

typedef struct 
{
	int						nMulriple;
	int						nSpeed;
	int						nMaxCatch;
	int						nBulletSize;
	int						nCatchRadio;
	int						nCannonType;
	bool					bFirst;
}FISH3D_CMD_S_BULLET_SET;

typedef struct 
{
	int			nCount;
	TCHAR		szDes[4][256];
	bool  		isBoss;
}FISH3D_CMD_S_SEND_DES;

typedef struct 
{
	DWORD	wChairID;
	DWORD	dwLockID;
}FISH3D_CMD_S_LOCK_FISH;

typedef struct 
{
	int		FishCount;
	float	dir;
}FISH3D_AndroidUpdata;

typedef struct 
{
	bool	m_bAllowFire;
}FISH3D_CMD_S_ALLOW_FIRE;

typedef struct 
{
	int		nst;
	bool	bSwitching;
}FISH3D_CMD_S_SWITCH_SCENE;

typedef struct 
{
	DWORD		wChairID;
	DWORD		dwBulletID;
}FISH3D_CMD_S_KILL_BULLET;

typedef struct 
{
	DWORD		wChairID;
	LONGLONG	lScore;
	DWORD		dwFishID;
	int			nBScoe;
	LONGLONG	totalScore;
}FISH3D_CMD_S_KILL_FISH;

typedef struct 
{
	DWORD		dwID;
	DWORD		wChairID;
	DWORD		dwCreateTick;
	float		fXpos;
	float		fYPos;
	int			nCannonType;
	int			nMultiply;
	LONGLONG	lScore;
	float		fDirection;
	bool		bNew;
	DWORD		dwServerTick;
	bool		IsDouble;
}FISH3D_CMD_S_SEND_BULLET;

typedef struct 
{
	DWORD		wChairID;
	int			cannonType;
	int			cannonMul;
	int			cannonSet;
}FISH3D_CMD_S_CANNON_SET;

typedef struct 
{
	DWORD		wChairID;
	LONGLONG	lFishScore;
	LONGLONG	lWastageScore;
}FISH3D_CMD_S_CHANGE_SCORE;

typedef struct 
{
	DWORD			wChairID;
	DWORD			dwUserID;
	TCHAR  szUserName[32];
	LONGLONG		lScore;
	int				nCannonType;
	int				nCannonMul;
	int				nCannonSet;
	LONGLONG	    lWastage;
	int	nFrequencyMultiply;
	unsigned int	lockFish;
	unsigned int	nBulletID;
}FISH3D_CMD_S_USER_INFO;

typedef struct
{
	DWORD	dwFishID;
	int		nTypeID;
	int		nPathID;
	DWORD	dwCreateTick;
	float	fOffestX;
	float	fOffestY;
	float	fOffestZ;
	float	fDirX;
	float	fDirY;
	float	fDirZ;
	float	fDelay;
	DWORD	dwServerTick;
	float	FishSpeed;
	int		FisType;
	int		lockLevel;
	bool	bTroop;
	bool	bBelong;
	DWORD	nRefershID;
	DWORD	nParentID;
	int		lifetime;
}FISH3D_CMD_S_SEND_FISH;

typedef struct 
{
	DWORD	wServerID;
	int		nChangeRatioUserScore;
	int		nChangeRatioFishScore;
	int		nExchangeOnce;
	int		nFireInterval;
	int		nMaxInterval;
	int		nMinInterval;
	int		nShowGoldMinMul;
	int		nMaxBulletCount;
	int		nMaxCannon;
}FISH3D_CMD_S_GAME_CONFIG;

typedef struct 
{
	DWORD	wChiarID;
	DWORD	dwServerTick;
	DWORD	dwClientTick;
}FISH3D_CMD_S_TIME_SYNC;

typedef struct 
{
	DWORD		wChiarID;
	LONGLONG	lScore;
	LONGLONG	lTotalScore;
}FISH3D_CMD_S_SCORE_SYNC;

typedef struct 
{
	DWORD		wChairID;
	LONGLONG	lScore;	
}FISH3D_CMD_C_TREASURE_END;

typedef struct 
{
	DWORD		wChairID;
	bool		bAdd;
}FISH3D_CMD_C_CHANGE_CANNONSET;

typedef struct 
{
	DWORD	dwBulletID;
	DWORD	dwData;
	DWORD	dwFishID;
}FISH3D_CMD_C_NETCAST;

typedef struct 
{
	DWORD	wChairID;
	bool	bLock;
}FISH3D_CMD_C_LOCK_FISH;

typedef struct 
{
	DWORD		wChairID;
	float		fDirection;
	DWORD		dwFireTime;
	DWORD		dwClientID;
}FISH3D_CMD_C_FIRE;

typedef struct 
{
	DWORD wChairID;
	bool bAdd;
}FISH3D_CMD_C_CHANGE_CANNON;

typedef struct 
{
	DWORD	wChairID;
	bool	bAdd;
	bool	bAddAll;
}FISH3D_CMD_C_CHANGE_SCORE;

typedef struct 
{
	DWORD	wChairID;
	DWORD	dwClientTick;
}FISH3D_CMD_C_TIME_SYNC;

typedef struct 
{
	DWORD	dwRemainTime;
}FISH3D_CMD_S_DIFF_END;

typedef struct 
{
	DWORD	dwRemainTime;
}FISH3D_CMD_S_DIFF_START;

typedef struct
{
	WORD	wChairID;
	DWORD	nFrequencyMultiply;
}FISH3D_CMD_S_BULLET_SPEED_UP;

typedef struct
{
	DWORD	wChairID;
	DWORD	dwFishID;
}FISH3D_CMD_S_LOCK_ONE_FISH;

typedef struct
{
	DWORD	wChairID;
	DWORD	dwFishID;
}FISH3D_CMD_C_LOCK_ONE_FISH;

typedef struct 
{
	DWORD	wChairID;
	DWORD	nFrequencyMultiply;
}FISH3D_CMD_C_BULLET_SPEED_UP;

typedef struct
{
	int		type;
	DWORD	dwID;
	float	x;
	float	y;
	float	z;
	float	dirX;
	float	dirY;
	float	dirZ;
}FISH3D_CMD_S_UPDATE_POSITION;

typedef struct 
{
	DWORD	dwGroupID;
	int		nTypeID;
	int		nPathID;
	DWORD	dwCreateTick;
	float	fOffestX;
	float	fOffestY;
	float	fOffestZ;
	float	fDirX;
	float	fDirY;
	float	fDirZ;
	DWORD	dwServerTick;
	float	Speed;
	DWORD	nParentID;
	int		lifetime;
	bool	bBelong;
}FISH3D_CMD_S_SEND_GROUP;

typedef struct
{
	DWORD	dwGroupID;
}FISH3D_CMD_S_KILL_GROUP;

typedef struct
{
	DWORD		wChairID;
	LONGLONG	lScore;
	DWORD		dwFishID;
	int			nBScoe;
	LONGLONG	totalScore;
	int 		effectType;
	DWORD 		fishes[100];
	LONGLONG	scores[100];
}FISH3D_CMD_S_KILL_SPECIAL_FISH;

typedef struct 
{  
	DWORD  wChairID;
	DWORD  dwFishID;
	int   nBScoe;  
	int   effectType;  
	DWORD  fishes[100];  
	LONGLONG scores[100]; 

}FISH3D_CMD_S_EFFECT_KILL;

typedef struct  
{ 
	 DWORD wChairID; 
} FISH3D_CMD_C_GET_STATIISTICS_INFO;

typedef struct {  

	DWORD  wChairID;  
	DWORD  dwKillNumber;  
	LONGLONG lIncome;  
	LONGLONG lExpenditure;  
	DWORD  dwCount;  
	DWORD  fishes[100];  
	DWORD  dwKillCounts[100]; 

} FISH3D_CMD_S_GET_STATIISTICS_INFO;

typedef struct {

    DWORD sceneID;
	FISH3D_CMD_S_USER_INFO	userSet[4];
	FISH3D_CMD_S_BULLET_SET	bulletSet[10];

} FISH3D_CMD_S_ENTER_SCENE;

typedef struct {

	DWORD	wChairID;
	DWORD	dwUserID;
	bool 	bKickout;

} FISH3D_CMD_S_LEAVE_GAME;

typedef struct {  
	DWORD wChairID;  
	DWORD dwTimeLeft; 
} FISH3D_CMD_S_TIMEOUT_ALARM;

typedef struct {  
	DWORD  wChairID;  
	DWORD  dwFishID;  
	int   nBaseMultiple;  
	int   nBaseScore;
	int   nBScoe; 
	int   nBMultiple;
	LONGLONG lScore; 
} FISH3D_CMD_S_EFFECT_WHEELSURF;

#pragma pack(0)
