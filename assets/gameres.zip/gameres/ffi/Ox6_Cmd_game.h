#pragma pack(1)
//彩金得主信息
typedef struct {
    LONGLONG lGetCajin;
    char nickName[32*2];
    char cardType[15*2];
}Ox6_CajinInfo;

typedef struct {
    LONGLONG lCaijin;
}CMD_S_Ox6_AllCaijin;
//游戏状态
typedef struct {
    LONGLONG							lCellScore;							//基础积分
    LONGLONG							lCaijin;							//彩金
    Ox6_CajinInfo						caijinInfo[10];
    LONGLONG							lAllCaijin[6];
    bool                                bCaiJin;
}CMD_S_Ox6_StatusFree;

//游戏状态
typedef struct {
    WORD							    	wCallBanker;						//叫庄用户
    BYTE							        cbPlayStatus[6];          //用户状态
}CMD_S_Ox6_StatusCall;

typedef struct {
    LONGLONG								lTurnMaxScore;						//最大下注
    LONGLONG								lTableScore[6];			//下注数目
    BYTE								    cbPlayStatus[6];          //用户状态
    WORD							    	wBankerUser;						//庄家用户
}CMD_S_Ox6_StatusScore;

typedef struct {
    BYTE								    cbPlayStatus[6];          //用户状态
    LONGLONG								lTurnMaxScore;						//最大下注
    LONGLONG								lTableScore[6];			//下注数目
    WORD								    wBankerUser;						//庄家用户

    LONGLONG								lCaijin;							//彩金
    Ox6_CajinInfo							caijinInfo[10];
    LONGLONG								lAllCaijin[6];

    BYTE							    	cbHandCardData[6][5];//桌面扑克
    BYTE						      		bOxCard[6];				//牛牛数据\;
    bool                                    bCaiJin;
    LONGLONG                                lCellScore;
}CMD_S_Ox6_StatusPlay;
//用户叫庄
typedef struct {
    WORD							     	wCallBanker;						//叫庄用户
    bool							    	bFirstTimes;						//首次叫庄
}CMD_S_Ox6_CallBanker;

typedef struct {
    LONGLONG								lTurnMaxScore;						//最大下注
    WORD							     	wBankerUser;						//庄家用户
}CMD_S_Ox6_GameStart;

//用户下注
typedef struct {
    WORD							    	wAddScoreUser;						//加注用户
    LONGLONG								lAddScoreCount;						//加注数目
}CMD_S_Ox6_AddScore;

//游戏结束
typedef struct {
    LONGLONG								lGameTax[6];				//游戏税收
    LONGLONG								lGameScore[6];			//游戏得分
    BYTE							     	cbCardData[6];			//用户扑克
    WORD									wWinUser;							//赢的玩家
    LONGLONG								lCaijin;							//彩金
    LONGLONG								lGetCaijin;
    Ox6_CajinInfo							caijinInfo[10];
}CMD_S_Ox6_GameEnd;

//发牌数据包
typedef struct {
    BYTE								    cbCardData[6][5];	//用户扑克

    BYTE									cbPlayStatus[6];			//游戏状态//
}CMD_S_Ox6_SendCard;

//用户退出
typedef struct {
    WORD						      		wPlayerID;							//退出用户
}CMD_S_Ox6_PlayerExit;

//用户摊牌
typedef struct {
    WORD							     	wPlayerID;							//摊牌用户
    BYTE							      	bOpen;								//摊牌标志
}CMD_S_Ox6_Open_Card;

typedef struct {
    LONGLONG                           lStorage;
    int                                nStorageDeduct;
}CMD_S_Ox6_AdminStorage;

typedef struct {
    BYTE                               cbEnable;
}CMD_S_Ox6_AdminControlEnable;

typedef struct {
    BYTE                              cbType;   //0为ID,1为机器码，2为IP
    DWORD                             dwGameID; //控制ID
    INT                               nPercent; //概率
    INT                               nTimes;   //控制次数，-1表示不限次数
    char                              szMachineID[33]; //控制机器码
}CMD_S_Ox6_AdminControl;

typedef struct {
    LONGLONG                           lStorage;//库存下限
    int                                nPercent ;
}CMD_S_Ox6_AdminFloat;

typedef struct {
    BYTE                               cbEnable;
}CMD_S_Ox6_AdminFloatEnable;

//用户叫庄
typedef struct {
    BYTE							    	bBanker;							//做庄标志
}CMD_C_Ox6_CallBanker;

//用户加注
typedef struct {
    LONGLONG                            nServriValue;
    LONGLONG								lScore;								//加注数目
}CMD_C_Ox6_AddScore;

//用户摊牌
typedef struct {
    LONGLONG                            nServriValue;
    BYTE							    	bOX;								//牛牛标志
}CMD_C_Ox6_OxCard;

typedef struct {
    LONGLONG                           lStorage;
    INT                                nStorageDeduct;
}CMD_C_Ox6_AdminStorageUpdate;

typedef struct {
    BYTE                              cbEnable;
}CMD_C_Ox6_AdminControlEnableUpdate;

typedef struct {
    BYTE                              cbType;   //0为ID,1为机器码，2为IP
    DWORD                             dwGameID; //控制ID
    INT                               nPercent; //概率
    INT                               nTimes;   //控制次数，-1表示不限次数
    char                              szMachineID[33]; //控制机器码
}CMD_C_Ox6_AdminControlAdd;

typedef struct {
    BYTE                              cbType;   //0为ID,1为机器码，2为IP
    DWORD                             dwGameID; //控制ID
    char                              szMachineID[33]; //控制机器码
}CMD_C_Ox6_AdminControlDelete;

typedef struct {
    BYTE                              cbEnable;
}CMD_C_Ox6_AdminFloatEnableUpdate;
typedef struct {
    LONGLONG                           lStorage;//库存下限
    int                                nPercent ;
}CMD_C_Ox6_AdminFloatAdd;

typedef struct {
    LONGLONG                           lStorage;//库存下限
}CMD_C_Ox6_AdminFloatDelete;

#pragma pack()
