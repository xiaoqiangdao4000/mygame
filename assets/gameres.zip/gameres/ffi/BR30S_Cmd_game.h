#pragma pack(1)

//记录信息
typedef struct {
    bool							bInit;
    BYTE							cbPlayerCount;						//闲家点数
    BYTE							cbBankerCount;						//庄家点数
    bool							cbPing;								//平
    bool							bPlayerTwoPair;						//闲对标识
    bool							bBankerTwoPair;						//庄对标识
    bool							bHu;
    bool							bLong;

}BR30S_tagClientGameRecord;

//记录信息
typedef struct {
    BYTE							cbKingWinner;						//天王赢家
    bool							bPlayerTwoPair;						//对子标识
    bool							bBankerTwoPair;						//对子标识
    BYTE							cbPlayerCount;						//闲家点数
    BYTE							cbBankerCount;						//庄家点数
}BR30S_tagServerGameRecord;

typedef struct {
    BYTE cbAckType;					//回复类型
    BYTE cbResult;
    BYTE cbExtendData[20];			//附加数据
}BR30S_CMD_S_CommandResult;

//失败结构
typedef struct {
    WORD							wPlaceUser;							//下注玩家
    BYTE							lBetArea;							//下注区域
    LONGLONG						lPlaceScore;						//当前下注
}BR30S_CMD_S_PlaceBetFail;

//申请庄家
typedef struct {
    WORD							wApplyUser;							//申请玩家
}BR30S_CMD_S_ApplyBanker;

//取消申请
typedef struct {
    WORD							wCancelUser;						//取消玩家
}BR30S_CMD_S_CancelBanker;

//切换庄家
typedef struct {
    WORD							wBankerUser;						//当庄玩家
    LONGLONG						lBankerScore;						//庄家分数
}BR30S_CMD_S_ChangeBanker;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    LONGLONG						lPlayFreeSocre;						//玩家自由金币

    WORD							wBankerUser;						//当前庄家
    LONGLONG						lBankerScore;						//庄家分数
    LONGLONG						lBankerWinScore;					//庄家赢分
    WORD							wBankerTime;						//庄家局数

    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制

    DWORD dwServerId;
}BR30S_CMD_S_StatusFree;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间
    BYTE							cbGameStatus;						//游戏状态

    LONGLONG						lAllBet[8];					//总下注
    LONGLONG						lPlayBet[8];					//玩家下注

    LONGLONG						lPlayBetScore;						//玩家最大下注
    LONGLONG						lPlayFreeSocre;						//玩家自由金币

    LONGLONG						lPlayScore[8];				//玩家输赢
    LONGLONG						lPlayAllScore;						//玩家成绩

    WORD							wBankerUser;						//当前庄家
    LONGLONG						lBankerScore;						//庄家分数
    LONGLONG						lBankerWinScore;					//庄家赢分
    WORD							wBankerTime;						//庄家局数

    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制

    BYTE							cbCardCount[2];						//扑克数目
    BYTE							cbTableCardArray[2][3];				//桌面扑克

    DWORD dwServerId;
}BR30S_CMD_S_StatusPlay;

//游戏空闲
typedef struct {
    BYTE							cbTimeLeave;						//剩余时间
}BR30S_CMD_S_GameFree;

//游戏开始
typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    WORD							wBankerUser;						//庄家位置
    LONGLONG						lBankerScore;						//庄家金币

    LONGLONG						lPlayBetScore;						//玩家最大下注
    LONGLONG						lPlayFreeSocre;						//玩家自由金币

    int								nChipRobotCount;					//人数上限 (下注机器人)
    LONGLONG                         nListUserCount;						//列表人数
    int								nAndriodCount;						//机器人列表人数
    BYTE                           bRealUser[150];
}BR30S_CMD_S_GameStart;

typedef struct {
    WORD							wBetUser;						//庄家位置
    BYTE							cbbetArea;
}BR30S_CMD_S_GameSide;

//用户下注
typedef struct {
    WORD							wChairID;							//用户位置
    BYTE							cbBetArea;							//筹码区域
    LONGLONG						lBetScore;							//加注数目
    BYTE							cbAndroidUser;						//机器标识
}BR30S_CMD_S_PlaceBet;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    BYTE							cbCardCount[2];						//扑克数目
    BYTE							cbTableCardArray[2][3];				//桌面扑克

    LONGLONG						lBankerScore;						//庄家成绩
    LONGLONG						lBankerTotallScore;					//庄家成绩
    INT								nBankerTime;						//做庄次数

    LONGLONG						lPlayScore[8];				//玩家成绩
    LONGLONG						lPlayAllScore;						//玩家成绩

    LONGLONG						lRevenue;							//游戏税收
}BR30S_CMD_S_GameEnd;

typedef struct {
    TCHAR                           szUserName[32];
    LONGLONG                        lWinScore;
}BR30S_tagRankUser;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间

    BYTE							cbCardCount[2];						//扑克数目
    BYTE							cbTableCardArray[2][3];				//桌面扑克

    LONGLONG						lBankerScore;						//庄家成绩
    LONGLONG						lBankerTotallScore;					//庄家成绩
    INT								nBankerTime;						//做庄次数

    LONGLONG						lPlayScore[8];				//玩家成绩
    LONGLONG						lPlayAllScore;						//玩家成绩

    LONGLONG						lRevenue;							//游戏税收

    BYTE                            cbRankCount;
    BR30S_tagRankUser                     RankUser[5];
}BR30S_CMD_S_GameEndEx;

typedef struct {
    BYTE							cbTimeLeave;						//剩余时间
    BYTE							cbGameStatus;						//游戏状态

    LONGLONG						lAllBet[8];					//总下注
    LONGLONG						lPlayBet[8];					//玩家下注

    LONGLONG						lPlayBetScore;						//玩家最大下注
    LONGLONG						lPlayFreeSocre;						//玩家自由金币

    LONGLONG						lPlayScore[8];				//玩家输赢
    LONGLONG						lPlayAllScore;						//玩家成绩

    WORD							wBankerUser;						//当前庄家
    LONGLONG						lBankerScore;						//庄家分数
    LONGLONG						lBankerWinScore;					//庄家赢分
    WORD							wBankerTime;						//庄家局数

    bool							bEnableSysBanker;					//系统做庄

    LONGLONG						lApplyBankerCondition;				//申请条件
    LONGLONG						lAreaLimitScore;					//区域限制

    BYTE							cbCardCount[2];						//扑克数目
    BYTE							cbTableCardArray[2][3];				//桌面扑克

    DWORD dwServerId;

    LONGLONG		lEndBankerScore;								//庄家当局成绩
    BYTE			cbRankCount;
    BR30S_tagRankUser		RankUser[5];
}BR30S_CMD_S_StatusPlayEx;

typedef struct {
    BYTE cbReqType;
    BYTE cbExtendData[20];			//附加数据
}BR30S_CMD_C_AdminReq;

//用户下注
typedef struct {
    BYTE							cbBetArea;						//筹码区域
    LONGLONG						lBetScore;						//加注数目
}BR30S_CMD_C_PlaceBet;

#pragma pack()
