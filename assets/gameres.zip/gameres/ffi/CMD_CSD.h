#pragma pack(1)
//游戏状态
typedef struct 
{
	LONGLONG			lCellScore;										//底注
	DWORD				dwFreeGames;									//免费次数
	LONGLONG 			lJettonScore;									//上次下注分数
	LONGLONG   			lFreeGameWinScore;//免费游戏累计赢得积分
}CSD_CMD_S_Status;

//用户下注
typedef struct 
{
	LONGLONG			lWinScore;										//开奖赢分
	BYTE				cbCardDatas[15];							//牌型数据
	DWORD				dwFreeGames;									//免费次数
}CSD_CMD_S_Bet;

//水浒传游戏
typedef struct 
{
	LONGLONG		    lJettonScore;								//底注
}CSD_CMD_C_Bet;
#pragma pack()