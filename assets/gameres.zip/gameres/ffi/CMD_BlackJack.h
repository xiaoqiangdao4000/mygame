#pragma pack(push)
#pragma pack(1)

typedef struct  
{
	LONG							lMaxGold;							
	LONG							lBasicGold;							
	BYTE							cbTimeBetCard;						
	BYTE							cbTimeCallCard;						
	WORD				 			wCurrentUser;						
	bool						    bAddGoldEnd[3][2];	    	
	LONG							lTableGold[3][2];			
	BYTE						    bInsurance[3];	    			    
	bool							cbCutCard[3];               

	BYTE							cbCardStatus[3];		   
	BYTE							cbCutCardStatus[3];		   

	BYTE							cbTableCardCount[3];		
	BYTE							cbTableCardArray[3][21];	

	BYTE							cbTableCutCardCount[3];		
	BYTE							cbTableCutCardArray[3][21];	
	
	BYTE							cbTableBankCardCount;		
	BYTE							cbTableBankCardArray[21];
}BJ_CMD_S_Recover_Game_Status;

typedef struct  
{
	BYTE        						cbTimeBetCard;
}BJ_CMD_S_Gaming_Start;

typedef struct 
{
 	BYTE        						wState;     
}BJ_CMD_S_Gaming_State;

typedef struct  
{
	WORD								wCurrentUser;						
}BJ_CMD_S_Gaming_HitCard;

typedef struct  
{
	WORD								wAddUser;							
	LONG								lLastAddGold;						
}BJ_CMD_S_Gaming_Bet;

typedef struct  
{
	WORD								wAddUser;							
	LONG								lLastAddGold;						
	WORD        						wCurrentUser;      
 	BYTE        						cbCardData;       
 	BYTE        						cbCardSum;              
	bool        						bCutCard; 
}BJ_CMD_S_Gaming_Double;

typedef struct  
{
	BYTE								cbCardData[3][2];			
	BYTE								cbBankCard[2];			
	BYTE        						cbBankSum;
	BYTE								cbCardSum[3];	          
	bool								bInsurance;				
	WORD        						wCurrentUser;
}BJ_CMD_S_Gaming_InitCard;

typedef struct  
{
	WORD        						wSendUser;
	WORD								wCurrentUser;						
	BYTE								cbUserCard;						  
	BYTE								cbCardSum;	            			
	bool								bCutCard;	            		
}BJ_CMD_S_Gaming_SendCard;


typedef struct  
{
	WORD								wUser;					
	BYTE								bInsurance;				
}BJ_CMD_S_Gaming_UserInsurance;

typedef struct  
{
	BYTE								bBankValue;
	bool								bIsBlackJace;
	BYTE        						cbCardSum;  
	WORD        						wCurrentUser;
}BJ_CMD_S_Gaming_BankerInsurance;

typedef struct  
{
	WORD								wUserChairID;						
	WORD								wCurrentUser;
}BJ_CMD_S_UserLeft;

typedef struct  
{
	WORD								wCutCardUser;						
	WORD        						wCurrentUser;
	BYTE								cbFirstCard;					   
	BYTE								cbSecondCard;						
	BYTE								cbFirstCardSum;					  
	BYTE								cbSecondCardSum;					
}BJ_CMD_S_Gaming_CutCard;

typedef struct  
{
	WORD								wStopUser;							
	WORD								wCurrentUser;						
	bool								bCutCard;	            			
}BJ_CMD_S_Gaming_StopCard;

typedef struct  
{
	WORD								wBrustUser;							
	bool								bCutCard;	            			
	WORD								wCurrentUser;						
}BJ_CMD_S_Gaming_BrustCard;

typedef struct  
{
	LONGLONG							lGameGold[3][2];			
	bool								bCutCard[3];               
	BYTE								cbUserCardNum[3];
	BYTE								cbUserCard[3][21];
	BYTE								cbCutCardNum[3];
	BYTE								cbCutCard[3][21];	
	BYTE								cbCardSum[3];	   			
	BYTE								cbCutCardSum[3];	     	
	BYTE								cbBankCardSum;
	BYTE								cbBankCardNum;
	BYTE								cbBankCard[21];
}BJ_CMD_S_Gaming_End;

typedef struct
{
	LONG 								lScore[3];		
}BJ_CMD_S_Gaming_Score_Update; 		

typedef struct  
{
	LONG								lGold;								
}BJ_CMD_C_Gaming_Bet;

typedef struct  
{
	bool								bCutCard;	            			
}BJ_CMD_C_Gaming_HitCard;

typedef struct  
{
	bool								bCutCard;	            			
}BJ_CMD_C_Gaming_StopCard;

typedef struct  
{
	bool								bInsurance;	            		
}BJ_CMD_C_Gaming_Insurance;

typedef struct 
{
 	bool        						bCutCard;                
}BJ_CMD_C_Gaming_Double;

typedef struct 
{
 	WORD  wchairid;
 	BYTE  bCard[2];
}BJ_CMD_C_SetUserCard;

#pragma pack(pop)