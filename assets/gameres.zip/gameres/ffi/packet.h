#pragma pack(1)

#pragma mark 内核命令
//网络验证
typedef struct{
	TCHAR		szValidateKey[64];				//验证字符
}TCP_Validate;

//网络内核
typedef struct {
    DWORD       dwIPAdress;                     //转发IP头
	BYTE		cbDataKind;						//数据类型
	BYTE		cbCheckCode;					//效验字段
	WORD		wPacketSize;					//数据大小
}TCP_Info;

//网络命令
typedef struct{
    DWORD       dwIPAdress;                     //转发IP头
	WORD		wMainCmdID;						//主命令码
	WORD		wSubCmdID;						//子命令码
}TCP_Command;

//网络包头
typedef struct{
	TCP_Info	TCPInfo;						//基础结构
	TCP_Command	CommandInfo;					//命令信息
}TCP_Head;

//网络缓冲
typedef struct{
	TCP_Head	Head;							//数据包头
	BYTE		cbBuffer[(16384-sizeof(TCP_Head))];	//数据缓冲
}TCP_Buffer;

#pragma pack()

