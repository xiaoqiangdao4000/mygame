#pragma pack(4)

typedef struct {
    BYTE                            cbWeaveKind;                        //组合类型
    BYTE                            cbCenterCard;                       //中心扑克
    BYTE                            cbPublicCard;                       //公开标志
    WORD                            wProvideUser;                       //供应用户
    BYTE                            cbCardData[4];                      //组合数据
}WZMJ_WeaveItem_WZMJ;

typedef struct {
    WZMJ_WeaveItem_WZMJ             WeaveItemArray[2][5];                        //组合类型                     //组合数据
}WZMJ_WeaveItem_Array_New;

#pragma pack(1)

typedef unsigned int        UINT32;

//组合子项
typedef struct {
    BYTE							cbWeaveKind;						//组合类型
    BYTE							cbCenterCard;						//中心扑克
    BYTE							cbPublicCard;						//公开标志
    WORD							wProvideUser;						//供应用户
    BYTE							cbCardData[4];						//组合数据
}WZMJ_CMD_WeaveItem_WZMJ;

typedef struct {
    WZMJ_CMD_WeaveItem_WZMJ         WeaveItemArray[2][5];                        //组合类型                     //组合数据
}WZMJ_WeaveItem_Array_Base;


typedef struct {
    BYTE             cbCard[17];
    BYTE             cbCount;
}WZMJ_CMD_S_TopUserCard_WZMJ;

//空闲状态
typedef struct {
    LONGLONG						lCellScore;							//基础金币
    LONGLONG						lMinEnterScore;
    WORD							wBankerUser;						//庄家用户
    bool							bTrustee[2];			//是否托管
    unsigned short					szGameRoomName[32];			//房间名称
}WZMJ_CMD_S_StatusFree_WZMJ;

//买底状态
typedef struct {
    LONGLONG						lCellScore;							//基础金币
    WORD							wBankerUser;						//庄家用户
    bool							bTrustee[2];			//是否托管
    BYTE							cbLianZhuangCount;					//连庄局数
    BYTE							bMaiDi[2];			//买底状态
    bool							bHaveMaiDi[2];		//是否买过
    unsigned short					szGameRoomName[32];			//房间名称
}WZMJ_CMD_S_StatusChip_WZMJ;

typedef struct {
    LONGLONG						lCellScore;									//单元积分
    WORD							wBankerUser;								//庄家用户
    WORD							wCurrentUser;								//当前用户
    WORD							wReplaceUser;								//花牌替换用户
    BYTE							cbQuanFeng;									//圈风
    BYTE							cbHuaCardCount[2];				//花牌数目
    BYTE							cbHuaCardData[2][8];				//花牌数组
    BYTE							cbHuaCardInfo[2][8];				//花牌信息

    BYTE							cbActionCard;								//动作扑克
    BYTE							cbActionMask;								//动作掩码-吃，胡，碰，杠
    BYTE							cbHearStatus[2];					//听牌状态
    BYTE							cbLeftCardCount;							//剩余数目
    bool							bTrustee[2];						//是否托管
    bool							bTuoPai;									//是否脱牌

    WORD							wOutCardUser;								//出牌用户
    BYTE							cbOutCardData;								//出牌扑克
    BYTE							cbDiscardCount[2];				//丢弃数目
    BYTE							cbDiscardCard[2][60];				//丢弃记录

    BYTE							cbFengCardData[8];							//风牌记录
    BYTE							cbFengCardCount;							//风牌记录

    BYTE							cbCardCount;								//扑克数目
    BYTE							cbCardData[17];						//扑克列表
    BYTE							cbSendCardData;								//发送扑克

    BYTE							cbWeaveCount[2];					//组合数目
    WZMJ_CMD_WeaveItem_WZMJ				WeaveItemArray[2][5];		//组合扑克

    WORD							wHeapHead;									//堆立头部
    WORD							wHeapTail;									//堆立尾部
    BYTE							cbHeapCardInfo[4][2];						//堆牌信息

    BYTE							bMagicIndex;								//财神牌值
    WORD							wMagicPos;									//财神方位
    BYTE							cbHeapMagic;								//财神堆位	(从尾部数起）
    unsigned short					szGameRoomName[32];			//房间名称
}WZMJ_CMD_S_StatusPlay_WZMJ;

//买底消息
typedef struct {
    WORD							wBankerUser;								//庄家位置
    BYTE							cbLianZhuangCount;							//连庄局数
    LONGLONG						lCellScore;									//底注
}WZMJ_CMD_S_Chip_WZMJ;

//游戏开始
typedef struct {
    UINT32                          lSiceCount;									//骰子点数
    WORD							wBankerUser;								//庄家用户
    WORD							wCurrentUser;								//当前用户
    WORD							wReplaceUser;								//补牌用户
    BYTE							cbUserAction;								//用户动作
    BYTE							cbCardData[17];					//扑克列表
    BYTE							cbQuanFeng;									//圈风
    WORD							wHeapHead;									//堆立牌头
    WORD							wHeapTail;									//堆立牌尾
    BYTE							cbHeapCardInfo[4][2];						//堆立信息
    BYTE							bMagicIndex;								//财神牌值
    WORD							wMagicPos;									//财神方位
    BYTE							cbHeapMagic;								//财神堆位	(从尾部数起）
    BYTE							cbLianZhuangCount;							//连庄计数
}WZMJ_CMD_S_GameStart_WZMJ;

//出牌命令
typedef struct {
    WORD							wOutCardUser;						//出牌用户
    BYTE							cbOutCardData;						//出牌扑克
}WZMJ_CMD_S_OutCard_WZMJ;

//发送扑克
typedef struct {
    BYTE							cbCardData;							//扑克数据
    BYTE							cbActionMask;						//动作掩码
    WORD							wCurrentUser;						//当前用户
    WORD							wReplaceUser;						//补牌用户
    WORD							wSendCardUser;						//发牌用户
    bool							bTail;								//末尾发牌
}WZMJ_CMD_S_SendCard_WZMJ;

//操作提示
typedef struct {
    WORD							wResumeUser;						//还原用户
    BYTE							cbActionMask;						//动作掩码
    BYTE							cbActionCard;						//动作扑克
}WZMJ_CMD_S_OperateNotify_WZMJ;

//操作命令
typedef struct {
    WORD							wOperateUser;						//操作用户
    WORD							wProvideUser;						//供应用户
    BYTE							cbOperateCode;						//操作代码
    BYTE							cbOperateCard[3];					//操作扑克
    bool							bTuoPai;							//是否脱牌
}WZMJ_CMD_S_OperateResult_WZMJ;

typedef struct {
    bool							bIsEscape;
    LONGLONG						lGameTax;							//游戏税收
    WORD							wProvideUser;						//供应用户
    BYTE							cbProvideCard;						//供应扑克
    unsigned						dwChiHuKind[2];		//胡牌类型
    unsigned						dwChiHuRight[3];		//胡牌类型
    BYTE							cbHuaCardCount;						//花牌个数
    BYTE							cbFanCount;							//总番数

    LONGLONG						lGameScore[2];		//游戏积分

    BYTE							cbCardCount[2];		//扑克数目
    BYTE							cbCardData[2][17];	//扑克数据
}WZMJ_CMD_S_GameEnd_WZMJ;

//用户托管
typedef struct {
    bool							bTrustee;							//是否托管
    WORD							wChairID;							//托管用户
}WZMJ_CMD_S_Trustee_WZMJ;

//用户听牌
typedef struct {
    WORD							wChairId;							//听牌用户
}WZMJ_CMD_S_Listen_WZMJ;

//补牌命令
typedef struct {
    WORD							wReplaceUser;						//补牌用户
    BYTE							cbReplaceCard;						//补牌扑克
}WZMJ_CMD_S_ReplaceCard_WZMJ;

//买底结果
typedef struct {
    bool							bTotal;								//是否全部
    WORD							wMaiDiUser;							//买底用户
    BYTE							bMaidi[2];			//买底类型
}WZMJ_CMD_S_Chip_Result_WZMJ;

//出牌命令
typedef struct {
    BYTE							cbCardData;							//扑克数据
}WZMJ_CMD_C_OutCard_WZMJ;

//操作命令
typedef struct {
    BYTE							cbOperateCode;						//操作代码
    BYTE							cbOperateCard[3];					//操作扑克
}WZMJ_CMD_C_OperateCard_WZMJ;

//用户听牌
typedef struct {
    BYTE							cbListen;							//听牌用户
}WZMJ_CMD_C_Listen_WZMJ;

//用户托管
typedef struct {
    bool							bTrustee;							//是否托管
}WZMJ_CMD_C_Trustee_WZMJ;

//补牌命令
typedef struct {
    BYTE							cbCardData;							//扑克数据
}WZMJ_CMD_C_ReplaceCard_WZMJ;

//买底消息
typedef struct {
    BYTE							bMaiDi;								//买底类型
}WZMJ_CMD_C_Chip_WZMJ;

#pragma pack()
