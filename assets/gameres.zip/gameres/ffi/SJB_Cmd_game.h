#pragma pack(4)

typedef struct
{
    int match_id;//赛程ID
    int match_state;//比赛状态
    int match_disable;//是否封盘
    int match_start_date;//比赛开始时间
    int match_opened_time;//开盘时间

    //pk_asian_ 为前缀的是亚盘（让球）
    int pk_asian_id;//盘口ID （下注是需要原样回传给存储过程） INT
    int pk_asian_typeid;//盘口类型ID （下注是需要原样回传给存储过程） INT
    double pk_asian_hteam;//主胜 DECIMAL(18, 2) 保留两位小数
    int pk_asian_hteam_areaid;//主胜区域ID（下注是需要原样回传给存储过程） INT
    double pk_asian_handicap;//盘口 DECIMAL(18, 2) 保留两位小数
    double pk_asian_vteam;//客胜 DECIMAL(18, 2) 保留两位小数
    int pk_asian_vteam_areaid;//客胜区域ID（下注是需要原样回传给存储过程） INT
    int pk_asian_disable;//盘口禁用状态 0可用 1禁用 INT
    LONGLONG pk_asian_totalpool;//总奖池 BIGINT
    LONGLONG pk_asian_match_minjetton;//最小下注 BIGINT

    //pk_europe_ 为前缀的是欧盘（胜平负）
    int pk_europe_id;//盘口ID INT
    int pk_europe_typeid;//盘口类型ID （下注是需要原样回传给存储过程）INT
    double pk_europe_won;//胜赔率 DECIMAL(18, 2) 保留两位小数
    int pk_europe_won_areaid;//胜区域ID（下注是需要原样回传给存储过程）INT
    double pk_europe_drawn;//平局赔率 DECIMAL(18, 2) 保留两位小数
    int pk_europe_drawn_areaid;//平区域ID（下注是需要原样回传给存储过程）INT
    double pk_europe_lost;//负赔率 DECIMAL(18, 2) 保留两位小数
    int pk_europe_lost_areaid;//负区域ID（下注是需要原样回传给存储过程）INT
    int pk_europe_disable;//盘口禁用状态 0可用 1禁用 INT
    LONGLONG pk_europe_totalpool;//总奖池 BIGINT
    LONGLONG pk_europe_minjetton;//最小下注 BIGINT

    //pk_bs_ 为前缀的是大小球
    int pk_bs_id;//盘口ID INT
    int pk_bs_typeid;//盘口类型ID （下注是需要原样回传给存储过程）INT
    double pk_bs_big;//大赔率 DECIMAL(18, 2) 保留两位小数
    int pk_bs_big_areaid;//大区域ID（下注是需要原样回传给存储过程） INT
    double pk_bs_handicap;//盘口 DECIMAL(18, 2) 保留两位小数
    double pk_bs_small;//小赔率 DECIMAL(18, 2) 保留两位小数
    int pk_bs_small_areaid;//小区域ID（下注是需要原样回传给存储过程） INT
    int pk_bs_disable;//盘口禁用状态 0可用 1禁用  INT
    LONGLONG pk_bs_totalpool;//总奖池 BIGINT
    LONGLONG pk_bs_minjetton;//最小下注 BIGINT
    BYTE cbActive;
    CHAR szStartTime[20];
}SJB_MatchInfo;

typedef struct
{
    DWORD  wMatchID;   //比赛id
    int match_hteam_logo_id;  //主场队id
    int match_vteam_logo_id;  //客场队id
    int match_start_date;//比赛开始时间
    int match_opened_time;//开盘时间
    int match_end_time;//封盘时间
    int match_state;//比赛状态说明：0比赛异常，1未开赛，2上半场，3中场，4下半场，5加时赛上半场，6加时赛下半场，7点球决战，8完场，9推迟，10中断，11腰斩，12取消，13待定
    int match_disable;//是否封盘:0 开盘可以下注，1 封盘禁止下注
    TCHAR match_groupname[32];
    int match_guessing_id;//是否封盘:0 开盘可以下注，1 封盘禁止下注 并且这个ID需要回传到后端
    int match_settle_status;//结算状态 0未结算 1奖励正在计算中 2奖励已计算，正在派奖 3派奖完成
    CHAR szStartTime[20];
}SJB_MatchMenu;

//////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct {
    DWORD dwUserID;
    int MatchID;    //赛程ID
    int HandicapID; //盘口ID
    int nAreaID; //服务器定义
    LONGLONG BeforeScore; //下注前携带欢乐豆
    LONGLONG LastScore;   //下注成功后剩余欢乐豆
    int returnvalue;      //错误码

    //returnvalue = 10001：胜平负盘口发生变更
    //胜平负盘口数据集：（始终只会有一条数据）
    int pk_europe_id; //盘口ID
    double pk_europe_won; //胜赔率 DECIMAL(18, 2) 保留两位小数
    double pk_europe_drawn; //平局赔率 DECIMAL(18, 2) 保留两位小数
    double pk_europe_lost; //负赔率 DECIMAL(18, 2) 保留两位小数

    //10002：受让球盘口发生变更
    //受让球盘口数据集：（始终只会有一条数据）
    int pk_asian_id; //盘口ID （下注是需要原样回传给存储过程） INT
    double pk_asian_hteam; //主胜 DECIMAL(18, 2) 保留两位小数
    double pk_asian_handicap; //盘口 DECIMAL(18, 2) 保留两位小数
    double pk_asian_vteam; //客胜 DECIMAL(18, 2) 保留两位小数

    //10003：大小球盘口发生变更
    //大小球盘口数据集：
    int pk_bs_id; //盘口ID INT
    double pk_bs_big;//大赔率 DECIMAL(18, 2) 保留两位小数
    double pk_bs_handicap;//盘口 DECIMAL(18, 2) 保留两位小数
    double pk_bs_small;//小赔率 DECIMAL(18, 2) 保留两位小数
    TCHAR strErrorDescribe[128];//输出信息
    int nServerTime;
}SJB_CMD_S_JETTON;


typedef struct{
    int nMatchID;
    int wJettonAreaID;
    //int lJettonAreaTotalPlayerCount[3];  //各门的下注人次总和
    LONGLONG lJettonSoloTotal[3];//各门的个人的下注总和
    //int lJettonTotalPlayerCount;         //下注总人次
    int nServerTime;
    BYTE cbActive;//客户端发给服务端，服务端原样返回，主动下发的时候为0
    int lVJettonAreaTotalPlayerCount[3];  //各门下注总人次虚拟总和
    int lVJettonTotalPlayerCount;         //下注虚拟总人次
    LONGLONG lForecastScore[3];           //预计盈利
}SJB_CMD_S_Send_Jetton_Total;

typedef struct
{
    SJB_MatchInfo tInfo;
    int nServerTime;
}SJB_CMD_S_Send_Match_Info;

typedef struct
{
    int nCount;
    int nServerTime;
    SJB_MatchMenu tMenu[80];
    BYTE cbActive;
}SJB_CMD_S_Send_Match_Menu;

typedef struct{  
    int nMatchID;  //赛事id
    TCHAR szName[32]; //昵称
    LONGLONG lJetton; //下注数量
}SJB_CMD_S_BROADCAST_JETTON;

typedef struct 
{  
   int nMatchID; //赛事id
}SJB_CMD_S_BROADCAST_NOTICE;

typedef struct
{
    int guessing_id;//竞猜ID
    LONGLONG guessing_totalpool;//总奖池
    int guessing_count;//参与竞猜次数
    int hteam_logo_id;//主队ID
    int vteam_logo_id;//客队ID
    int endtime;//竞猜结束时间
    LONGLONG guessing_price;//单次竞猜购买价格
    int guessing_surpluscount;//剩余竞猜次数
    LONGLONG guessing_gifttimescore;//下注多少欢乐豆赠送一次竞猜，可累计赠送
    int returnvalue;//情况下才会有正常的数据集返回,否则 returnvalue 值就是错误码， @strErrorDescribe 为错误描述
    TCHAR strErrorDescribe[128];//输出信息
    BYTE cbActive;
    TCHAR match_groupname[32];
}SJB_CMD_S_Send_GuessingInfo;

typedef struct
{
    int GuessingID;//竞猜ID
    LONGLONG BeforeScore;//购买前身上携带欢乐豆
    LONGLONG LastScore;//购买后身上剩余花了都
    int Guessing_SurplusCount;//购买成功之后，剩余竞猜次数
    int returnvalue;//情况下才会有正常的数据集返回,否则 returnvalue 值就是错误码， @strErrorDescribe 为错误描述
    TCHAR strErrorDescribe[128];//输出信息
}SJB_CMD_S_Send_GuessBuy;

typedef struct
{
    int GuessingID;//竞猜ID
    int Guessing_SurplusCount;//剩余竞猜次数
    int Guessing_PartakeCount;//本期竞猜总份数
    int returnvalue;//情况下才会有正常的数据集返回,否则 returnvalue 值就是错误码， @strErrorDescribe 为错误描述
    TCHAR strErrorDescribe[128];//输出信息
}SJB_CMD_S_Send_GuessJetton;


//////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct
{
    DWORD wMatchID;     //赛事id
    BYTE cbActive;
}SJB_CMD_C_Request_Match_Info;

typedef struct
{ 
    DWORD wMatchID;          //赛事id
    int wHandicapID;        //盘口ID
    int wHandicapTypeID;    //盘口类型(pk_asian_typeid, pk_europe_typeid, pk_bs_typeid三个类型的值，下注那个类型就传那个类型 1胜平负 2受让球 3大小球)
    int wJettonAreaID;      //下注区域ID(各个盘口的区域ID 【_areaid】    1胜负平主胜 2胜负平和局 3胜负平客胜 4受让球主胜 5受让球客胜 6大小球大球 7大小球小球)
    LONGLONG lJettonScore;  //下注金额
    char strTempPassword[32];//临时密码
    int cbDeviceType;        //设备ID
}SJB_CMD_C_Jetton;

typedef struct {
    DWORD wMatchID;     //赛事id
    BYTE cbJettonType;  //下注种类，让球，胜负平，大小
    BYTE cbActive; //客户端传给服务端的, 服务端原样返回
}SJB_CMD_C_Request_Jetton_Total;

typedef struct {
    BYTE cbActive;
}SJB_CMD_C_Request_Menu;

typedef struct
{
    int dwGuessingID;
    char strTempPassword[32];//临时密码
    int cbDeviceType;        //设备ID
}SJB_CMD_C_Request_Guess_buy;

typedef struct
{
    int dwGuessingID;
    char strTempPassword[32];//临时密码
    int cbDeviceType;        //设备ID
    BYTE cbActive;
}SJB_CMD_C_Request_GuessingInfo;

typedef struct
{
    int dwGuessingID;
    char strTempPassword[32];//临时密码
    int cbDeviceType;        //设备ID
    int dwHteamScore;       //主队比分
    int dwVteamScore;       //客队比分
}SJB_CMD_C_Request_Guess_Jetton;

#pragma pack()
