#pragma pack(1)

//手机客户端请求查询老玩家七天签到信息
typedef struct 
{
	int	nUserID;
}CMD_MB_LoadSevenDaySignForRegress;

//服务器返回老玩家七天签到信息
typedef struct 
{
	SYSTEMTIME BeginTime;
	SYSTEMTIME EndTime;
	SYSTEMTIME ModifyTime;
	DWORD dwDayCount;
	DWORD dwDaySign;
	DWORD dwAward;
	DWORD dwFirstNumber;
	DWORD dwSecondNumber;
	DWORD dwThirdNumber;
	DWORD dwForthNumber;
	DWORD dwFifthNumber;
	DWORD dwSixNumber;
}CMD_MB_LoadSevenDaySignForRegressResult;

//手机客户端请求签到
typedef struct 
{
	int					nUserID;
	CHAR szMachineID[33]; //机器标识
}CMD_MB_SevenDaySignForRegress;

//服务器签到结果
typedef struct 
{
	DWORD dwDayCount;
	DWORD dwDaySign;
	DWORD dwAward;
	DWORD dwFirstNumber;
	DWORD dwSecondNumber;
	DWORD dwThirdNumber;
	DWORD dwForthNumber;
	DWORD dwFifthNumber;
	DWORD dwSixNumber;
}CMD_MB_SevenDaySignForRegressResult;

#pragma pack()