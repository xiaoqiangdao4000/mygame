#pragma pack(1)

typedef struct {
    BYTE                            cbWeaveKind;                        //组合类型
    BYTE                            cbCenterCard;                       //中心扑克
    BYTE                            cbPublicCard;                       //公开标志
    WORD                            wProvideUser;                       //供应用户
    BYTE                            cbCardData[4];                      //组合数据
}WZMJex_WeaveItem_WZMJex;

typedef struct {
    WZMJex_WeaveItem_WZMJex             WeaveItemArray[2][5];                        //组合类型                     //组合数据
}WZMJex_WeaveItem_Array_New;

#pragma pack(1)

typedef unsigned int        UINT32;

//组合子项
typedef struct {
    BYTE							cbWeaveKind;						//组合类型
    BYTE							cbCenterCard;						//中心扑克
    BYTE							cbPublicCard;						//公开标志
    WORD							wProvideUser;						//供应用户
    BYTE							cbCardData[4];						//组合数据
}WZMJex_CMD_WeaveItem_WZMJex;

typedef struct {
    WZMJex_CMD_WeaveItem_WZMJex         WeaveItemArray[2][5];                        //组合类型                     //组合数据
}WZMJex_WeaveItem_Array_Base;


typedef struct {
    BYTE             cbCard[17];
    BYTE             cbCount;
}WZMJex_CMD_S_TopUserCard_WZMJex;

//空闲状态
typedef struct
{
  //历史积分
  LONGLONG            lTurnScore[2];          //积分信息
  LONGLONG            lCollectScore[2];          //积分信息

  LONGLONG            lCellScore;                  //基础金币
  WORD              wBankerUser;                //庄家用户
  bool              bTrustee[2];            //是否托管
}WZMJex_CMD_S_StatusFree_WZMJex;


//买底状态
typedef struct {
    LONGLONG						lCellScore;							//基础金币
    WORD							wBankerUser;						//庄家用户
    bool							bTrustee[2];			//是否托管
    BYTE							cbLianZhuangCount;					//连庄局数
    BYTE							bMaiDi[2];			//买底状态
    bool							bHaveMaiDi[2];		//是否买过
    unsigned short					szGameRoomName[32];			//房间名称
}WZMJex_CMD_S_StatusChip_WZMJex;

//游戏状态
typedef struct
{
    //历史积分
    LONGLONG                        lTurnScore[2];                              //积分信息
    LONGLONG                        lCollectScore[2];                           //积分信息

    //游戏变量
    LONGLONG                        lCellScore;                                 //单元积分
    WORD                            wBankerUser;                                //庄家用户
    WORD                            wCurrentUser;                               //当前用户
    WORD                            wReplaceUser;                               //花牌替换用户
    WORD                            wResumeUser;                                //还原用户
    BYTE                            cbQuanFeng;                                 //圈风

    //状态变量
    BYTE                            cbActionCard;                               //动作扑克
    BYTE                            cbActionMask;                               //动作掩码
    BYTE                            cbHearStatus[2];                            //听牌状态
    BYTE                            cbLeftCardCount;                            //剩余数目
    bool                            bTrustee[2];                                //是否托管

    //出牌信息
    WORD                            wOutCardUser;                               //出牌用户
    BYTE                            cbOutCardData;                              //出牌扑克
    BYTE                            cbDiscardCount[2];                          //丢弃数目
    BYTE                            cbDiscardCard[2][60];                       //丢弃记录

    //扑克数据
    BYTE                            cbCardCount;                                //扑克数目
    BYTE                            cbCardData[14];                             //扑克列表
    BYTE                            cbSendCardData;                             //发送扑克
    BYTE                            cbFlowerCardData[2][8];                     //花牌扑克

    //组合扑克
    BYTE                            cbWeaveCount[2];                            //组合数目
    WZMJex_CMD_WeaveItem_WZMJex     WeaveItemArray[2][4];                       //组合扑克

    //堆立信息
    WORD                            wHeapHead;                                  //堆立头部
    WORD                            wHeapTail;                                  //堆立尾部
    BYTE                            cbTailCount[2];                             //尾部数目
    BYTE                            cbHeapCardInfo[2][2];                       //堆牌信息
    TCHAR                           szGuid[9];                                  //记录标识
}WZMJex_CMD_S_StatusPlay_WZMJex;

//买底消息
typedef struct {
    WORD							wBankerUser;								//庄家位置
    BYTE							cbLianZhuangCount;							//连庄局数
    LONGLONG						lCellScore;									//底注
}WZMJex_CMD_S_Chip_WZMJex;

//游戏开始
typedef struct
{
    WORD                            wSiceCount;                                 //骰子点数
    WORD                            wBankerUser;                                //庄家用户
    WORD                            wCurrentUser;                               //当前用户
    WORD                            wReplaceUser;                               //补牌用户
    BYTE                            cbUserAction;                               //用户动作
    BYTE                            cbCardData[14];                             //扑克列表
    BYTE                            cbQuanFeng;                                 //圈风
    WORD                            wHeapHead;                                  //堆立牌头
    WORD                            wHeapTail;                                  //堆立牌尾
    BYTE                            cbTailCount[2];                             //尾部数目
    BYTE                            cbHeapCardInfo[2][2];                       //堆立信息
    TCHAR                           szGuid[9];                                  //记录标识

}WZMJex_CMD_S_GameStart_WZMJex;

//出牌命令
typedef struct {
    WORD							wOutCardUser;						//出牌用户
    BYTE							cbOutCardData;						//出牌扑克
}WZMJex_CMD_S_OutCard_WZMJex;

//发送扑克
typedef struct {
    BYTE							cbCardData;							//扑克数据
    BYTE							cbActionMask;						//动作掩码
    WORD							wCurrentUser;						//当前用户
    WORD							wReplaceUser;						//补牌用户
    WORD							wSendCardUser;						//发牌用户
    bool							bTail;								//末尾发牌
}WZMJex_CMD_S_SendCard_WZMJex;

//用户听牌 获取可以出的牌
typedef struct 
{
  BYTE              cbOutCard;              //可出的牌
  BYTE              cbCanHuCard[9];            //可以胡的牌
  BYTE              cbPoint[9];              //胡牌番数
  BYTE              cbLeftCount[9];            //剩余数量
}WZMJex_CMD_ListenCard_WZMJex;


//操作提示
typedef struct {
    WORD							wResumeUser;						//还原用户
    BYTE							cbActionMask;						//动作掩码
    BYTE							cbActionCard;						//动作扑克
}WZMJex_CMD_S_OperateNotify_WZMJex;

//操作命令
typedef struct {
    WORD							wOperateUser;						//操作用户
    WORD							wProvideUser;						//供应用户
    BYTE							cbOperateCode;						//操作代码
    BYTE							cbOperateCard[3];					//操作扑克
    BYTE              cbListenCode;                       //听牌
}WZMJex_CMD_S_OperateResult_WZMJex;

//游戏结束
typedef struct 
{
  WORD                              bIsEscape;                      //强退用户
  LONGLONG                          lGameTax;                       //游戏税收
  //结束信息
  WORD                              wProvideUser;                   //供应用户
  BYTE                              cbProvideCard;                  //供应扑克
  DWORD                             dwChiHuKind[2];                 //胡牌类型
  DWORD                             dwChiHuRight[3];                //胡牌类型
  WORD                              cbFanCount;                     //总番数
  WORD                              wTimesCount;                    //总倍数
  //积分信息
  LONGLONG                          lGameScore[2];                  //游戏积分

  //扑克信息
  BYTE                              cbCardCount[2];                 //扑克数目
  BYTE                              cbCardData[2][14];              //扑克数据

  //组合扑克
  BYTE                              cbWeaveCount;                   //组合数目
  WZMJex_CMD_WeaveItem_WZMJex       WeaveItemArray[4];              //组合扑克

}WZMJex_CMD_S_GameEnd_WZMJex;

//用户可胡的牌
typedef struct 
{
  BYTE              cbCanHuCard;            //可以胡的牌
  BYTE              cbPoint;              //胡牌番数
  BYTE              cbLeftCount;            //剩余数量
}WZMJex_CMD_CanHuCard_WZMJex;

//用户托管
typedef struct {
    bool							bTrustee;							//是否托管
    WORD							wChairID;							//托管用户
}WZMJex_CMD_S_Trustee_WZMJex;

//确认 用户听牌
typedef struct {
    WORD							wChairId;							//听牌用户
}WZMJex_CMD_S_Listen_WZMJex;

//补牌命令
typedef struct {
    WORD							wReplaceUser;						//补牌用户
    BYTE							cbReplaceCard;						//补牌扑克
}WZMJex_CMD_S_ReplaceCard_WZMJex;

//买底结果
typedef struct {
    bool							bTotal;								//是否全部
    WORD							wMaiDiUser;							//买底用户
    BYTE							bMaidi[2];			//买底类型
}WZMJex_CMD_S_Chip_Result_WZMJex;

//出牌命令
typedef struct {
    BYTE							cbCardData;							//扑克数据
}WZMJex_CMD_C_OutCard_WZMJex;

//操作命令
typedef struct {
    BYTE							cbOperateCode;						//操作代码
    BYTE							cbOperateCard[3];					//操作扑克
}WZMJex_CMD_C_OperateCard_WZMJex;

//用户听牌
typedef struct {
    BYTE							cbListen;							//听牌用户
}WZMJex_CMD_C_Listen_WZMJex;

//用户托管
typedef struct {
    bool							bTrustee;							//是否托管
}WZMJex_CMD_C_Trustee_WZMJex;

//补牌命令
typedef struct {
    BYTE							cbCardData;							//扑克数据
}WZMJex_CMD_C_ReplaceCard_WZMJex;

//买底消息
typedef struct {
    BYTE							bMaiDi;								//买底类型
}WZMJex_CMD_C_Chip_WZMJex;

#pragma pack()
