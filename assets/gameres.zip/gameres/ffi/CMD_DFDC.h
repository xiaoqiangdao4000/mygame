#pragma pack(1)

//游戏状态
typedef struct 
{
	DWORD				dwBaseJetton;						//底注（对应图腾数量）
	WORD				wBetMultiple;						//倍数（1-10）
	BYTE				cbCardDatas[25];					//牌型数据
	LONGLONG			lTotalWinScore;						//累计赢分
	WORD				wFreeGames;							//剩余免费次数
	BYTE				bActiveChoiceFreeGame;				//是否需要玩家主动选择免费次数
	WORD				wChoiceFreeGameTimes;				//选择的免费游戏次数
	WORD				wFortuneTreeProgress;				//财神树总进度（分 100，200，300，400..900 九档）总共900满值
	BYTE				cbJackpotDatas[12];					//彩池牌型数据
	BYTE				cbJackpot;							//是否进入福娃彩金游戏
}DFDC_CMD_S_Status;

//用户下注
typedef struct 
{
	LONGLONG			lWinScore;								//开奖赢分
	WORD				wFreeGames;								//剩余免费次数
	LONGLONG			lTotalWinScore;							//累计赢分
	WORD				wFortuneTreeProgress;					//财神树总进度（分 100，200，300，400..900 九档）总共900满值
	LONGLONG			lFortuneTreeWinScore;					//开奖赢分
	BYTE				cbFeatureSymbolChangeValue;				//帘子转换
	BYTE				cbFeatureSymbolExpandValue;				//帘子扩容
	BYTE				cbCardDatas[25];						//牌型数据
	BYTE				cbJackpot;								//是否进入福娃彩金游戏
	LONGLONG			lJackScore;								//小奖彩金分数
	BYTE				cbActiveChoiceFreeGameFlag;			    //免费游戏标志
	BYTE				cbDiamondWildMutiple[25];		//diamond
}DFDC_CMD_S_Bet;

//选择免费游戏
typedef struct 
{
	WORD					wTimes;								//次数
}DFDC_CMD_S_ChoiceFreeGame;

//点击铜钱
typedef struct 
{
	WORD				wIndex;
	BYTE				wData;
	WORD				wJackType;								//巨奖，大奖，中奖，小奖
	LONGLONG			lJackScore;								//分数
	BYTE				cbJackpotDatas[12];					//彩池牌型数据
}DFDC_CMD_S_ClickJackpotIcon;




//游戏下注
typedef struct 
{
	DWORD					dwBaseJetton;
	WORD					wBetMultiple;
}DFDC_CMD_C_Bet;

//游戏选择免费游戏类型
typedef struct 
{
	WORD					wTimes;								//次数 钻石永恒（5、10、15） 熊猫（5、7、10、15、20）
}DFDC_CMD_C_ChoiceFreeGame;

//点击铜钱
typedef struct 
{
	WORD					wIndex;
}DFDC_CMD_C_ClickJackpotIcon;


#pragma pack()