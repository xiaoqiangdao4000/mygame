#pragma pack(1)

//手机客户端请求查询七天签到信息
typedef struct  
{ 
  int        nUserID; 
}CMD_MB_LoadSevenDaySign; 

//服务器返回七天签到信息 
typedef struct  
{ 
	SYSTEMTIME BeginTime; 
	SYSTEMTIME EndTime;  
	SYSTEMTIME ModifyTime;  
	DWORD dwDayCount;  
	DWORD dwDaySign;  
	DWORD dwAward;  
	DWORD dwFirstNumber;  
	DWORD dwSecondNumber;  
	DWORD dwThirdNumber;  
	DWORD dwForthNumber;  
	DWORD dwFifthNumber;  
	DWORD dwSixNumber; 
}CMD_MB_LoadSevenDaySignResult; 

 //手机客户端请求签到 
typedef struct  
{
  int        nUserID; 
  CHAR		 szMachineID[33];
}CMD_MB_SevenDaySign;  

//服务器签到结果 
typedef struct 
 { 
	DWORD dwDayCount;  
	DWORD dwDaySign;  
	DWORD dwAward;  
	DWORD dwFirstNumber;  
	DWORD dwSecondNumber;  
	DWORD dwThirdNumber; 
	DWORD dwForthNumber;  
	DWORD dwFifthNumber;  
	DWORD dwSixNumber; 
}CMD_MB_SevenDaySignResult;

#pragma pack()