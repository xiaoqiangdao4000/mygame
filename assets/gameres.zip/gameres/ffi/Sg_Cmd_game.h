#pragma pack(1)

//游戏状态
typedef struct 
{
	BYTE				cbStatus;					//游戏状态
	LONGLONG			lCellScore;					//底分
	BYTE				cbBetMultiples[4];			//加注倍数
	BYTE				cbPrepareTime;				//准备时间	
	BYTE				cbCallBankerTime;			//抢庄时间	
	BYTE				cbBetTime;					//下注时间	
	BYTE				cbOpenCardTime;				//摊牌时间						
	BYTE				cbEndTime;					//结束时间
	WORD				wBankerUser;				//庄家用户
	BYTE				cbPlayStatus[5];			//用户游戏状态 0:旁观 1:参与
	BYTE				cbBetMultiple[5];			//下注数目
	BYTE				cbHandCardData[5][3];		//桌面扑克
	BYTE				cbOperateStatus[5];			//操作状态
	BYTE				cbFleeInfo[5];				//逃跑信息
	BYTE				cbCardType[5];				//牌的类型
	LONGLONG   			lGameScore[5];    //游戏得分
	BYTE				cbTimeLeave;				//剩余时间
}SG_CMD_S_Status;

//游戏开始抢庄
typedef struct  
{
	BYTE				cbPlayStatus[5];	//游戏状态
}SG_CMD_S_GameStartCallBanker;

//游戏开始下注
typedef struct 
{
	WORD				wBankerUser;		//庄家用户
}SG_CMD_S_GameStartBet;

//游戏开始摊牌
typedef struct 
{
	BYTE				cbCardData[5][3];	//用户扑克
}SG_CMD_S_GameStartOpenCard;

//游戏结算
typedef struct 
{
	LONGLONG			lGameScore[5];				//游戏得分
	BYTE				cbCardData[5][3];			//用户扑克
	BYTE				cbCardType[5];				//牌的类型
	BYTE				cbFleeInfo[5];				//逃跑信息
}SG_CMD_S_GameEnd;

//用户退出
typedef struct 
{
	WORD				wPlayerID;								//退出用户
}SG_CMD_S_PlayerExit;

//用户叫庄(返回)
typedef struct 
{
	WORD				wCallBanker;		//叫庄用户
	BYTE				cbCall;				//是否叫庄
}SG_CMD_S_CallBanker;

//用户下注(返回)
typedef struct 
{
	WORD				wBetUser;			//加注用户
	BYTE				bMultiple;			//加注数目
}SG_CMD_S_Bet;

//用户摊牌
typedef struct 
{
	WORD				wPlayerID;			//摊牌用户
	BYTE				bOpen;				//摊牌标志
}SG_CMD_S_OpenCard;


//用户叫庄(请求)
typedef struct 
{
	BYTE					cbCall;				//是否叫庄
}SG_CMD_C_CallBanker;

//用户加注(请求)
typedef struct 
{
	BYTE 				cbMultiple;			//加注倍数
}SG_CMD_C_Bet;

#pragma pack()
